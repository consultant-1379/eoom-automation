#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import json
import logging
import argparse
import re
import paramiko
import os

from imscommon import SSHUtility
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from utils import CliExecutor
from sbg_parsers import SBGVCDXmlParser
from imscommon.parsers import OpenstackJsonParser

logger = logging.getLogger('scale_common')

DEFAULT_ADMIN = 'vsbg-admin'
ME_CLISS_PATTERN = re.compile(
    '^'
    'ManagedElement=[^ ]+,'
    'Equipment=1,'
    'ComputeResource=(?P<name>[^ ]+)'
    ' *$'
    '|'
    '^'
    'ManagedElement=[^ ]+,'
    'SbgFunction.id=1,'
    'ProcessorManagement.id=1,'
    'MatedPair.id=(?P<id>[^ ]+),'
    'PayloadProcessor=(?P<name_pl>[^ ]+)'
    ' *$'
)


class ScaleParser(object):

    class PreScaleJsonParser(OpenstackJsonParser):
        def get_all_params(self):
            stack_outputs = dict(
                (output['output_key'], output['output_value'])
                for output in self.vnf_status_file["stack"]['outputs']
            )

            parameters = dict(
                (k, v.strip())
                for k, v in self.vnf_status_file["stack"]['parameters'].iteritems()
            )

            self.affinity_policy = parameters.get('affinity_policy')
            user_name = parameters.get('admin_username', DEFAULT_ADMIN)
            ip = stack_outputs.get('Output-IP')
            uuids = stack_outputs.get('pl_uuids').strip().split()
            resource_names = stack_outputs.get('pl_names').strip().split()

            return (ip, user_name, uuids, resource_names)

    class PreScaleXMLParser(SBGVCDXmlParser):
        def __init__(self, filename):
            super(ScaleParser.PreScaleXMLParser, self).__init__(filename)
            self.uuids = self.get_uuids()

        def get_all_params(self):
            user_name = self.get_admin_username()
            _ip = self.get_oam_public_ip()
            resource_names = self.get_vm_names()

            return (_ip, user_name, self.uuids, resource_names)

        def get_vm_names(self):
            names = []

            xpath = './/vcloud:Vm'
            vms = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))

            for _vm in vms:
                names.append(_vm.attrib.get('name'))

            return names

        def get_pl_mac_addresses(self):
            vm_names = self.get_vm_names()
            macs = self.get_mac_addresses()
            entry_regexp = '.+PL-[0-9]+$'

            pl_macs = []
            for vm_name in vm_names:
                pl_postfix = re.match(entry_regexp, vm_name)
                if pl_postfix:
                    idx = vm_names.index(vm_name)
                    pl_macs.append(macs[idx])

            return pl_macs

        def get_payload_instance_count(self):
            return len(self.get_pl_mac_addresses())


class ScaleInHook(object):

    class InputData:
        def __init__(self,
                     admin_username,
                     sc_ip,
                     number_of_steps,
                     uuids,
                     resource_names,
                     preferred_uuids=None,
                     key_file=None,
                     password_file=None,
                     port=22):
            self.admin_username = admin_username
            self.sc_ip = sc_ip
            self.number_of_steps = number_of_steps
            self.uuids = uuids
            self.resource_names = resource_names
            self.preferred_uuids = preferred_uuids or []
            if preferred_uuids is None:
                preferred_uuids = []
            self.key_file = key_file
            self.password_file = password_file
            self.port = port

    def parse_input_json_file(self, input_json_file):
        if not input_json_file:
            return None
        try:
            with open(input_json_file) as json_file:
                return json.load(json_file)
        except Exception as ex:
            logger.error(
                "Input JSON file is invalid: %s, caught exception: %s ",
                input_json_file, ex
            )
            raise Exit(ReturnCode.INVALID_JSON)

    def argument_parsing(self):
        parser = argparse.ArgumentParser("pre_scale_in hook for workflow")
        arg = parser.add_argument
        arg('-f', '--vnf-instance-details-file', metavar='<FILE>',
            help='Path to the file containing the response of stack show '
                 'details command in json format.',
            required=True)
        arg('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.')
        arg('-p', '--password-file', metavar='<PASSWORD_FILE>',
            help=('Path to the file containing the password '
                  'to login into the VNF instance.'),
            type=str, required=False)
        arg('-x', '--aspect-id', metavar='<ASPECT_ID>',
            help='The aspect id of the scaling domain to scale.',
            required=False)
        arg('-l', '--auto-scale-info-file', metavar='<AUTO_SCALE_INFO_FILE>',
            help='Auto Scale information parameters.',
            required=False)
        arg('-k', '--key-file', metavar='<KEY_FILE>',
            help='SSH public key', type=str, required=False)
        arg('-u', '--user-name', metavar='<USERNAME>',
            help='user name', type=str, required=False)
        arg('-i', '--workflow-instance-identifier', metavar='<ID>',
            help='Workflow instance identifier.',
            required=False)
        arg('-n', '--number-of-steps', metavar='<STEPS>',
            help='Number of scaling steps.',
            type=int,
            required=True)

        args = parser.parse_args()

        self.password_file = args.password_file
        self.key_file = args.key_file
        self.number_of_steps = args.number_of_steps
        self.workflow_instance_identifier = args.workflow_instance_identifier

        if args.vnf_instance_details_file.endswith('.xml'):
            self.vnf_instance_file_parser = ScaleParser.PreScaleXMLParser(
                args.vnf_instance_details_file)
        else:
            self.vnf_instance_file_parser = ScaleParser.PreScaleJsonParser(
                args.vnf_instance_details_file)

        logger.debug('json file [%s] loaded',
                     args.vnf_instance_details_file)

        self.auto_scale_info_params = self.parse_input_json_file(args.auto_scale_info_file)
        self.additional_params = self.parse_input_json_file(args.additional_param_file)
        (self.sc_ip, self.admin_username,
         self.uuids, self.resource_names) = self.vnf_instance_file_parser.get_all_params()

    def __init__(self):
        self.argument_parsing()
        self.preferred_uuids = self.additional_params.get('listOfUUIDsToBeDeleted', [])
        self.shutting_down_timeout = \
            self.additional_params.get('shuttingDownTimeout', None)
        self.shutdown_type = self.additional_params.get('shutdownType', None)
        self.input_data = self.InputData(
            self.admin_username,
            self.sc_ip,
            self.number_of_steps,
            self.uuids,
            self.resource_names,
            self.preferred_uuids,
            self.key_file,
            self.password_file
        )

        self.ssh = SSHUtility.SSHUtility(
            ip=self.input_data.sc_ip,
            username=self.input_data.admin_username,
            password=self.input_data.password_file,
            key_filename=self.input_data.key_file,
            port=self.input_data.port,
        )
        self.cli = CliExecutor(self.ssh)

    def _get_pair_policy(self):
        stdout, stderr, retcode = \
            self.ssh.run_command('cat /opt/sgc/etc/pair_policy',
                                 fail_at_error=False)
        policy = stdout.strip()
        if retcode != 0 or not policy:
            logger.error("Get pair policy ('%s') error: '%s'", policy, stderr)
            raise Exit(ReturnCode.DATA_ERROR)
        return policy

    def check_connection(self):
        try:
            self.ssh.run_command('true')
            return True
        except paramiko.AuthenticationException:
            logger.error('SSH Authentication failed')
            raise Exit(ReturnCode.RETURN_ERROR)
        except Exception:
            logger.exception('Failed to execute remote command')
            return False

    def path(self, name):
        conf_dir = '.vnflcm_scale'

        home_dir = os.path.join('/home', self.admin_username)
        vnflcm_dir = os.path.join(home_dir, conf_dir)
        return {
            'VNFLCM_DIR':
                vnflcm_dir,
            'INSTANCE_ID_FILE':
                os.path.join(vnflcm_dir, 'instance_id'),
            'START_TIME_FILE':
                os.path.join(vnflcm_dir, 'scale_start_time'),
            'SCALE_IN_DATA_FILE':
                os.path.join(vnflcm_dir, 'scale_in_data.json'),
            'POST_SCALE_IN_STDOUT':
                os.path.join(vnflcm_dir, 'post_scale_in_stderr'),
            'POST_SCALE_IN_STDERR':
                os.path.join(vnflcm_dir, 'post_scale_in_stdout'),
            'POST_SCALE_IN_RC':
                os.path.join(vnflcm_dir, 'post_scale_in_rc'),
        }[name]

    def is_vcd(self):
        return isinstance(self.vnf_instance_file_parser, ScaleParser.PreScaleXMLParser)

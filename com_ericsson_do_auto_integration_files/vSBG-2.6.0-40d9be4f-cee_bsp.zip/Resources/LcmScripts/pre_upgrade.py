#!/usr/bin/env python2

"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import json
import logging
import os
import re
import sys
import shutil
import ast
import yaml
from sbg_common import mkcmd, CommonLcmTask
from sbg_parsers import SBGVCDXmlParserExtended as VCDXmlParser
from sbg_parsers import SBGOpenstackJsonParser as OpenstackJsonParser
from imscommon.consts import ReturnCode
from imscommon.exceptions import Exit
from utils import CliExecutor

DEFAULT_ADMIN = 'vsbg-admin'
WORKFLOW_USER = 'workflow-user'
WORKFLOW_IP = '127.0.0.1'


class PreUpgrade(CommonLcmTask):

    class InputData:
        def __init__(self,
                     sc_ip,
                     admin_username,
                     environment=None,
                     password=None,
                     key_filename=None,
                     instance_id=None):
            self.sc_ip = sc_ip
            self.config_dir = os.path.dirname(environment)
            self.environment = environment
            self.admin_username = admin_username
            self.password = password
            self.key_filename = key_filename
            self.instance_id = instance_id

    def __init__(self):
        self.input_data = self.argument_parsing()
        self.ssh = None
        self.state = None
        self.conf_up_path = None
        self.conf_roll_path = None
        self.env = {}

    def __call__(self):
        self.ssh = self.connect_to_host(
            ip=self.input_data.sc_ip,
            username=self.input_data.admin_username,
            password=self.input_data.password,
            key_filename=self.input_data.key_filename,
            port=22)
        logger.info('Checking if SSH is available')
        if not self.check_connection(self.ssh):
            logger.warning('SSH connection is not available yet.')
            print('SSH connection is not available yet.')
            raise Exit(ReturnCode.REPEAT)
        self.cli = CliExecutor(self.ssh)
        self.create_vnflcm_dir(self.input_data.admin_username,
                               self.input_data.instance_id)
        self.export_configuration()
        self.ssh.close()
        print(self.generate_upgrade_environments())

    def export_configuration(self):
        if not os.path.exists(self.input_data.config_dir):
            logger.error('The output configuration directory does not existed.')
            raise Exit(ReturnCode.RETURN_ERROR)

        conf_up_dir = os.path.join(self.input_data.config_dir, '.upgrade_config')
        conf_roll_dir = os.path.join(self.input_data.config_dir, '.rollback_config')

        if not os.path.exists(conf_up_dir):
            os.mkdir(conf_up_dir)

        if not os.path.exists(conf_roll_dir):
            os.mkdir(conf_roll_dir)

        conf_file = 'sbg_config'
        extense = '.tar.gz'

        conf_up_path = os.path.join(conf_up_dir, conf_file + extense)
        conf_roll_path = os.path.join(conf_roll_dir, conf_file + extense)
        remote_path = os.path.join(self.path('VNFLCM_DIR',
                                             self.input_data.admin_username,
                                             self.input_data.instance_id),
                                   conf_file + extense)
        remote_target = os.path.join(self.path('VNFLCM_DIR',
                                               self.input_data.admin_username,
                                               self.input_data.instance_id),
                                     conf_file)

        self.update_state()
        if self.state is None:
            logger.info('Start to export the configration.')
            print('Start to export the configration.')
            self._perform_configuration_export(remote_target)
            raise Exit(ReturnCode.REPEAT)
        elif self.state == 'Running':
            logger.info('Exporting the configuration.')
            print('Exporting the configuration.')
            raise Exit(ReturnCode.REPEAT)
        elif self.state == 'Error':
            logger.error('Failed to export the configration.')
            raise Exit(ReturnCode.RETURN_ERROR)
        else:
            logger.info('The configuration is exported.')
            self.rm_file(self.path('START_FILE',
                                   self.input_data.admin_username,
                                   self.input_data.instance_id))
            self.rm_file(self.path('RET_FILE',
                                   self.input_data.admin_username,
                                   self.input_data.instance_id))
            self.ssh.get_file(remote_path, conf_up_path)
            """
            In SBG the converting action is combined to importing action
            So just copy the config file for both upgrade and rollback
            """
            shutil.copy2(conf_up_path, conf_roll_path)
            self.conf_up_path = conf_up_path
            self.conf_roll_path = conf_roll_path

    def generate_upgrade_environments(self):
        jsons = {}

        scheme_conf_up_path = "file://" + self.conf_up_path
        scheme_conf_roll_path = "file://" + self.conf_roll_path

        jsons['upgradeEnvironment'] = self.upgrade_environment()
        jsons['rollbackEnvironment'] = self.create_rollback_env()
        jsons['upgradeAdditionalFiles'] = [scheme_conf_up_path]
        jsons['rollbackAdditionalFiles'] = [scheme_conf_roll_path]

        return json.dumps(jsons)

    def upgrade_environment(self):
        """Upgrade the environment file to the new version."""
        self.env = self.read_env()
        if self.cloud_type == 'VMWARE':
            if not self.env.get('product_section_parameters'):
                self.env['product_section_parameters'] = {}
            self.upgrade_env_vcd()

        self.extract_secret_settings()
        return self.env

    def upgrade_env_vcd(self):
        prod_section = self.env['product_section_parameters']
        vapp_properties = self.vnf_instance_file_parser.get_user_configurable_vapp_properties()
        for prop, val in vapp_properties.iteritems():
            if prop not in prod_section:
                logger.debug("Adding %r to env with value %r", prop, val)
                prod_section[prop] = val

        if not self.env.get('template', None):
            logger.error(
                "The upgrade target config (env-vcd.y(a)ml) is missing "
                "'template' entry! It must contain this parameter and "
                "it must point to a valid template "
                "in your vCloud Director!"
            )
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        if not self.env.get('vapp_affinity', None):
            aff_rule = self.vnf_instance_file_parser.get_affinity_rule()
            logger.info(
                ("Parameter 'vapp_affinity' was missing from upgrade "
                 "target config. Adding value %r"),
                aff_rule
            )
            self.env['vapp_affinity'] = aff_rule

        network_data = self.vnf_instance_file_parser.get_grouped_networks()
        self.env['org_networks'] = network_data['org_networks']
        self.env['vapp_networks'] = network_data['vapp_networks']

    def read_env(self):
        """Load the environent file"""
        with open(self.parsed_args.environment) as yamfile:
            return yaml.safe_load(yamfile)

    def extract_secret_settings(self):
        """
        Extract settings from vnf that cannot be extracted
        from stack/vApp status.
        """
        if self.cloud_type == 'OPENSTACK':
            self.extract_secret_settings_openstack()
        elif self.cloud_type == 'VMWARE':
            self.extract_secret_settings_vcd()

    def extract_secret_settings_openstack(self):
        param_defs = self.env['parameter_defaults']
        param_defs['admin_password_hash'] = self.get_pw_hash()

    def extract_secret_settings_vcd(self):
        """
        VMWare's OVF format contains most secrets already, but we should
        rewrite them, in case they changed since the OVF creation.
        """
        param_defs = self.env['product_section_parameters']
        param_defs['passwd'] = self.get_pw_hash()

    def get_pw_hash(self):
        if self.cloud_type == "OPENSTACK":
            admin_username = self.env['parameter_defaults']['admin_username']
        elif self.cloud_type == "VMWARE":
            admin_username = self.env['product_section_parameters']['user_name']
        pw_hash_cmd_parts = (
            "sudo cat /etc/shadow",
            "grep {0}".format(admin_username),
            "awk '{split($0,tokens,\":\")} END {print tokens[2]}'",
        )
        pw_hash_cmd = " | ".join(pw_hash_cmd_parts)
        return self.execute_on_vnf(pw_hash_cmd).split()[0]

    def execute_on_vnf(self, command):
        """Execute command on the remote VM"""
        return self.cli.run_cli_remote(command)

    def create_rollback_env(self):
        """
        Create env-vcd.yaml or env-yaml that would be used
        by the rolled-back instance.
        """
        self.env = {}
        if self.cloud_type == 'OPENSTACK':
            self.create_rollback_env_openstack()
        elif self.cloud_type == 'VMWARE':
            self.create_rollback_env_vcd()
        return self.env

    def create_rollback_env_vcd(self):
        """Create env-vcd.yaml from vApp details."""
        self.env['product_section_parameters'] = {}
        self.convert_vappdetails_to_env()
        self.extract_secret_settings()

    def create_rollback_env_openstack(self):
        """Create env.yaml from stackdetails."""
        self.env['parameter_defaults'] = {}
        self.convert_stackdetails_to_env()
        self.extract_secret_settings()

    def convert_vappdetails_to_env(self):
        """
        Convert vApp details XML into environment for orchestration.
        """
        # template name, affinity rule
        self.env['template'] = self.vnf_instance_file_parser.get_vapp_template_name()
        self.env['vapp_affinity'] = self.vnf_instance_file_parser.get_affinity_rule()
        # networks
        network_data = self.vnf_instance_file_parser.get_grouped_networks()
        self.env.update(network_data)
        # product section
        parameters = self.vnf_instance_file_parser.get_user_configurable_vapp_properties()
        self.env['product_section_parameters'].update(parameters)

    def convert_stackdetails_to_env(self):
        """
        Convert OS stack details json into environment for orchestration.
        """
        block = '[:]'
        regex = re.compile(block)

        parameters = self.vnf_instance_file_parser.vnf_status_file['stack']['parameters']
        for attr, val in parameters.iteritems():
            if regex.search(attr) is None:
                """
                json load can not parse the netsted unicode str
                from stack file
                e.g.
                In env(yaml), sig_vlans: ['1001', '1002']
                In stack(json), , "sig_vlans": "[u'1001', u'1002]",
                After json load, Dict< u'sig_vlans':u"[u'1001', u'1002]" >
                So excute additional parse, after _nested_escape_unicode:
                str u"[u'1001', u'1002]" => list ['1001', '1002']
                """
                r_attr = self._nested_escape_unicode(attr)
                r_val = self._nested_escape_unicode(val)
                self.env['parameter_defaults'][r_attr] = r_val

    def _perform_configuration_export(self, remote_target):
        try:
            """ There is a TR for imex sbc_export_conf.py """
            """ 1. Not support abs path, so split it """
            """ 2. Not accept the filename with extense """
            (filepath, filename) = os.path.split(remote_target)
            self.ssh.run_command(
                str.format(
                    'nohup bash -c '
                    '\'cd {2}; '
                    'IMEX_SFTP_USER={1} '
                    'IMEX_SFTP_HOST={0} '
                    '/opt/imex/sbc_export_conf.py --timeout 600 --user {1} {3}; '
                    'echo $? > {4}\' '
                    '> {5} 2>{6} </dev/null &',
                    WORKFLOW_IP,
                    WORKFLOW_USER,
                    filepath,
                    filename,
                    self.path('RET_FILE',
                              self.input_data.admin_username,
                              self.input_data.instance_id),
                    self.path('OUT_FILE',
                              self.input_data.admin_username,
                              self.input_data.instance_id),
                    self.path('ERR_FILE',
                              self.input_data.admin_username,
                              self.input_data.instance_id)))
            self.ssh.run_command(
                mkcmd('touch',
                      self.path('START_FILE',
                                self.input_data.admin_username,
                                self.input_data.instance_id)))
        except:
            logger.error('Failed to export configuration.')
            raise Exit(ReturnCode.RETURN_ERROR)

    def _nested_escape_unicode(self, item):
        if isinstance(item, unicode):
            real_item = item.encode('unicode_escape')
        else:
            real_item = item

        if isinstance(real_item, str):
            return self._nested_translate_str(real_item)

        return real_item

    def _nested_translate_str(self, origin_str):
        relay_str = self._nested_escape_unicode_for_str(origin_str)
        if isinstance(relay_str, str) and relay_str.isdigit():
            return int(relay_str)

        return relay_str

    def _nested_escape_unicode_for_str(self, origin_str):
        relay_str = origin_str.strip()
        if len(relay_str) < 3:
            return relay_str

        if relay_str[0] == '[' and relay_str[-1] == ']':
            """
            From str [,,,] to list [,,,]
            """
            outlist = ast.literal_eval(relay_str)
            return outlist

        if relay_str[0] == 'u' and relay_str[1] == '\'' and relay_str[-1] == '\'':
            """
            From str: u'string' to str: 'string'
            """
            return relay_str[2:-1]

        if relay_str[0] == 'u' and relay_str[1] == '\"' and relay_str[-1] == '\"':
            """
            From str u"a'bc'de" to str a'bc'de OR
                 str u"[u'a', u'b']" to list of str ['a', 'b']
            """
            return self._nested_escape_unicode_for_str(relay_str[2:-1])

        return relay_str

    def update_state(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f',
                                       self.path('START_FILE',
                                                 self.input_data.admin_username,
                                                 self.input_data.instance_id)),
                                 fail_at_error=False)

        if retcode > 0:
            self.state = None
            return

        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat',
                                       self.path('RET_FILE',
                                                 self.input_data.admin_username,
                                                 self.input_data.instance_id)),
                                 fail_at_error=False)
        if retcode > 0:
            self.state = 'Running'
        elif stdout.strip() == '0':
            self.state = 'Done'
        else:
            self.state = 'Error'

    def add_additional_arguments(self):
        arg = self.parser.add_argument
        arg('-i', '--instaceid',
            help='Workflow session instance id',
            required=True)
        arg('-e', '--environment',
            help='Path to new environment file',
            required=True)
        arg('-s', '--sourceversion',
            help='Version of the source',
            required=True)
        arg('-t', '--targetversion',
            help='Version of the source will be converted',
            required=True)

    def argument_parsing(self):
        # Add the common input arguments
        self.add_common_arguments('pre_upgrade hook for workflow')
        # Add additional arguments for pre_upgrade
        self.add_additional_arguments()
        args = self.parser.parse_args()
        self.parsed_args = args
        self.cloud_type = self.get_cloud_type(args.vnf_instance_details_file)
        logger.info('Loading vnf_instance_details_file: %r',
                    args.vnf_instance_details_file)
        if self.cloud_type == 'OPENSTACK':
            self.vnf_instance_file_parser = OpenstackJsonParser(
                args.vnf_instance_details_file
            )
        elif self.cloud_type == 'VMWARE':
            self.vnf_instance_file_parser = VCDXmlParser(
                args.vnf_instance_details_file
            )
        sc_ip, admin_username, dummy = \
            self.vnf_instance_file_parser.get_all_params()

        data = PreUpgrade.InputData(sc_ip,
                                    admin_username,
                                    args.environment,
                                    args.password_file,
                                    args.key_file,
                                    args.instaceid)
        logger.info('Input data: %r', data)
        return data


def main():
    pre_upgrade = PreUpgrade()
    try:
        pre_upgrade()
    except Exit as e:
        if e.return_code == ReturnCode.SUCCESS:
            logger.info('Exiting with SUCCESS (0)')
        elif e.return_code == ReturnCode.REPEAT:
            logger.info('Exiting with REPEAT (100)')
        else:
            logger.error('Exiting with ERROR (%d)', e.return_code)

        sys.exit(e.return_code)


if __name__ == '__main__':
    """ sys.stdout is used for printing environments and config files """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    logger = logging.getLogger('pre_upgrade')
    main()

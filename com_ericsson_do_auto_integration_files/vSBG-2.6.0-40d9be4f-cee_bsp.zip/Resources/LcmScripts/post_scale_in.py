#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import re
import sys
import time
import json
import logging

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from scale_common import ScaleInHook


CMW_STATUS_NODE_RE = r'^safAmfNode=(?P<vm_name>[^,]+),safAmfCluster=.*$'


class PostScaleIn(ScaleInHook):

    def __init__(self):
        super(PostScaleIn, self).__init__()

    def __call__(self):
        """Wait until all scaled in VMs are disabled, then
        call a scale_in_node.py utility on them each and wait
        until that completes. If it completes with no errors, the hook
        is successful."""
        if not self.check_connection():
            logger.warning('SSH connection is not available yet.')
            print('Waiting for SSH connection')
            raise Exit(ReturnCode.REPEAT)
        self.load_scale_in_data()

        if not self.cmw_cleanup_started():
            self.check_all_vms_are_disabled()
            self.start_cmw_cleanup()
            logger.info("Waiting to see if the cmw cleanup finishes.")
            time.sleep(20)

        if not self.cmw_cleanup_finished():
            print("Waiting for nodes to be removed from CrM")
            raise Exit(ReturnCode.REPEAT)
        logger.info("Nodes removed from CrM successfully.")
        # TODO should any cmw-status indicators be waited for?

        # at the very end only, clean up the scale_in working dir
        self.cleanup_scale_working_dir()

    def cleanup_scale_working_dir(self):
        vnflcm_dir = self.path('VNFLCM_DIR')
        _, err, rc = self.ssh.run_command(
            "rm -rf '{}'".format(vnflcm_dir),
            fail_at_error=False)
        if rc != 0:
            logger.warning(
                "Failed to delete directory '%s': %s", vnflcm_dir, err)

    def check_all_vms_are_disabled(self):
        """Check `cmw-status node` and see if all the expected names
        appear there as "DISABLED". If not, raise REPEAT."""
        cmw_status, _, _ = self.ssh.run_command(
            "cmw-status node", fail_at_error=False)
        cmw_status_lines = cmw_status.strip().split()
        missing_vms = set(self.names_scaled)
        for line in cmw_status_lines:
            vm_status_match = re.match(CMW_STATUS_NODE_RE, line)
            if vm_status_match is None:
                continue
            vm_name = vm_status_match.group('vm_name')
            if vm_name in missing_vms:
                missing_vms.remove(vm_name)

        if missing_vms:
            logger.info(
                "The following VMs are not in state 'DISABLED' yet: %s",
                missing_vms)
            print("Waiting for scaled-in VM states to update ({})".format(
                ' '.join(missing_vms)))
            raise Exit(ReturnCode.REPEAT)

    def cmw_cleanup_started(self):
        """If the stderr redirection file exists, it was started already."""
        err_file = self.path('POST_SCALE_IN_STDERR')
        _, _, rc = self.ssh.run_command(
            "test -f {}".format(err_file), fail_at_error=False)
        return rc == 0

    def cmw_cleanup_finished(self):
        """If the rcfile exists, then the job finished."""
        rc_file = self.path('POST_SCALE_IN_RC')
        err_file = self.path('POST_SCALE_IN_STDERR')
        error_log = self.ssh.run_command("cat '{}'".format(err_file))[1]

        file_content, _, rc = self.ssh.run_command(
            "cat '{}'".format(rc_file), fail_at_error=False)
        if rc != 0:
            logger.info(
                "cmw cleanup still in progress, no rcfile found at %s",
                rc_file)
            return False
        cleanup_result = file_content.strip()
        if not cleanup_result or cleanup_result != '0':
            logger.error(
                "cmw cleanup failed! rc: '%s', error log:\n%s",
                cleanup_result, error_log)
            raise Exit(ReturnCode.RETURN_ERROR)
        return True

    def start_cmw_cleanup(self):
        cleanup_script = str.format(
            """nohup bash 2>{err_file} >{out_file} << 'ENDOFSCRIPT' &
rc=0
for node_name in {node_names}; do
    try_count=5
    last_rc=1
    while [ $try_count -gt 0 ]; do
        /opt/imex/scale_in_node.py "$node_name"
        last_rc=$?
        if [ $last_rc -eq 0 ]; then
            break
        fi
        try_count=$((try_count-1))
        sleep 1s
    done
    rc=$((rc+last_rc))
done
echo -n "$rc" >{rc_file}
ENDOFSCRIPT""",
            err_file=self.path('POST_SCALE_IN_STDERR'),
            out_file=self.path('POST_SCALE_IN_STDOUT'),
            node_names=' '.join(self.names_scaled),
            rc_file=self.path('POST_SCALE_IN_RC'),
        )
        logger.info('Cleanup script to run:\n%s', cleanup_script)
        self.ssh.run_command(cleanup_script)

    def load_scale_in_data(self):
        """Load data about the operation saved during pre_scale_in.
        This contains the information about which VMs were scaled in,
        and which MatedPairs were affected by the opration."""
        scale_in_data_file = self.path('SCALE_IN_DATA_FILE')
        try:
            data_content, _, _ = self.ssh.run_command(
                "cat '{}'".format(scale_in_data_file))
            scale_in_data = json.loads(data_content.strip())
            self.names_scaled = scale_in_data['names_scaled']
            self.mps_affected = scale_in_data['mps_affected']
        except Exit:
            raise
        except Exception:
            logger.exception("Error while fetching scale-in data")
            raise Exit(ReturnCode.INVALID_JSON)


def main():
    try:
        post_scale_in = PostScaleIn()
        post_scale_in()
    except Exit as e:
        logger.error('Exiting (%d)', e.return_code)
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    logger = logging.getLogger('postscalein')
    main()

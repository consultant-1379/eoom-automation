#!/usr/bin/env python2

"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import os
import logging
import time
import sys
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from sbg_parsers import SBGVCDXmlParser as VCDXmlParser
from sbg_parsers import SBGOpenstackJsonParser as OpenstackJsonParser
from sbg_common import JobType, mkcmd, CommonLcmTask

DEFAULT_ADMIN = 'vsbg-admin'
WORKFLOW_USER = 'workflow-user'
WORKFLOW_IP = '127.0.0.1'


class PostInstantiation(CommonLcmTask):
    job_list = [('wait_for_cmw_status_ok', JobType.FG),
                ('check_cmw_status_node_su_sg', JobType.FG),
                ('import_configuration', JobType.BG)]

    class InputData:
        def __init__(self,
                     sc_ip,
                     config_dir,
                     key_filename,
                     admin_username,
                     password,
                     instance_id):
            self.sc_ip = sc_ip
            self.config_dir = config_dir
            self.key_filename = key_filename
            self.admin_username = admin_username
            self.password = password
            self.instance_id = instance_id

        def __repr__(self):
            return repr(self.__dict__)

    def __init__(self):
        super(PostInstantiation, self).__init__(workflow_name=self.__class__.__name__)
        self.input_data = self.argument_parsing()
        self.ssh = None
        self.state = None
        self.to_run = None

    def __call__(self):
        self.ssh = self.connect_to_host(
            ip=self.input_data.sc_ip,
            username=self.input_data.admin_username,
            password=self.input_data.password,
            key_filename=self.input_data.key_filename,
            port=22)
        logger.info('Checking if SSH is available')
        if not self.check_connection(self.ssh):
            logger.warning('SSH connection is not available yet.')
            print('SSH connection is not available yet.')
            raise Exit(ReturnCode.REPEAT)
        self.create_vnflcm_dir(self.input_data.admin_username,
                               self.input_data.instance_id)
        self.read_state_file(self.input_data.admin_username,
                             self.input_data.instance_id)
        self.check_state()
        self.execute_jobs()
        self.rm_file(self.path('STATE_FILE',
                               self.input_data.admin_username,
                               self.input_data.instance_id))
        self.rm_file(self.path('RET_FILE',
                               self.input_data.admin_username,
                               self.input_data.instance_id))
        self.ssh.close()

    def check_state(self):
        if self.state == '':
            logger.debug('State is clean, will run all the jobs')
            self.to_run = PostInstantiation.job_list
        else:
            logger.debug('Intermediate state detected: %s', self.state)
            self._check_bg_job()

    def _check_bg_job(self):
        if self._is_job_started():
            self._read_job_ret()

        # bg job is done or not started if reaches here
        # re-organize the job list
        self.to_run = []
        found = False
        for jobname, jobtype in PostInstantiation.job_list:
            if jobname == self.state.strip():
                found = True
                continue
            if found:
                self.to_run.append((jobname, jobtype))
        self.rm_file(self.path('STATE_FILE',
                               self.input_data.admin_username,
                               self.input_data.instance_id))
        self.rm_file(self.path('RET_FILE',
                               self.input_data.admin_username,
                               self.input_data.instance_id))
        self.rm_file(self.path('START_FILE',
                               self.input_data.admin_username,
                               self.input_data.instance_id))

    def _is_job_started(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f',
                                       self.path('START_FILE',
                                                 self.input_data.admin_username,
                                                 self.input_data.instance_id)),
                                 fail_at_error=False)
        return retcode == 0

    def _read_job_err(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat',
                                       self.path('ERR_FILE',
                                                 self.input_data.admin_username,
                                                 self.input_data.instance_id)),
                                 fail_at_error=False)
        if retcode > 0:
            logger.warning('Background job %s is running, read job error file failed', self.state)
        else:
            ret = stdout.strip()
            logger.warning('Error massage: %r', ret)

    def _read_job_ret(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat',
                                       self.path('RET_FILE',
                                                 self.input_data.admin_username,
                                                 self.input_data.instance_id)),
                                 fail_at_error=False)
        if retcode > 0:
            logger.warning('Background job %s is still running', self.state)
            print("Background job {job} is still running".format(job=self.state))
            raise Exit(ReturnCode.REPEAT)
        else:
            ret = int(stdout.strip())
            logger.debug('Background job %r exits with %r', self.state, ret)
            if ret > 0:
                self._read_job_err()
                logger.exception('Background job exited with error')
                raise Exit(ReturnCode.RETURN_ERROR)

    def execute_jobs(self):
        logger.debug('Jobs to run %r', self.to_run)
        for jobname, jobtype in self.to_run:
            func = getattr(self, jobname)
            if callable(func):
                func()
            else:
                logger.exception('Wrong job name %r', jobname)
                raise Exit(ReturnCode.RETURN_ERROR)

            if jobtype == JobType.BG:
                logger.debug('Interrupted by job %r', jobname)
                self._save_state(jobname)
                print("Interrupted by job {job}.".format(job=jobname))
                raise Exit(ReturnCode.REPEAT)

    def _save_state(self, jobname):
        logger.debug('Saving state %r to file', jobname)
        try:
            self.ssh.run_command(
                str.format(
                    "echo '{0}' > '{1}'",
                    jobname,
                    self.path('STATE_FILE',
                              self.input_data.admin_username,
                              self.input_data.instance_id)))
        except:
            logger.exception('Failed to save state file')
            raise Exit(ReturnCode.RETURN_ERROR)

    def wait_for_cmw_status_ok(self):
        logger.info('Waiting for CoreMW')
        if not self._wait_for_cmd_status_ok('cmw-status node'):
            logger.info('CoreMW is NOT OK')
            print('CoreMW is NOT OK.')
            raise Exit(ReturnCode.REPEAT)
        logger.info('CoreMW is OK')

    def check_cmw_status_node_su_sg(self):
        logger.info('Waiting for cmw-status node su sg')
        if not self._wait_for_cmd_status_ok('cmw-status node su sg'):
            logger.info('cmw-status node su sg is NOT OK')
            print('cmw-status node su sg is NOT OK.')
            raise Exit(ReturnCode.REPEAT)
        logger.info('cmw-status node su sg is OK')

    def _wait_for_cmd_status_ok(self, cmd, try_count=2, wait_time=8):
        logger.debug('Waiting for %r status ...', cmd)
        for attempt in range(try_count):
            try:
                self.ssh.run_command(cmd)
            except Exception as e:
                logger.info('Status is NOT OK (was try %d/%d)',
                            attempt + 1, try_count)
                time.sleep(wait_time)
            else:
                logger.debug('Status is OK')
                return True
        logger.error('Status is NOT OK (%r)', cmd)
        return False

    def import_configuration(self):
        possible_names = (
            'sbg_config.tar.gz',
        )
        possible_paths = (
            os.path.join(self.input_data.config_dir, fname)
            for fname in possible_names
        )

        try:
            src_path = next(
                pth for pth in possible_paths if os.path.exists(pth))
        except StopIteration:
            logger.warning('No config files found in %r; expected any of:%r',
                           self.input_data.config_dir, possible_names)
            logger.info('The vSBG instance will not be configured.')
            return
        self._perform_configuration_import(src_path)

    def _perform_configuration_import(self, src_path):
        dst_path = os.path.join(self.path('VNFLCM_DIR',
                                          self.input_data.admin_username,
                                          self.input_data.instance_id),
                                os.path.basename(src_path))
        logger.info('Importing configuration from %r, through VNF:%r',
                    src_path, dst_path)
        try:
            self.ssh.send_file(src_path, dst_path)
            self.ssh.run_command(
                str.format(
                    'nohup bash -c '
                    '\'IMEX_SFTP_USER={1} '
                    'IMEX_SFTP_HOST={0} '
                    '/opt/imex/sbc_import_conf.py --timeout 1800 --user {1} {2}; '
                    'echo $? > {3}\' '
                    '> {4} 2>{5} </dev/null &',
                    WORKFLOW_IP,
                    WORKFLOW_USER,
                    dst_path,
                    self.path('RET_FILE', self.input_data.admin_username,
                              self.input_data.instance_id),
                    self.path('OUT_FILE', self.input_data.admin_username,
                              self.input_data.instance_id),
                    self.path('ERR_FILE', self.input_data.admin_username,
                              self.input_data.instance_id)))
            self.ssh.run_command(mkcmd('touch',
                                       self.path('START_FILE',
                                                 self.input_data.admin_username,
                                                 self.input_data.instance_id)))
        except:
            logger.exception('Failed to import configuration')
            raise Exit(ReturnCode.RETURN_ERROR)

    def add_additional_arguments(self):
        self.mandatory.add_argument('-c', '--config-dir', metavar='<CONFIG_DIR>',
                                    help='Configuration directory',
                                    type=str,
                                    required=True)
        self.parser.add_argument('-i', '--workflow-instance-identifier', metavar='<ID>',
                                 help='Workflow instance identifier.',
                                 required=False)

    def argument_parsing(self):
        # Add the common input arguments
        self.add_common_arguments('post_instantiation hook for workflow')
        # Add additional arguments for instantiation
        self.add_additional_arguments()
        args = self.parser.parse_args()
        self.parsed_args = args
        self.cloud_type = self.get_cloud_type(args.vnf_instance_details_file)
        logger.debug('Loading vnf_instance_details_file: %r',
                     args.vnf_instance_details_file)
        if self.cloud_type == 'OPENSTACK':
            self.vnf_instance_file_parser = OpenstackJsonParser(
                args.vnf_instance_details_file
            )
        elif self.cloud_type == 'VMWARE':
            self.vnf_instance_file_parser = VCDXmlParser(
                args.vnf_instance_details_file
            )
        sc_ip, admin_username, dummy = \
            self.vnf_instance_file_parser.get_all_params()
        data = PostInstantiation.InputData(sc_ip,
                                           args.config_dir,
                                           args.key_file,
                                           admin_username,
                                           args.password_file,
                                           args.workflow_instance_identifier)

        logger.info('Input data: %r', data)
        return data


def main():
    post_instantiation = PostInstantiation()
    try:
        post_instantiation()
    except Exit as e:
        logger.error('Exiting (%d)', e.return_code)
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    logger = logging.getLogger('post_instantiation')
    main()

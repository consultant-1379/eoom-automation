#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""
from __future__ import print_function
import logging
import socket
import paramiko
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode


class CliExecutor:
    def __init__(self, ssh):
        self.ssh = ssh
        self.__logger = logging.getLogger('CliExecutor')

    def _run_ssh_command(self, script, fail_at_error):
        try:
            return self.ssh.run_command(script, fail_at_error=fail_at_error)
        except paramiko.SSHException as paramiko_ex:
            self.__logger.error("SSH connection failed!")
            print('SSH connection failed ({extype})! IP: {ip} User: {user}'.format(
                ip=self.ssh.ip,
                user=self.ssh.username,
                extype=paramiko_ex.__class__.__name__,
            ))
            print(' -- Waiting for O&M connection setup.')
            raise Exit(ReturnCode.REPEAT)
        except socket.error as socket_error:
            self.__logger.error("Socket error on SSH connection!")
            print("Socket error on SSH connection ({msg})! IP: {ip} User: {user}".format(
                ip=self.ssh.ip,
                user=self.ssh.username,
                msg=getattr(socket_error, 'strerror', 'unknown error'),
            ))
            print(' -- Waiting for O&M connection setup.')
            raise Exit(ReturnCode.REPEAT)

    def run_cli_remote(self, script):
        stdout, stderr, ret = self._run_ssh_command(script, False)
        if ret != 0:
            self.__logger.warning(
                ("Got %d return code running command '%s'. "
                 "Output: %s Stderr: %s"),
                ret, script, stdout, stderr)
            print('Remote command failed, retrying.')
            raise Exit(ReturnCode.REPEAT)
        return stdout

    @staticmethod
    def build_cliss_script(cliss_commands):
        script = '{ '
        for command in cliss_commands:
            script += "echo '" + command + "'; "
        script += "echo 'exit'; } | /opt/com/bin/cliss -sb"
        return script

    def run_cliss_remote(self, cliss_commands):
        script = self.build_cliss_script(cliss_commands)
        stdout, stderr, _ = self._run_ssh_command(script, True)
        if "ERROR" in stdout:
            self.__logger.error(
                ("Cliss output had an error when running command '%s'. "
                 "Output: %s"),
                script, stdout)
            raise Exit(ReturnCode.CLISS_ERROR)
        if stderr != "":
            self.__logger.error(
                ("Cliss printed to stderr while running command '%s'. "
                 "Output: %s Stderr: %s"),
                script, stdout, stderr)
            raise Exit(ReturnCode.CLISS_ERROR)
        return stdout.strip()

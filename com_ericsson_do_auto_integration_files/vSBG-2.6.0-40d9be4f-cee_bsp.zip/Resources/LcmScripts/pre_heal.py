#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import os
import sys
import time
import json
import logging

import heal_common

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode


logger = logging.getLogger('preheal')


class PreHeal(heal_common.HealHook):
    MIN_GRACE_PERIOD = 0
    DEFAULT_GRACE_PERIOD_TIME_SEC = 4 * 60
    MAX_GRACE_PERIOD = 15 * 60

    NO_ACTION_NEEDED = 101

    def __call__(self):
        self._parse_input_data_files()

        self.uuid_to_be_healed, self.name_to_be_healed = self.get_uuid_and_name_to_heal()
        logger.info('UUID to heal: %r', self.uuid_to_be_healed)
        if not self.uuid_to_be_healed:
            logger.error("UUID to be healed couldn't be found.")
            raise Exit(ReturnCode.INVALID_JSON)

        if self.args.auto_healing_info_file:
            self.handle_auto_healing_grace_period()

        output = {}
        output["UUIDToBeHealed"] = self.uuid_to_be_healed
        print(json.dumps(output))

    def check_autohealing_supported(self):
        supported = self._get_stack_output('autohealing_supported', as_str=True)
        if (supported is self.OUTPUT_KEY_NOT_FOUND or not
                supported or supported == 'false'):
            logger.error('Autohealing is not supported for this deployment!')
            raise Exit(ReturnCode.REJECT)

    def handle_auto_healing_grace_period(self):
        '''
        Waiting logic that tries to enter the node and REPEATs a few times
        before it eventually decides to continue with healing.
        If the node O&M becomes available before the grace time ends,
        and a health check reports all is okay, the script will exit
        and 'fail' so that the stack change will not happen.
        '''
        health_check_error = self.get_health_error()
        if health_check_error is None:
            logger.info(
                'Health check returned ok. No need for healing. Cancelling.')
            raise Exit(self.NO_ACTION_NEEDED)

        time_elapsed = self.get_time_elapsed_since_start()
        grace_period = self.get_grace_period()
        if time_elapsed < grace_period:
            logger.info('Still within grace period time')
            user_message = str.format(
                ("VM health not ok: {}. \nMaximum grace period left before "
                 "forcing healing: ~{}s. \nWaiting to see if node "
                 "recovers by itself."),
                health_check_error, int(grace_period - time_elapsed))
            print(user_message)
            raise Exit(ReturnCode.REPEAT)

        logger.info('Grace period time exceeded')
        logger.info('VM health is still not ok, forcing healing')

    def get_time_elapsed_since_start(self):
        '''
        Obtain the time by comparing current time to file creation time
        of input parameter files.
        '''
        ctime = os.path.getctime(self.args.vnf_instance_details_file)
        return time.time() - ctime

    def get_grace_period(self):
        timeout = self.auto_healing_info.get('gracePeriodBeforeHeal')
        if timeout is None:
            return self.DEFAULT_GRACE_PERIOD_TIME_SEC
        try:
            timeout = int(timeout)
        except ValueError:
            logger.error(
                "Invalid/missing value for 'gracePeriodBeforeHeal' value: %r",
                timeout)
            return self.DEFAULT_GRACE_PERIOD_TIME_SEC
        if not (self.MIN_GRACE_PERIOD <= timeout <= self.MAX_GRACE_PERIOD):
            logger.warning(
                "Invalid range for 'graceTimeoutForHeal', setting default")
            return self.DEFAULT_GRACE_PERIOD_TIME_SEC
        return timeout

    def check_health_in_cmw(self, cmw_status, name):
        try:
            for i in range(0, len(cmw_status), 3):
                if name in cmw_status[i] and 'OperState=DISABLED' in cmw_status[i + 2]:
                    return '{} is DISABLED in CoreMW'.format(name)
        except Exception:
            logger.error('Error in CoreMW output')
            raise Exit(ReturnCode.PARSE_ERROR)

        logger.info('%s is either not found or ENABLED in CoreMW', name)
        return None


def main():
    args = heal_common.argument_parsing()
    try:
        pre_heal = PreHeal(args)
        pre_heal()
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    main()

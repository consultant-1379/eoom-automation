#!/usr/bin/env python2
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------


from __future__ import absolute_import

import os
import subprocess

from .pdb_config_executor import PdbConfigExecutor


class PdbBackgroundExecutor(PdbConfigExecutor):

    def __init__(self, args):
        super(PdbBackgroundExecutor, self).__init__(args)
        self.log_file = None

    def execute(self):
        pfind = subprocess.Popen([
            'find', self.parsed_args.work_dir, '-iname', 'run_configure.sh'
        ], stdout=subprocess.PIPE)
        run_config_file = pfind.communicate()[0].strip()
        run_config_dir = os.path.dirname(run_config_file)
        os.chdir(run_config_dir)

        dev_null = open(os.devnull, 'wb')
        os.chmod('run_configure.sh', 0o777)
        run_cfg = subprocess.Popen([
            "./run_configure.sh"
        ], stdout=dev_null, close_fds=True)
        self.log_file = "%s/out.%d" % (run_config_dir, run_cfg.pid)
        return run_cfg.pid

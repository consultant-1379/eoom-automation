#!/usr/bin/env python2
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------


from __future__ import absolute_import

import argparse
import os
import shutil
import subprocess
import sys
from tarfile import TarFile
from zipfile import ZipFile


class PdbConfigExecutor(object):

    def __init__(self, args):
        self.parsed_args = None
        self.log_file = None
        self.parse_arguments(args)
        self.extract_files()

    def parse_arguments(self, args):
        parser = argparse.ArgumentParser(description="PdbConfigExecutor")
        parser.add_argument(
            '-f', '--archive-file',
            metavar='<ARCHIVE>',
            help='Path to the file containing the PDB configuration files.',
            required=True)
        parser.add_argument(
            '-wd', '--work-dir',
            metavar='<WORK DIRECTORY>',
            help='Path to extract the PDB archive to.',
            required=True)
        self.parsed_args = parser.parse_args(args)

    def extract_files(self):
        if os.path.isdir(self.parsed_args.work_dir):
            shutil.rmtree(self.parsed_args.work_dir)

        if self.parsed_args.archive_file.endswith(".zip"):
            archive = ZipFile(self.parsed_args.archive_file)
        else:
            archive = TarFile(self.parsed_args.archive_file)

        archive.extractall(self.parsed_args.work_dir)

    def execute(self):
        pfind = subprocess.Popen(
            [
                'find',
                self.parsed_args.work_dir,
                '-iname', 'run_configure.sh',
            ],
            stdout=subprocess.PIPE)
        run_config_file = pfind.communicate()[0].strip()
        run_config_dir = os.path.dirname(run_config_file)
        os.chdir(run_config_dir)

        os.chmod('run_configure.sh', 0o777)
        run_cfg = subprocess.Popen("./run_configure.sh", stdout=open(os.devnull, 'wb'))
        run_cfg.communicate()
        self.log_file = "%s/out.%d" % (run_config_dir, run_cfg.pid)
        return run_cfg.returncode


if __name__ == "__main__":
    pce = PdbConfigExecutor(sys.argv[1:])
    pce.execute()

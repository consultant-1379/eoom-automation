#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------


import sys

from imscommon.consts import ReturnCode

if __name__ == '__main__':
    sys.exit(ReturnCode.SUCCESS)

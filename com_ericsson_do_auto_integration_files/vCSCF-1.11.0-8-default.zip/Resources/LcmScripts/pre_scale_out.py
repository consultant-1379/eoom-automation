#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# pylint: disable=C0111

# Continue refactoring these:
# R1702(too-many-nested-blocks), R0904(too-many-public-methods), W0141(use-builtin-function filter)
# pylint: disable=R0904

# Workaround:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311

from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import re

from common import setup_default_logging
from imscommon.consts import ReturnCode
from imscommon.parsers import VCDXmlParser
from lcmUtilities.lcm_decorators import skippable
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig
from scale_base import ScaleLcmBaseTask


class PreScaleOut(ScaleLcmBaseTask):
    def __init__(self):
        super(PreScaleOut, self).__init__()
        self.log = LcmOutputManager(tag="vCSCF-PreScaleOut")
        self.config = self.argument_parsing()
        self.log.tag = "vCSCF-PreScaleOut.%s" % self.config.stack_name

        self.ssh = self.connect_with_config()
        self.create_vnflcm_dir()
        self.read_state_file("pre_scale_in")

    def do_pre_scale_out(self):
        self.check_preconditon_step()
        if self.config.is_openstack:
            output = {self.SCALED_NUMBER_VAR_NAME: self.config.number_of_steps + self.config.number_of_scaled_out_vms}
            self.log.info(json.dumps(output))
        else:
            output = {'number_of_vms_to_be_added': self.config.number_of_steps}
            self.log.info(json.dumps(output))

        self.rm_work_dir()
        self.log.debug("PreScaleOut done.")
        self.quit_with_code(ReturnCode.SUCCESS)

    @skippable
    def check_preconditon_step(self):
        """
        Checks for scale out precondition, only run on first invocation, since scaling is started at that point,
        so there is no point checking again if we can start.
        """
        if not self.check_crm_status():
            self.log.error("Scaling out is not possible because the internal CrM node state in is not ok. "
                           "Hint: 1) Check CSCF troubleshooting guide")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        if not self.check_vdicos_status():
            self.log.error("Scaling in is not possible because the internal vDicos state is not ok. "
                           "Hint: 1) Check CSCF troubleshooting guide")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.update_state_file("check_preconditon_step")

    def graceful_cancel(self):
        self.quit_with_code(ReturnCode.REJECT)

    def argument_parsing(self):
        parser = PreScaleOut.argmunet_parsing_base(description='pre_scale_out hook for workflow')
        parser.add_argument('-n', '--number-of-steps', metavar='<STEPS>',
                            help='Number of scaling steps.', type=int, required=True)
        parser.add_argument('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
                            help='All additional parameters in json format.', type=str, required=False)
        parser.add_argument('-x', '--aspect-id', metavar='<ASPECT_ID>',
                            help='The aspect ID of the scaling domain to scale.', type=str, required=False)
        parser.add_argument('-l', '--auto-scale-info-file', metavar='<AUTO_SCALE_INFO_FILE>',
                            help='Auto Scale information parameters.', type=str, required=False)
        args = parser.parse_args()
        if args.stack_details_file.endswith('.xml'):
            self.log.debug("Parsing XML config file: %s" % args.stack_details_file)
            config = self.parse_vcd_xml_file(args.stack_details_file)
        else:
            self.log.debug("Parsing JSON config file: %s" % args.stack_details_file)
            config = self.parse_openstack_json_file(args.stack_details_file)

        config.workflow_instance_identifier = args.workflow_instance_identifier
        config.emergency_username = self.get_value_or_fallback_on_none(args.user_name, config.emergency_username)
        config.key_file = args.key_file
        config.password_file = args.password_file
        config.number_of_steps = args.number_of_steps
        if args.auto_scale_info_file:
            self.log.debug("Auto scale file: %s" % args.auto_scale_info_file)
            with open(args.auto_scale_info_file) as auto_scale_info_json_file:
                auto_scale_info_params = json.load(auto_scale_info_json_file)
                additional_info = auto_scale_info_params.get('additionalInformation', '')
                self.log.debug("argument_parsing: additional_info '%s'" % additional_info)
                pattern = re.compile('.*CSCF Time Based Scale Out. (?P<num>\\d*).*')
                match = pattern.search(additional_info)
                if match is None:
                    self.log.error("Autoscale alarm cannot be parsed")
                    self.quit_with_code(ReturnCode.REJECT)
                wanted_cluster_size = int(match.group('num'))
                cluster_size = config.number_of_scaled_out_vms + 2
                if cluster_size >= wanted_cluster_size:
                    self.log.error("Autoscale request to scale out to %s PLs but there are already %s PLs" %
                                   (wanted_cluster_size, cluster_size))
                    self.quit_with_code(ReturnCode.REJECT)
                config.number_of_steps = wanted_cluster_size - cluster_size
        self.log.debug("Parameters parsed from config: %s" % config)
        self.config = config
        self.check_if_canceled(args)
        return config

    def parse_openstack_json_file(self, config_file):
        with open(config_file) as json_file_handle:
            config_data = json.load(json_file_handle)

        config = LcmTaskConfig(is_openstack=True)
        try:
            stack_params = config_data["stack"]["parameters"]
            config.stack_name = config_data["stack"]["stack_name"]
            config.emergency_username = stack_params["emergency_username"].strip()
            config.mip = self.get_value_or_fallback_on_match(
                stack_params["OM_IPv4_address"].strip(),
                stack_params["OM_IPv6_address"].strip(), "none")
            config.number_of_scaled_out_vms = int(stack_params[self.SCALED_NUMBER_VAR_NAME].strip())
        except KeyError as ex:
            self.log.error("A field is missing from the JSON file: %s" % ex)
            self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)
        return config

    def parse_vcd_xml_file(self, config_file):
        parser = VCDXmlParser(config_file)
        v_app = parser.vnf_status_file
        v_app_name = v_app.attrib.get("name")
        if v_app_name is None:
            self.log.error("Could not fetch 'name' parameter while parsing input data")
            self.handle_config_file_error(config_file)

        config = LcmTaskConfig(is_openstack=False)
        config.stack_name = v_app_name
        config.emergency_username = parser.get_property("emergency_username").strip()
        config.mip = self.get_value_or_fallback_on_match(
            parser.get_property('OM_IPv4_address').strip(),
            parser.get_property('OM_IPv6_address').strip(), "none")
        vm_list = parser.get_vm_name_list()
        filtered_vm_list = {}
        vm_number_pattern = re.compile("^.*-(?P<vm_num>\\d+)$")
        for vm_name in vm_list:
            if self.is_scalable_node(vm_name):
                match = vm_number_pattern.search(vm_name)
                if not match:
                    self.log.error("Can not extract VM number from [%s]" % vm_name)
                    self.quit_with_code(ReturnCode.VM_NR_ERROR)
                vm_num = self.string_to_int(match.group('vm_num'))
                filtered_vm_list[vm_name] = vm_num

        config.number_of_scaled_out_vms = len(filtered_vm_list)
        return config


if __name__ == '__main__':
    # C0103(invalid-name)
    # pylint: disable=C0103
    setup_default_logging()
    pre_scale_out = PreScaleOut()
    pre_scale_out.do_pre_scale_out()

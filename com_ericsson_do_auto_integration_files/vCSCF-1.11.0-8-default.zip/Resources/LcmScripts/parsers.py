#!/usr/bin/env python2
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------


from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import logging
import xml.etree.ElementTree as Etree

from imscommon.consts import ReturnCode
from imscommon.exceptions import Exit


class VNFStatusParser(object):
    def __init__(self, filename, log_id):
        self._logger = logging.getLogger(log_id)
        self.vnf_status_file = self.parse_vnf_status_file(filename)

    def parse_vnf_status_file(self, filename):
        raise NotImplementedError()

    def get_admin_username(self):
        raise NotImplementedError()

    def get_oam_public_ip(self):
        raise NotImplementedError()

    def get_payload_instance_count(self):
        raise NotImplementedError()

    def get_uuid_count(self):
        raise NotImplementedError()

    def get_vnf_name(self):
        raise NotImplementedError()

    def get_mac_to_vm_name_dict(self):
        raise NotImplementedError()

    def get_vm_name_list(self):
        raise NotImplementedError()


class OpenstackJsonParser(VNFStatusParser):

    def __init__(self, filename):
        super(OpenstackJsonParser, self).__init__(filename, self.__class__.__name__)

    def parse_vnf_status_file(self, filename):
        try:
            with open(filename) as json_file:
                return json.load(json_file)
        except ValueError:
            self._logger.error("Input JSON file is invalid: %s " % filename)
            raise Exit(ReturnCode.INVALID_JSON)

    def get_payload_instance_count(self):
        try:
            parameters = self.vnf_status_file["stack"]["parameters"]
            payload_instance_count = int(parameters["payload_instance_count"])
            if payload_instance_count < 0:
                self._logger.error("payload_instance_count field is negative!")
                raise Exit(ReturnCode.INVALID_PAYLOAD_INSTANCE_COUNT)
            return payload_instance_count
        except KeyError:
            self._logger.error("Missing payload_instance_count field!")
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)
        except ValueError:
            self._logger.error("Invalid payload_instance_count field!")
            raise Exit(ReturnCode.INVALID_PAYLOAD_INSTANCE_COUNT)

    def get_admin_username(self):
        try:
            return self.vnf_status_file["stack"]["parameters"]["admin_username"]
        except KeyError:
            self._logger.error("Missing admin_username field!")
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

    def get_oam_public_ip(self):
        try:
            obj = self.vnf_status_file["stack"]["outputs"]
            for x in obj:
                if x["output_key"] == "oam_public_ip":
                    return x["output_value"].strip()
        except KeyError:
            self._logger.error("Badly formatted stack details json.")
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)
        self._logger.error("Missing oam_public_ip field!")
        raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

    def get_uuids(self):
        uuids = []
        try:
            obj = self.vnf_status_file["stack"]["outputs"]
            for x in obj:
                if x["output_key"] == "resource_list":
                    uuids = x["output_value"].strip().split()
        except KeyError as ex:
            self._logger.error("A field is missing from the JSON file: %s", ex)
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        return uuids

    def get_uuid_count(self):
        return len(self.get_uuids()) + 1

    def get_all_params(self):
        return self.get_oam_public_ip(), self.get_admin_username(), self.get_uuids()

    def get_vnf_name(self):
        return self.vnf_status_file["stack"]["stack_name"]


# noinspection PyBroadException
class VCDXmlParser(VNFStatusParser):
    NAMESPACES = {'vcloud': '{http://www.vmware.com/vcloud/v1.5}',
                  'ovf': '{http://schemas.dmtf.org/ovf/envelope/1}',
                  'vssd': 'http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_VirtualSystemSettingData',
                  'rasd': '{http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_ResourceAllocationSettingData}',
                  'vmw': '{http://www.vmware.com/schema/ovf}',
                  'xsi': '{http://www.w3.org/2001/XMLSchema-instance}'}

    def __init__(self, filename):
        super(VCDXmlParser, self).__init__(filename, self.__class__.__name__)

    @staticmethod
    def replace_xpath_namespaces(xpath):
        for ns in VCDXmlParser.NAMESPACES:
            xpath = xpath.replace(ns + ':', VCDXmlParser.NAMESPACES[ns])

        return xpath

    def get_uuid_count(self):
        xpath = './/vcloud:Vm'
        return len(self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath)))

    def get_property(self, prop_name):
        xpath = './/ovf:ProductSection//ovf:Property'
        properties = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))
        result_property = None
        for prop in properties:
            if prop.attrib.get(self.replace_xpath_namespaces('ovf:key')) == prop_name:
                result_property = prop
                break
        if result_property is None:
            self._logger.error(prop_name + " property not found in XML.")
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)
        for child in result_property:
            if child.tag == self.replace_xpath_namespaces('ovf:Value'):
                return child.attrib.get(self.replace_xpath_namespaces('ovf:value'))

        return result_property.attrib.get(self.replace_xpath_namespaces('ovf:value'))

    def get_admin_username(self):
        return self.get_property('Username')

    def get_oam_public_ip(self):
        return self.get_property('MIP_IPaddress')

    def get_all_params(self):
        return self.get_oam_public_ip(), self.get_admin_username()

    def parse_vnf_status_file(self, filename):
        try:
            tree = Etree.parse(filename)
            return tree.getroot()
        except Exception:
            self._logger.error("Failed to parse VCD XML file!")
            raise Exit(ReturnCode.INVALID_JSON)

    def get_vnf_name(self):
        return self.vnf_status_file.attrib['name']

    def get_mac_to_vm_name_dict(self):

        result = {}

        xpath = './/vcloud:Vm'
        vms = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))
        xpath2 = './/rasd:Address'
        try:
            for vm in vms:
                name = vm.attrib.get(self.replace_xpath_namespaces('name'))
                self._logger.debug("getMactoVmNameDict processing VM [" + name + "]")
                addresses = vm.findall(self.replace_xpath_namespaces(xpath2))
                for address in addresses:
                    self._logger.debug("getMacToVmNameDict MAC [%s] belongs to VM [%s]" % (address, name))
                    result[address] = name

        except KeyError as ex:
            self._logger.error("A field is missing from the XML file: %s", ex)
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        self._logger.debug("getMacToVmNameDict result [" + str(result) + "]")
        return result

    def get_vm_name_to_mac_dict(self):
        result = {}
        xpath = './/vcloud:Vm'
        vms = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))
        xpath2 = './/rasd:Address'
        try:
            for vm in vms:
                tmp = []
                name = vm.attrib.get(self.replace_xpath_namespaces('name'))
                self._logger.debug("getVmNameToMacDict processing VM [" + name + "]")
                addresses = vm.findall(self.replace_xpath_namespaces(xpath2))
                for address in addresses:
                    tmp.append(address.text)
                self._logger.debug("getVmNameToMacDict VM name [%s] has MAC addresses [%s]" % (addresses, tmp))
                result[name] = tmp

        except KeyError as ex:
            self._logger.error("A field is missing from the XML file: %s", ex)
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        self._logger.debug("getVmNameToMacDict result [" + str(result) + "]")
        return result

    def get_vm_name_to_id_dict(self):
        result = {}
        xpath = './/vcloud:Vm'
        vms = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))
        try:
            for vm in vms:
                name = vm.attrib.get(self.replace_xpath_namespaces('name'))
                vm_id = vm.attrib.get(self.replace_xpath_namespaces('id'))
                self._logger.debug("getVmNameToIdDict processing VM [%s] with id/uuid [%s]" % (name, vm_id))
                result[name] = vm_id

        except KeyError as ex:
            self._logger.error("A field is missing from the XML file: %s" % ex)
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        self._logger.debug("getVmNameToIdDict result [%s]" % result)
        return result

    def get_vm_name_list(self):
        result = []
        xpath = './/vcloud:Vm'
        vms = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))
        try:
            for vm in vms:
                name = vm.attrib.get(self.replace_xpath_namespaces('name'))
                result.append(name)
                self._logger.debug("getVmNameList adding VM [%s]" % name)

        except KeyError as ex:
            self._logger.error("A field is missing from the XML file: %s" % ex)
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        self._logger.debug("getVmNameList returning [%s]" % result)
        return result


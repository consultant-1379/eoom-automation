#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import os
import re
import shutil
import subprocess
import time
import lxml.etree as etree

from paramiko import AuthenticationException

from common import CommonLcmTask, ReturnCode, setup_default_logging
from lcmUtilities.pdb_background_executor import PdbBackgroundExecutor
from lcmUtilities.lcm_decorators import skippable
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig
from parsers import VCDXmlParser


# noinspection PyBroadException
class PostInstantiation(CommonLcmTask):

    CONFIG_KEYS = ("nels_host", "nels_port",
                   "emergency_username", "emergency_password_hash",
                   "secla_password_hash", "root_password_hash")

    def __init__(self):
        super(PostInstantiation, self).__init__()
        self.esm_time = None
        self.pdb_pid_data = {}
        self.log = LcmOutputManager(tag="vCSCF-PostInstantiation")
        self.config = self.argument_parsing()
        self.log.tag = "vCSCF-PostInstantiation.%s" % self.config.stack_name

        try:
            self.connect_to_host(host=self.config.mip, username="root", password="rootroot")
        except AuthenticationException:
            self.log.info("Root login disabled, logging in with %s user" % self.config.emergency_username)
            self.connect_with_config()
        except Exception as err:
            self.log.info("Connecting to host is not yet successful")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.REPEAT)

        self.create_vnflcm_dir()
        self.read_state_file("post_instantiation")

    def do_post_instantiation_steps(self):
        self.waiting_for_cmw_status_ok()
        self.check_cmw_status_node_su_sg()

        # Do actual work steps, can update state, short circuit on re-invocation when task is already done
        self.check_esm_image_step()  # should come after state file?
        # self.check_and_apply_cpu_smap()
        self.initiate_com_switchover_step()
        self.verify_com_switchover_step()
        self.update_lm_config_step()
        self.configure_nels_step()
        self.add_emergency_user_step()
        self.change_secla_password_step()
        self.apply_pdb_step()
        self.activate_evip_albs_step()
        # missing enable scaling?

        # Finalize and cleanup
        self.disable_root_login_step()  # cluster config reload needed
        self.change_root_password_step()
        self.create_backup_step()
        self.check_backup_complete_step()
        self.finalize_configuration()

    def pdb_pid_data_file(self):
        return "%s/pdb_pid_data" % self.lcm_work_dir()

    def waiting_for_cmd_status_ok(self, p_cmd, p_retry_loop=20, p_sleep=5):
        self.log.debug("Waiting for %s status OK..." % p_cmd)
        for l_attempt in range(1, p_retry_loop):
            try:
                self.ssh.run_command(p_cmd)
                self.log.debug("cmd status is OK")
                return "OK"
            except Exception as err:
                self.log.debug("cmd status is NOT OK, retry... %d/%d" % (l_attempt, p_retry_loop))
                self.log.debug("Exception: %s" % err)
                time.sleep(p_sleep)
        self.log.warning(p_cmd + " status is NOT OK")
        return "NOT OK"

    def waiting_for_cmw_status_ok(self, retry_loop=10):
        state = self.waiting_for_cmd_status_ok("cmw-status node", p_retry_loop=retry_loop)
        if state == "NOT OK":
            self.log.info("Waiting for CoreMW")
            self.quit_with_code(ReturnCode.REPEAT)

    def check_cmw_status_node_su_sg(self, p_retry=9):
        cmd = "cmw-status node su sg"
        for _ in range(p_retry):
            try:
                stdout, _, _ = self.ssh.run_command(cmd)
                lines = stdout.split("\n")
                if lines[0] == "Status OK":
                    self.log.info("cmw-status is OK")
                    return
            except Exception:
                self.log.info("cmw-status is not OK")
                self.quit_with_code(ReturnCode.REPEAT)

        self.log.info("cmw-status is not OK")
        self.quit_with_code(ReturnCode.REPEAT)

    def is_esm(self):
        _, _, code = self.ssh.run_command(
            "test -e /cluster/storage/system/config/lde/csm/finalized/csm.yml", fail_at_error=False)
        return code == 0

    def esm_timer_file(self):
        return "%s/post_install_esm_timer" % self.lcm_work_dir()

    def read_esm_timer_file(self):
        timer = self.read_vnflcm_file(self.esm_timer_file())
        self.esm_time = time.time() if timer is None else float(timer)

    def update_esm_timer_file(self):
        if os.path.exists(self.esm_timer_file()):
            self.log.debug("ESM timer file already exist")
            return False

        self.write_vnflcm_file(str(time.time()), self.esm_timer_file())
        return True

    @skippable
    def check_esm_image_step(self):
        if self.is_esm():
            self.update_esm_timer_file()
            self.check_esm_image_status()
        else:
            self.log.info("Not ESM image")
        self.update_state_file("check_esm_image_step")

    def check_esm_image_status(self):
        _, _, code = self.ssh.run_command(
            'grep "Offline Instantiation was successful" /var/log/SC-*/messages*', fail_at_error=False)
        if code:
            self.read_esm_timer_file()
            if time.time() - self.esm_time >= 1200:  # 20 minutes timeout? why?
                self.log.error("ESM installation status timeout. Exiting Installation...")
                self.quit_with_code(ReturnCode.RETURN_ERROR)

            self.log.info("ESM installation ongoing be patient")
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.info("ESM installation successful")

    @skippable
    def initiate_com_switchover_step(self):
        self.log.info("Initiating COM Switchover")
        try:
            self.ssh.run_command("nohup comsa-mim-tool com_switchover &> /tmp/com_switchover_result &")
        except Exception:
            self.log.error("COM switchover failed")
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.update_state_file("initiate_com_switchover_step")
        self.log.debug("COM Switchover started. Returning with repeat.")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    def verify_com_switchover_step(self):
        self.log.info("Verifying COM Switchover")
        MAX_ATTEMPTS = 10

        com_result = self.run_com_cli_command("show ManagedElement=1,CscfFunction=1", configure_mode=False)
        self.log.debug("COM result: [%s]" % com_result)

        # CscfFunction applications
        app_list = ["CSCF-Application=CSCF",
                    "CscfDomainRoutingApplication=CscfDomainRouting",
                    "CscfEosApplication=CscfEos",
                    "DIA-CFG-Application=DIA",
                    "DNS-Application=DNS",
                    "ExtNetSel-Application=ExtNetSelection",
                    "ExtNetSel-Application=ExtNetSelection2",
                    "ICMP-Application=ICMP",
                    "LdapClientApplication=LdapClientApplication",
                    "LI-Application=LI",
                    "NumberNormalisation=NumberNormalisation",
                    "SigComp-Subsystem=SigComp"]

        for app in app_list:
            if app not in com_result:
                self.log.info("Not all CSCF applications are under CscfFunction yet. [%s] is missing in [%s]" %(app, com_result))
                if self.can_iterate_step("verify_the_com_switchover_step", MAX_ATTEMPTS):
                    self.log.debug("Returning with repeat.")
                    self.quit_with_code(ReturnCode.REPEAT)
                self.log.error("Failed to verify COM switchover. [%i] attempts done." % MAX_ATTEMPTS)
                self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.update_state_file("verify_com_switchover_step")
        self.log.info("All CSCF applications are now visible through COM")

    @skippable
    def check_and_apply_cpu_smap(self):
        self.log.info("Check and apply CPU smap")

        stdout, stderr, retcode = self.ssh.run_command("lscpu | grep smap", fail_at_error=False)
        if retcode == 1:
            self.log.info("CPU smap config needed")
            try:
                self.ssh.run_command(
                    "sed -i 's/rootfstype=ramfs/& nosmap/' /boot/grub2/grub.cfg")
                self.log.info("Grub config updated")
                self.update_state_file("check_and_apply_cpu_smap")
                return
            except Exception:
                self.log.error("Updating /boot/grub2/grub.cfg failed")
                # TODO: Fail?
                return
        self.log.debug("CPU smap check done. No update needed.")

    def reload_and_apply_cluster_conf(self):
        self.log.info("Reload/apply cluster config")
        self.cp_file("/cluster/etc/cluster.conf", "/boot/.cluster.conf")
        try:
            self.ssh.run_command("cluster config -r")
        except Exception as err:
            self.log.error("Reload/apply cluster config failed, configuration incomplete")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def validate_cluster_conf(self):
        self.log.info("Validate cluster config")
        _, stderr, code = self.ssh.run_command("cluster config -v", fail_at_error=False)
        if code != 0:
            self.log.error("Validate cluster config failed: %s" % stderr)
            self.mv_file("/cluster/etc/cluster.conf.org", "/cluster/etc/cluster.conf")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.log.info("Cluster config is valid")
        self.rm_file("/cluster/etc/cluster.conf.org")

    @skippable
    def update_lm_config_step(self):
        """
        removes template parameters from the mentioned xml.
        e.g. <Path>%{LM_NeLS_SSL_ca_file}</Path> --> <Path></Path>
        :return:
        """
        self.log.info("Updating certificate_config.xml")
        _, stderr, code = self.ssh.run_command(
            "sed -i s/%\\{.*\\}// /cluster/storage/system/config/lm-apr9010503/certs/certificate_config.xml",
            fail_at_error=False)
        if code != 0:
            self.log.error("Error when updating certificate_config.xml: %s" % stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.update_state_file("update_lm_config_step")
        self.log.info("Updating certificate_config.xml done.")

    @skippable
    def configure_nels_step(self):
        self.log.info("Configure NeLS (%s:%s)" % (self.config.nels_host, self.config.nels_port))
        command = "ManagedElement=1,SystemFunctions=1,Lm=1,NeLSConfiguration=1,host=%s" % self.config.nels_host
        command += "\nManagedElement=1,SystemFunctions=1,Lm=1,NeLSConfiguration=1,port=%s" % self.config.nels_port
        com_result = self.run_com_cli_command(command)
        self.log.error("Failed to configure NeLS") if com_result is None else self.log.info("NeLS configuration done")
        self.update_state_file("configure_nels_step")

    def configure_emergency_user_account(self):
        _, stderr, code = self.ssh.run_command(
            "useradd -G com-emergency,system-ts " + self.config.emergency_username, fail_at_error=False)
        if code not in (0, 9):  # 0 success; 9 exists
            self.log.error("Adding emergency user failed")
            self.log.debug(stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.ssh.run_command(
            "lde-global-user -u " + self.config.emergency_username, fail_at_error=False)
        try:
            self.ssh.run_command(
                "usermod -p '%s' %s" % (self.config.emergency_password_hash, self.config.emergency_username))
        except Exception as err:
            self.log.error("Adding emergency user failed")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def enable_user_access(self, username):
        _, _, code = self.ssh.run_command(
            "grep %s /cluster/etc/login.allow" % username, fail_at_error=False)
        if code == 1:
            _, stderr, code = self.ssh.run_command(
                'echo "%s all" >> /cluster/etc/login.allow' % username)
            if code != 0:
                self.log.error("Adding %s user failed" % username)
                self.log.debug(stderr)
                self.quit_with_code(ReturnCode.RETURN_ERROR)

    def configure_emergency_user_ssh(self):
        self.log.info("Configure emergency user")
        # configure ssh-keys for internal use (needed for some internal commands)
        # add suppressing confusing SSH printouts
        try:
            self.ssh.run_command(
                "su - " + self.config.emergency_username + " -c " + "\"" +
                "mkdir -p .ssh; " +
                "ssh-keygen -f .ssh/id_rsa -t rsa -N ''; " +
                "cat .ssh/id_rsa.pub >> .ssh/authorized_keys; " +
                "echo -e 'localhost\nsc-1\nsc-2' >> .shosts; " +
                "echo -e 'Host *\nHostbasedAuthentication no' >> .ssh/config" +
                "\" ")
        except Exception:
            self.log.error("Emergency user SSH configuration failed")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def add_vnflcm_key(self):
        self.log.info("Add VNF-LCM's key to emergency user")
        public_key_file = "%s.pub" % self.config.key_file
        if not os.path.isfile(public_key_file):
            self.log.info("Public key file can't be found at private key location, trying config-dir ...")
            public_key_file = "%s/id_rsa.pub" % self.config.config_dir
        if not os.path.isfile(public_key_file):
            self.log.error("No public key found.")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        try:
            self.ssh.send_file(public_key_file, "/tmp/id_rsa.pub")
            self.ssh.run_command("su - %s -c 'mkdir -p .ssh'" % self.config.emergency_username)
            self.ssh.run_command(
                "su - %s -c 'cat /tmp/id_rsa.pub >> .ssh/authorized_keys'" % self.config.emergency_username)
            self.ssh.run_command("rm -f /tmp/id_rsa.pub")
        except Exception as err:
            self.log.error("Add VNF-LCM's key to emergency user failed")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.log.info("Add VNF-LCM's key to emergency user done")

    @skippable
    def add_emergency_user_step(self):
        self.log.info("Adding emergency user")
        self.configure_emergency_user_account()
        self.enable_user_access(self.config.emergency_username)
        self.configure_emergency_user_ssh()
        self.add_vnflcm_key()
        self.update_state_file("add_emergency_user_step")
        self.log.info("Emergency user added successfully")

    def secla_psw_change(self):
        slp_cmd = "$(printf '%%q ' /opt/eric/sec-la-cxp9026994/bin/sec-la-passwd la-admin -h '%s')" % (
                  self.config.secla_password_hash)
        for controller in ['sc-1', 'sc-2']:
            # this needs to be done on a specific SC, which may, or may not, be the active SC...
            _, _, code = self.ssh.run_command("ssh %s ps -ef | grep slapd | fgrep -v grep" % controller,
                                              fail_at_error=False)
            if not code:
                _, _, code = self.ssh.run_command('ssh %s "%s"' % (controller, slp_cmd), fail_at_error=False)
                if not code:
                    self.log.info("SEC-LA password change succeeded")
                    return
                self.log.debug("SEC-LA command failed on %s" % controller)

        self.log.error("SEC-LA password change failed")
        self.quit_with_code(ReturnCode.RETURN_ERROR)

    @skippable
    def change_secla_password_step(self):
        self.log.info("Change default SEC-LA password")
        self.secla_psw_change()
        self.update_state_file("change_secla_password_step")
        self.log.info("SEC-LA password changed")

    @skippable
    def change_root_password_step(self):
        self.log.info("Changing root password")
        try:
            self.ssh.run_command("usermod -p '%s' root; cluster config -r -a" % self.config.root_password_hash)
        except Exception as err:
            self.log.error("Changing root password failed")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.log.info("root password changed")
        self.update_state_file('change_root_password_step')

    @skippable
    def disable_root_login_step(self):
        self.log.info("Disabling root login")
        _, _, code = self.ssh.run_command(
            'grep "^ssh.rootlogin all off" /cluster/etc/cluster.conf', fail_at_error=False)
        if code:
            _, stderr, code = self.ssh.run_command(
                "sed -i -e '0,/^# ssh listening networks/s/# ssh listening networks/# "
                "ssh root login\\nssh.rootlogin all off\\n\\n&/' /cluster/etc/cluster.conf",
                fail_at_error=False)
            if code != 0:
                self.log.error("Updating cluster.conf failed")
                self.log.debug(stderr)
                self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.log.info("Disabling root login done")
        self.update_state_file('disable_root_login_step')

    def get_evip_albs(self):
        evip_albs = []
        cmd = "show ManagedElement=1,Transport=1,Evip=1,EvipAlbs=1 -m EvipAlb -p state"
        com_result = self.run_com_cli_command(cmd, configure_mode=False)
        if com_result is None:
            self.log.error("Could not fetch Evip Albs from COM")
            self.quit_with_code(ReturnCode.MO_INSTANCE_ERROR)

        for match in re.finditer('^EvipAlb=(?P<alb>.+?)$\\s+state="(?P<state>.+?)"$', com_result, re.MULTILINE):
            self.log.debug("EvipAlb: %s state: %s" % (match.group('alb'), match.group('state')))
            evip_albs.append(match.group('alb'))

        return evip_albs

    @skippable
    def activate_evip_albs_step(self):
        evip_albs = self.get_evip_albs()
        if not evip_albs:
            self.log.info("No EvipAlbs found, leaving %s LOCKED" % CommonLcmTask.ADMIN_STATE_NAME)
            self.update_state_file("activate_evip_albs_step")
            self.quit_with_code(ReturnCode.REPEAT)

        for evip_alb in evip_albs:
            com_res = self.run_com_cli_command(
                "ManagedElement=1,Transport=1,Evip=1,EvipAlbs=1,EvipAlb=%s,activate" % evip_alb, configure_mode=False)
            if com_res is None:
                self.log.error("Could not activate Evip Alb: %s" % evip_alb)
                self.quit_with_code(ReturnCode.MO_INSTANCE_ERROR)

        self.ensure_admin_state_unlocked()
        self.log.info("All EvipAlbs are active")
        self.update_state_file("activate_evip_albs_step")
        self.quit_with_code(ReturnCode.REPEAT)

    def handle_pdb_error_xml(self, rpc_error, pdb_log_file, pdb_file):
        """
        Check the error-tag value in the rpc-error tag, and attempt to re-run the import tasks 10 times before
        giving up if error type was resource-denied.
        (Resource denied case might suggest that the VNF is not yet in a state where it can accept the configuration.)
        """
        error_tag = rpc_error.find('{*}error-tag')
        if error_tag.text == "resource-denied" and self.can_iterate_step("handle_pdb_error_%s" % pdb_file, 10):
            self.log.error("PDB configuration pending")
            self.run_pdb_background_importer(pdb_file)
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.error("Application configuration with pdb failed! Check PDB log file: %s" % pdb_log_file)
        self.quit_with_code(ReturnCode.RETURN_ERROR)

    def check_pdb_precondition(self):
        """
        Attempt to check if node is ready to accept the configuration.
        This might require additional checks.
        """
        admin_state = self.read_admin_state()
        if admin_state not in ('LOCKED', 'UNLOCKED'):
            self.log.info('Application is not ready for configuration.')
            self.quit_with_code(ReturnCode.REPEAT)

    def save_pdb_file_pid(self, pdb_file_name, pid, log):
        self.pdb_pid_data[pdb_file_name] = {
            'pid': pid,
            'log': log
        }
        self.write_vnflcm_file(json.dumps(self.pdb_pid_data), self.pdb_pid_data_file())

    def read_pdb_pid_data(self):
        data = self.read_vnflcm_file(self.pdb_pid_data_file())
        self.pdb_pid_data = json.loads(data.split("\n")[0]) if data else {}

    def check_pdb_background_process(self, pdb_file, pdb_info):
        """
        Try to check process status by PID by sending a kill signal 0.
        If this throws an OSError, that means the process already quit, or its owned by some other user.
        In both cases we should check the logs left by the import, to check for errors.
        """
        self.log.debug("check_pdb_background_process [%s] [%s]" % (pdb_file, pdb_info))
        try:
            os.kill(pdb_info['pid'], 0)
        except OSError:
            self.check_pdb_run_for_error(pdb_file, pdb_info['log'])
        else:
            self.log.info("PDB import is ongoing [%s]" % os.path.basename(pdb_file))
            self.quit_with_code(ReturnCode.REPEAT)

    def check_pdb_run_for_error(self, pdb_file, log_file_name):
        """ Parse the rpc-reply sections of the log file as xml, and check if there was any <rpc-error> """
        with open(log_file_name) as log_file:
            log_text = log_file.read()

        pattern = '^<\\?xml version="1\\.0" encoding="UTF-8"\\?>$\n^<rpc-reply.*?</rpc-reply>$'
        matches = re.findall(pattern, log_text, re.MULTILINE | re.DOTALL)

        pdb_file_name = os.path.basename(pdb_file)
        log_dir = "/tmp/%s_pdb_import" % self.config.workflow_instance_identifier
        if not matches:
            self.log.error("PDB import failed [%s]. No rpc-reply found in logs. Check configtool-*.log in %s dir" %
                           (pdb_file_name, log_dir))
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        for xml in matches:
            rpc_reply = etree.fromstring(xml)
            for reply in rpc_reply:
                if self.trim_namespace(reply.tag) == 'rpc-error':
                    self.handle_pdb_error_xml(reply, log_file_name, pdb_file)

        self.update_state_file("pdb_import__%s__done" % pdb_file_name)
        self.log.info("PDB import done [%s]" % pdb_file_name)
        self.quit_with_code(ReturnCode.REPEAT)

    @staticmethod
    def trim_namespace(ns_string):
        """ Remove namespace from the xml tag name """
        return re.match('{.*}(.*)', ns_string).group(1)

    def run_pdb_background_importer(self, pdb_file):
        pdb_work_dir = "/tmp/%s_pdb_import" % self.config.workflow_instance_identifier
        pdb_exec = PdbBackgroundExecutor(['-f', pdb_file, '-wd', pdb_work_dir])
        pid = pdb_exec.execute()
        self.log.debug("PDB executor pid is [%s], log file is at: [%s]" % (pid, pdb_exec.log_file))
        pdb_file_name = os.path.basename(pdb_file)
        self.save_pdb_file_pid(pdb_file_name, pid, pdb_exec.log_file)

    def cleanup_pdb_work_dir(self):
        pdb_work_dir = "/tmp/%s_pdb_import" % self.config.workflow_instance_identifier
        if os.path.isdir(pdb_work_dir):
            shutil.rmtree(pdb_work_dir)

    @skippable
    def apply_pdb_step(self):
        """
        Try to apply all PDB files in the config folder.

        This method will launch all pdb import tasks sequentially in the background, checking the PID
        of the import process on subsequent runs to see if the import task was finished.

        Upon completion the log is examined to see if there was any rpc-error during the operation,
        and if there was the import task will be re-applied with a 10 attempt timeout.
        """
        find_process = subprocess.Popen(['find', self.config.config_dir, '-iname', '*.zip', '-printf', "'%P\\0%p\\n'"],
                                        stdout=subprocess.PIPE)
        sort_process = subprocess.Popen(['sort', '-t', '\\0', '-n'],
                                        stdin=find_process.stdout, stdout=subprocess.PIPE)
        awk_process = subprocess.Popen(['awk', '-F', '\\0', '{print $2}'],
                                       stdin=sort_process.stdout, stdout=subprocess.PIPE)
        find_process.stdout.close()
        sort_process.stdout.close()
        found_files = awk_process.communicate()[0].strip().split("\n")
        pdb_files = [pdb_file for pdb_file in found_files if pdb_file != '']
        if not pdb_files:
            self.log.info("No PDB file found skipping application configuration")
            self.update_state_file("apply_pdb_step")
            self.quit_with_code(ReturnCode.REPEAT)

        self.check_pdb_precondition()
        self.read_pdb_pid_data()

        loop_counter = 1
        for pdb_file in pdb_files:
            pdb_file_name = os.path.basename(pdb_file)
            if self.is_config_step_done("pdb_import__%s__done" % pdb_file_name):
                loop_counter += 1
                continue

            if self.is_config_step_done("pdb_import__%s__start" % pdb_file_name):
                self.check_pdb_background_process(pdb_file, self.pdb_pid_data.get(pdb_file_name))

            self.update_state_file("pdb_import__%s__start" % pdb_file_name)
            self.log.info("Processing PDB file (%u/%u) [%s]" % (loop_counter, len(pdb_files), pdb_file_name))
            self.run_pdb_background_importer(pdb_file)
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.info("Application configuration is done")
        self.rm_file(self.pdb_pid_data_file())
        self.cleanup_pdb_work_dir()
        self.update_state_file("apply_pdb_step")

    def ensure_admin_state_unlocked(self):
        admin_state = self.read_admin_state()
        if admin_state not in ('LOCKED', 'UNLOCKED'):
            self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

        self.update_admin_state("UNLOCKED")

    @skippable
    def vdicos_configure_step(self):
        self.log.info("Configuring vDicos")
        try:
            self.ssh.run_command("vdicos-envdata-create LOAD_REG_MIN_TARGETCALLS 100")
            stdout, _, _ = self.ssh.run_command("vdicos-envdata-get LOAD_REG_MIN_TARGETCALLS")
            self.log.debug("vDicos LOAD_REG_MIN_TARGETCALLS set to: " + stdout)
            self.log.info("Configuring vDicos done")
        except Exception:
            self.log.error("Configuring vDicos failed.")
        self.update_state_file("vdicos_configure_step")

    @skippable
    def check_backup_complete_step(self):
        progress_cmd = "show ManagedElement=1,SystemFunctions=1,BrM=1,BrmBackupManager=SYSTEM_DATA,progressReport"
        com_result = self.run_com_cli_command(progress_cmd)
        match = re.search(
            '^\\s*progressPercentage=(?P<progress>\\d+)$.*?^\\s*result=(?P<result>\\w+)$.*?^\\s*state=(?P<state>\\w+)$',
            com_result, re.MULTILINE | re.DOTALL)

        if match.group('state') == 'FINISHED' and match.group('result') == 'SUCCESS':
            self.log.info("Backup created successfuly")
            self.update_state_file("check_backup_complete_step")
            return

        if int(match.group('progress')) < 100:
            self.log.info("Backup progress: %s%%" % match.group('progress'))
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.error("Could not create backup.")
        self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

    @skippable
    def create_backup_step(self):
        backup_cmd = "ManagedElement=1,SystemFunctions=1,BrM=1,BrmBackupManager=SYSTEM_DATA,createBackup"
        com_result = self.run_com_cli_command(backup_cmd)
        if com_result is None:
            self.log.error("Could not create backup.")
            self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

        self.log.info("Creating backup.")
        self.update_state_file('create_backup_step')

    def finalize_configuration(self):
        self.rm_work_dir()
        self.log.info("Post-instantiation hook finished successfully")
        self.quit_with_code(ReturnCode.SUCCESS)

    def argument_parsing(self):
        parser = PostInstantiation.argmunet_parsing_base(description='post_instantiation hook for workflow')
        parser.add_argument('-c', '--config-dir', metavar='<CONFIG_DIR>',
                            help='Configuration directory.', type=str, required=True)
        args = parser.parse_args()
        self.log.debug("Args parsed from CLI: [%s]" % args)
        if args.stack_details_file.endswith('.xml'):
            self.log.debug("Parsing XML config file: %s" % args.stack_details_file)
            config = self.parse_vcd_xml_file(args.stack_details_file)
        else:
            self.log.debug("Parsing JSON config file: %s" % args.stack_details_file)
            config = self.parse_openstack_json_file(args.stack_details_file)
        config.workflow_instance_identifier = args.workflow_instance_identifier
        config.emergency_username = self.get_value_or_fallback_on_none(args.user_name, config.emergency_username)
        config.key_file = args.key_file
        config.password_file = args.password_file
        config.config_dir = args.config_dir
        self.log.debug("Parameters parsed from config: %s" % config)
        self.config = config
        self.check_if_canceled(args)
        return config

    def parse_openstack_json_file(self, config_file):
        with open(config_file) as json_file:
            config_data = json.load(json_file)

        config = LcmTaskConfig()
        try:
            config.stack_name = config_data["stack"]["stack_name"]
            stack_params = config_data["stack"]["parameters"]
            config.mip = self.get_value_or_fallback_on_match(
                stack_params["OM_IPv4_address"].strip(),
                stack_params["OM_IPv6_address"].strip(), "none")
            config.sc1_ip = self.get_value_or_fallback_on_match(
                stack_params["SC-1_IPv4_address"].strip().strip(),
                stack_params["SC-1_IPv6_address"].strip().strip(), "none")
            config.sc2_ip = self.get_value_or_fallback_on_match(
                stack_params["SC-2_IPv4_address"].strip().strip(),
                stack_params["SC-2_IPv6_address"].strip().strip(), "none")
            for cfg_key in PostInstantiation.CONFIG_KEYS:
                config[cfg_key.replace("-", "_")] = stack_params[cfg_key].strip()
        except KeyError as err:
            self.log.error("A field is missing from the JSON file: %s" % err)
            self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)
        return config

    def parse_vcd_xml_file(self, config_file):
        parser = VCDXmlParser(config_file)
        v_app = parser.vnf_status_file
        v_app_name = v_app.attrib.get("name")
        if v_app_name is None:
            self.log.error("Could not fetch 'name' parameter while parsing input data")
            self.handle_config_file_error(config_file)
        config = LcmTaskConfig()
        config.stack_name = v_app_name
        config.mip = self.get_value_or_fallback_on_match(
            parser.get_property('OM_IPv4_address').strip(),
            parser.get_property('OM_IPv6_address').strip(), "none")
        config.sc1_ip = self.get_value_or_fallback_on_match(
            parser.get_property('SC-1_IPv4_address').strip(),
            parser.get_property('SC-1_IPv6_address').strip(), "none")
        config.sc2_ip = self.get_value_or_fallback_on_match(
            parser.get_property('SC-2_IPv4_address').strip(),
            parser.get_property('SC-2_IPv6_address').strip(), "none")
        for cfg_key in PostInstantiation.CONFIG_KEYS:
            config[cfg_key.replace("-", "_")] = parser.get_property(cfg_key).strip()
        return config


if __name__ == '__main__':
    setup_default_logging()
    post_instantiation = PostInstantiation()
    post_instantiation.do_post_instantiation_steps()

#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# C0111(missing-docstring), W0703(broad-except)
# pylint: disable=C0111, W0703

# Continue refactoring these:
# R1702(too-many-nested-blocks), R0904(too-many-public-methods)
# pylint: disable=R0904

# Workaround for VMTAS-17068:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311

from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import os
import re
import shutil
import subprocess
import time
import lxml.etree as etree

from paramiko import AuthenticationException

from common import (setup_default_logging, CommonLcmTask)
from imscommon.consts import ReturnCode
from imscommon.parsers import VCDXmlParser
from lcmUtilities.pdb_background_executor import PdbBackgroundExecutor
from lcmUtilities.lcm_decorators import skippable, workaround
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig


# noinspection PyBroadException
class PostInstantiation(CommonLcmTask):
    REMOTE_COM_SCRIPT_FILE = "/tmp/com_restart_cmd.sh"
    REMOTE_COM_ERR_FILE = "/tmp/com_restart_cmd.err"
    REMOTE_COM_PID_FILE = "/tmp/com_restart_cmd.pid"

    CONFIG_KEYS = ("platform-vip", "platform-vip6", "tasvip4", "tasvip6",
                   "ut-vip4", "ut-vip6", "cai3g-vip4", "cai3g-vip6",
                   "sigtran1-vip4", "sigtran1-vip6", "sigtran2-vip4", "sigtran2-vip6",
                   "emergency_username", "emergency_password_hash",
                   "secla_password_hash", "root_password_hash", "oss_pm_password_hash")

    def __init__(self):
        super(PostInstantiation, self).__init__()
        self.esm_time = None
        self.pdb_pid_data = {}
        self.log = LcmOutputManager(tag="vMTAS-PostInstantiation")
        self.config = self.argument_parsing()
        self.log.tag = "vMTAS-PostInstantiation.%s" % self.config.stack_name

        try:
            self.connect_to_host(host=self.config.mip, username="root", password="rootroot")
        except AuthenticationException:
            self.log.info("Root login disabled, logging in with %s user" % self.config.emergency_username)
            self.connect_with_config()
        except Exception:
            self.log.info("Connecting to host is not yet successful")
            self.quit_with_code(ReturnCode.REPEAT)

        self.create_vnflcm_dir()
        self.read_state_file("post_instantiation")

    def do_post_instantiation_steps(self):
        self.waiting_for_cmw_status_ok()
        self.check_cmw_status_node_su_sg()

        # Do actual work steps, can update state, short circuit on re-invocation when task is already done
        self.check_esm_image_step()
        self.check_hw_clock_step()  # probably removable
        self.cluster_delta_configure_step()
        self.restart_com_step()
        self.evip_delta_configure_step()
        self.ss7_delta_configure_step()
        self.update_lm_config_step()
        self.managed_element_update_step(self.config.stack_name)
        self.cai3g_sessions_configure_step()
        self.apply_pdb_step()
        self.add_emergency_user_step()
        self.change_secla_password_step()
        self.add_vnflcm_key_step()
        self.prepare_sftp_connection_step()
        self.com_restart_after_sftp_step()
        self.enable_scaling_step()

        # Finalize and cleanup
        self.clear_logs_step()
        self.disable_root_login_step()
        self.change_root_password_step()
        self.create_backup_step()
        self.check_backup_complete_step()
        self.finalize_configuration()

    def pdb_pid_data_file(self):
        return "%s/pdb_pid_data" % self.lcm_work_dir()

    def waiting_for_cmd_status_ok(self, p_cmd, p_retry_loop=3, p_sleep=5):
        self.log.debug("Waiting for %s status OK..." % p_cmd)
        for l_attempt in range(p_retry_loop):
            try:
                self.ssh.run_command(p_cmd)
                self.log.debug("cmd status is OK")
                return "OK"
            except Exception:
                self.log.debug("cmd status is NOT OK, retry... %d/%d" % (l_attempt + 1, p_retry_loop))
                time.sleep(p_sleep)
        self.log.warning(p_cmd + " status is NOT OK")
        return "NOT OK"

    def waiting_for_cmw_status_ok(self, retry_loop=3):
        state = self.waiting_for_cmd_status_ok("cmw-status node", p_retry_loop=retry_loop)
        if state == "NOT OK":
            self.log.info("Waiting for CoreMW")
            self.quit_with_code(ReturnCode.REPEAT)

    @staticmethod
    def is_cmw_status_mmas_ok(cmw_status):
        for line in cmw_status:
            if (line.startswith("safSu=") or line.startswith("safSg=")) and not ("MMAS" in line and "oam" in line):
                return False
        return True

    def check_cmw_status_node_su_sg(self, p_retry=3, p_sleep=5):
        cmd = "cmw-status node su sg"
        for _ in range(p_retry):
            try:
                stdout, _, _ = self.ssh.run_command(cmd)
                lines = stdout.split("\n")
                if lines[0] == "Status OK" or (
                        ("safSu=" in stdout or "safSg=" in stdout) and self.is_cmw_status_mmas_ok(lines)):
                    self.log.info("cmw-status is OK")
                    return

                self.log.info("Waiting for cmw-status OK")
                time.sleep(p_sleep)
                continue
            except Exception:
                self.log.info("cmw-status is not OK")
                self.quit_with_code(ReturnCode.REPEAT)

        self.log.info("cmw-status is not OK")
        self.quit_with_code(ReturnCode.REPEAT)

    def is_esm(self):
        _, _, code = self.ssh.run_command(
            "test -e /cluster/storage/system/config/lde/csm/finalized/csm.yml", fail_at_error=False)
        return code == 0

    def esm_timer_file(self):
        return "%s/post_install_esm_timer" % self.lcm_work_dir()

    def read_esm_timer_file(self):
        timer = self.read_vnflcm_file(self.esm_timer_file())
        self.esm_time = time.time() if timer is None else float(timer)

    def update_esm_timer_file(self):
        if os.path.exists(self.esm_timer_file()):
            self.log.debug("ESM timer file already exist")
            return False

        self.write_vnflcm_file(str(time.time()), self.esm_timer_file())
        return True

    @skippable
    def check_esm_image_step(self):
        if self.is_esm():
            self.update_esm_timer_file()
            self.check_esm_image_status()
        else:
            self.log.info("Not ESM image")
        self.update_state_file("check_esm_image_step")

    def check_esm_image_status(self):
        _, _, code = self.ssh.run_command(
            'grep "Offline Instantiation was successful" /var/log/SC-*/messages*', fail_at_error=False)
        if code:
            self.read_esm_timer_file()
            if time.time() - self.esm_time >= 1200:  # 20 minutes timeout? why?
                self.log.error("ESM installation status timeout. Exiting Installation...")
                self.quit_with_code(ReturnCode.RETURN_ERROR)

            self.log.info("ESM installation ongoing be patient")
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.info("ESM installation successful")

    def is_hwc_sync_fail(self):
        result = True
        for _ in range(2):
            result = self.run_command_match_string("hwclock --test --show --debug", "synchronization failed") and result
        return result

    @skippable
    @workaround("HW clock behavior validation")
    def check_hw_clock_step(self):
        """
        If hwclock returns sync fail message twice in a row, we need to enable the timer patch
        This is an official workaround from vMTAS install guide, for certain clooud versions
        :return:
        """
        self.log.info("Verifying HW clock behavior")
        for _ in range(1, 3):
            if self.is_hwc_sync_fail():
                self.log.info("Applying RTC patch")
                self.ssh.run_command(
                    "immcfg -a value=enabled MtasParameter=TimerPatch,MtasInt=1,MtasSite=1", fail_at_error=False)

                self.update_state_file("check_hw_clock_step")
                self.log.info("Apply RTC patch done")
                self.quit_with_code(ReturnCode.REPEAT)

        self.update_state_file("check_hw_clock_step")
        self.log.info("HW clock behavior appropriate")

    def prepare_hostname_cmd(self):
        """ Insert hostnames to cluster.conf after timezone """
        command = ('sed -i \'/^timezone/a \\'
                   '\n \\'
                   '\n#  ----------- \\'
                   '\n# | HOSTNAMES | \\'
                   '\n#  -----------  \\')

        if self.config.platform_vip != "none":
            command += "\nhost all %s platform-vip\\" % self.config.platform_vip
        if self.config.platform_vip6 != "none":
            command += "\nhost all %s platform-vip6\\" % self.config.platform_vip6

        if self.config.tasvip4 != "none":
            command += "\nhost all %s tasvip4\\" % self.config.tasvip4
        if self.config.tasvip6 != "none":
            command += "\nhost all %s tasvip6\\" % self.config.tasvip6

        if self.config.ut_vip4 != "none":
            command += "\nhost all %s ut-vip4\\" % self.config.ut_vip4
        if self.config.ut_vip6 != "none":
            command += "\nhost all %s ut-vip6\\" % self.config.ut_vip6

        if self.config.cai3g_vip4 != "none":
            command += "\nhost all %s cai3g-vip4\\" % self.config.cai3g_vip4
        if self.config.cai3g_vip6 != "none":
            command += "\nhost all %s cai3g-vip6\\" % self.config.cai3g_vip6

        if self.config.sigtran1_vip4 != "none":
            command += "\nhost all %s sigtran1-vip4\\" % self.config.sigtran1_vip4
        if self.config.sigtran1_vip6 != "none":
            command += "\nhost all %s sigtran1-vip6\\" % self.config.sigtran1_vip6

        if self.config.sigtran2_vip4 != "none":
            command += "\nhost all %s sigtran2-vip4\\" % self.config.sigtran2_vip4
        if self.config.sigtran2_vip6 != "none":
            command += "\nhost all %s sigtran2-vip6\\" % self.config.sigtran2_vip6

        command += "\n\'"

        command = command + " /cluster/etc/cluster.conf"
        return command

    def update_cluster_conf(self):
        """
        Add other cluster.conf customization here, for instance eth4 support.
        Make sure MACs added to output section of main HOT.
        """
        commands = [self.prepare_hostname_cmd()]
        self.log.debug("update_cluster_conf with hostname: %s" % commands)
        for command in commands:
            try:
                self.cp_file("/cluster/etc/cluster.conf", "/cluster/etc/cluster.conf.orig")
                self.ssh.run_command(command)
            except Exception as err:
                self.log.error("Something went wrong with cluster.conf update. Check documentation!")
                self.log.debug("Exception: %s" % err)
                self.mv_file("/cluster/etc/cluster.conf.orig", "/cluster/etc/cluster.conf")
                self.quit_with_code(ReturnCode.RETURN_ERROR)

    def reload_and_apply_cluster_conf(self):
        self.log.info("Reload/apply cluster config")
        self.cp_file("/cluster/etc/cluster.conf", "/boot/.cluster.conf")
        try:
            self.ssh.run_command("cluster config -r")
            self.ssh.run_command("cluster reboot -a > /dev/null 2>&1 &")
        except Exception as err:
            self.log.error("Reload/apply cluster config failed, configuration incomplete")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def validate_cluster_conf(self):
        self.log.info("Validate cluster config")
        _, stderr, code = self.ssh.run_command("cluster config -v", fail_at_error=False)
        if code != 0:
            self.log.error("Validate cluster config failed: %s" % stderr)
            self.mv_file("/cluster/etc/cluster.conf.org", "/cluster/etc/cluster.conf")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.log.info("Cluster config is valid")
        self.rm_file("/cluster/etc/cluster.conf.org")

    def manage_xdms_key_store(self):
        self.log.debug("manage_xdms_key_store")
        stderr = ""
        try:
            _, stderr, _ = self.ssh.run_command(
                "echo 'emergency ALL=(root) NOPASSWD:/usr/java/latest/bin/keytool'> /etc/sudoers.d/mtas-xdms-keytool")
        except Exception as err:
            self.log.error("Enable emergency user to manage MTAS XDMS key-store failed\n%s" % stderr,
                           with_feedback=False)
            self.log.debug("Exception: %s" % err)
            return False
        try:
            # Check where the file was created in previous step
            _, stderr, _ = self.ssh.run_command(
                "scp /etc/sudoers.d/mtas-xdms-keytool sc-2:/etc/sudoers.d/mtas-xdms-keytool")
        except Exception as err:
            self.log.error("Failed to copy file mtas-xdms-keytool to sc-2:/etc/sudoers.d/mtas-xdms-keytool\n%s"
                           % stderr, with_feedback=False)
            self.log.debug("Exception: %s" % err)
            return False
        try:
            _, stderr, _ = self.ssh.run_command(
                "scp /etc/sudoers.d/mtas-xdms-keytool sc-1:/etc/sudoers.d/mtas-xdms-keytool")
        except Exception as err:
            self.log.error("Failed to copy file mtas-xdms-keytool to sc-1:/etc/sudoers.d/mtas-xdms-keytool\n%s"
                           % stderr, with_feedback=False)
            self.log.debug("Exception: %s" % err)
            return False
        return True

    @skippable
    def cluster_delta_configure_step(self):
        self.log.info("Apply cluster delta configuration")
        self.cp_file("/cluster/etc/cluster.conf", "/cluster/etc/cluster.conf.org")
        self.update_cluster_conf()
        self.validate_cluster_conf()
        # State file update has to happen before cluster is reloaded, or it may fail
        self.update_state_file("cluster_delta_configure_step")
        self.reload_and_apply_cluster_conf()
        self.log.info("Cluster delta configuration done")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    @workaround("COM restart", "HX54313")
    def restart_com_step(self):
        if not self.restart_com():
            self.quit_with_code(ReturnCode.REPEAT)

        self.update_state_file('restart_com_step')

    def configure_emergency_user_account(self):
        _, stderr, code = self.ssh.run_command(
            "useradd -G com-emergency " + self.config.emergency_username, fail_at_error=False)
        if code not in (0, 9):  # 0 success; 9 exists
            self.log.error("Adding emergency user failed")
            self.log.debug(stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.ssh.run_command(
            "lde-global-user -u " + self.config.emergency_username, fail_at_error=False)
        try:
            self.ssh.run_command(
                "usermod -p '%s' %s" % (self.config.emergency_password_hash, self.config.emergency_username))
        except Exception as err:
            self.log.error("Adding emergency user failed")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def enable_user_access(self, username):
        _, _, code = self.ssh.run_command(
            "grep %s /cluster/etc/login.allow" % username, fail_at_error=False)
        if code == 1:
            _, stderr, code = self.ssh.run_command(
                'echo "%s all" >> /cluster/etc/login.allow' % username)
            if code != 0:
                self.log.error("Adding %s user failed" % username)
                self.log.debug(stderr)
                self.quit_with_code(ReturnCode.RETURN_ERROR)

    @skippable
    def add_emergency_user_step(self):
        self.log.info("Adding emergency user")
        self.configure_emergency_user_account()
        self.enable_user_access(self.config.emergency_username)
        if not self.manage_xdms_key_store():
            self.log.error("Failed to add emergency user")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.update_state_file("add_emergency_user_step")
        self.log.info("Emergency user added successfully")

    @staticmethod
    def prepare_com_restart_command(is_esm, active_sc_index, standby_sc_index):
        sc_replacement = {
            'pidfile': PostInstantiation.REMOTE_COM_PID_FILE,
            'errfile': PostInstantiation.REMOTE_COM_ERR_FILE,
            'active': active_sc_index,
            'standby': standby_sc_index
        }
        if is_esm:
            cmd_str = (
                "#!/bin/bash\n"
                "echo $BASHPID > %(pidfile)s\n"
                "function do_com_restart() {\n"
                "amf-adm lock safSu=SC-%(standby)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm lock-in safSu=SC-%(standby)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm lock safSu=SC-%(active)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm lock-in safSu=SC-%(active)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm unlock-in safSu=SC-%(active)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm unlock safSu=SC-%(active)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm unlock-in safSu=SC-%(standby)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "amf-adm unlock safSu=SC-%(standby)d,safSg=2N,safApp=ERIC-com.oam.access.aggregation\n"
                "} 2>%(errfile)s\n"
                "do_com_restart\n"
            ) % sc_replacement
        else:
            cmd_str = (
                "#!/bin/bash\n"
                "echo $BASHPID > %(pidfile)s\n"
                "function do_com_restart() {\n"
                "amf-adm lock safSu=Cmw%(standby)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm lock-in safSu=Cmw%(standby)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm lock safSu=Cmw%(active)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm lock-in safSu=Cmw%(active)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm unlock-in safSu=Cmw%(active)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm unlock safSu=Cmw%(active)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm unlock-in safSu=Cmw%(standby)d,safSg=2N,safApp=ERIC-ComSa\n"
                "amf-adm unlock safSu=Cmw%(standby)d,safSg=2N,safApp=ERIC-ComSa\n"
                "} 2>%(errfile)s\n"
                "do_com_restart\n"
            ) % sc_replacement

        return cmd_str

    def is_com_restart_process_complete(self, pid):
        try:
            self.ssh.run_command("kill -0 %s" % pid)
            return False
        except RuntimeError:
            return True
        except Exception:
            self.log.info("COM restart status not available")
            self.quit_with_code(ReturnCode.REPEAT)

    def com_restart_success(self):
        err = self.read_file(PostInstantiation.REMOTE_COM_ERR_FILE)
        return False if err else True

    def restart_com(self):
        """
        Current implementation expects that SC roles are not changed during COM restart
        """
        com_restart_pid = "%s/com_restart.pid" % self.lcm_work_dir()

        pid = self.read_vnflcm_file(com_restart_pid)
        if pid is not None:
            if self.is_com_restart_process_complete(pid) and self.com_restart_success():
                os.remove(com_restart_pid)
                self.rm_file(PostInstantiation.REMOTE_COM_PID_FILE)
                self.log.info("Restarting COM done")
                return True

            self.log.info("COM restart in progress")
            return False

        is_esm = self.is_esm()
        self.log.info("Restarting COM")
        active_sc_index = 2
        standby_sc_index = 1

        cond1 = (is_esm and self.run_command_match_string(
            "amf-state csiass | grep -A 2 -i Com | grep -A 1 -F 'com-sshd-manager\\,safSu=SC-1'"
            " | grep saAmfCSICompHAState=ACTIVE",
            "saAmfCSICompHAState=ACTIVE(1)"))
        cond2 = (not is_esm and self.run_command_match_string(
            "amf-state csiass | grep -A 2 -i ComSa | grep -A 1 -F 'ERIC-ComSa-sshd\\,safSu=Cmw1'"
            " | grep saAmfCSICompHAState=ACTIVE",
            "saAmfCSICompHAState=ACTIVE(1)"))

        if cond1 or cond2:
            active_sc_index = 1
            standby_sc_index = 2

        generated_bash_script = self.prepare_com_restart_command(is_esm, active_sc_index, standby_sc_index)
        self.write_file(generated_bash_script, self.REMOTE_COM_SCRIPT_FILE)
        try:
            self.ssh.run_command("nohup bash %s > /dev/null 2>&1 &" % self.REMOTE_COM_SCRIPT_FILE)
        except Exception:
            self.log.error("COM restart error")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        pid = self.read_file(self.REMOTE_COM_PID_FILE)
        if pid is not None:
            self.write_vnflcm_file(pid.strip(), com_restart_pid)
            return False

        self.log.error("COM restart error, missing PID file")
        self.quit_with_code(ReturnCode.RETURN_ERROR)

    def enable_com_sshd_manager(self):
        self.log.debug("Enabling COM ssh manager")
        self.ssh.run_command(
            "sed -i -e 's#<cliPort>22</cliPort>#<cliPort>2022</cliPort>#g'"
            " /cluster/storage/system/config/com-apr9010443/lib/comp/libcom_sshd_manager.cfg",
            fail_at_error=False)
        self.ssh.run_command(
            "sed -i -e 's#<sshdManagement>false</sshdManagement>#<sshdManagement>true</sshdManagement>#g'"
            " /cluster/storage/system/config/com-apr9010443/lib/comp/libcom_sshd_manager.cfg",
            fail_at_error=False)
        self.log.debug("Enabling COM ssh manager done")
        return True

    def secla_psw_change(self):
        slp_cmd = "$(printf '%%q ' /opt/eric/sec-la-cxp9026994/bin/sec-la-passwd la-admin -h '%s')" % (
                  self.config.secla_password_hash)
        for controller in ['sc-1', 'sc-2']:
            # this needs to be done on a specific SC, which may, or may not, be the active SC...
            _, _, code = self.ssh.run_command("ssh %s ps -ef | grep slapd | fgrep -v grep" % controller,
                                              fail_at_error=False)
            if not code:
                _, _, code = self.ssh.run_command('ssh %s "%s"' % (controller, slp_cmd), fail_at_error=False)
                if not code:
                    self.log.info("SEC-LA password change succeeded")
                    return
                self.log.debug("SEC-LA command failed on %s" % controller)

        self.log.error("SEC-LA password change failed")
        self.quit_with_code(ReturnCode.RETURN_ERROR)

    @skippable
    def change_secla_password_step(self):
        self.log.info("Change default SEC-LA password")
        self.enable_com_sshd_manager()
        self.secla_psw_change()
        self.update_state_file("change_secla_password_step")
        self.log.info("SEC-LA password changed")

    @skippable
    def add_vnflcm_key_step(self):
        self.log.info("Add VNF-LCM's key to emergency user")
        public_key_file = "%s.pub" % self.config.key_file
        if not os.path.isfile(public_key_file):
            self.log.info("Public key file can't be found at private key location, trying config-dir ...")
            public_key_file = "%s/id_rsa.pub" % self.config.config_dir
        if not os.path.isfile(public_key_file):
            self.log.error("No public key found.")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        try:
            self.ssh.send_file(public_key_file, "/tmp/id_rsa.pub")
            self.ssh.run_command("su - %s -c 'mkdir -p .ssh'" % self.config.emergency_username)
            self.ssh.run_command(
                "su - %s -c 'cat /tmp/id_rsa.pub >> .ssh/authorized_keys'" % self.config.emergency_username)
            self.ssh.run_command("rm -f /tmp/id_rsa.pub")
        except Exception as err:
            self.log.error("Add VNF-LCM's key to emergency user failed")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.update_state_file("add_vnflcm_key_step")
        self.log.info("Add VNF-LCM's key to emergency user done")

    @skippable
    def change_root_password_step(self):
        self.log.info("Changing root password")
        try:
            self.ssh.run_command("usermod -p '%s' root; cluster config -r -a" % self.config.root_password_hash)
        except Exception as err:
            self.log.error("Changing root password failed")
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.log.info("root password changed")
        self.update_state_file('change_root_password_step')

    @skippable
    def disable_root_login_step(self):
        self.log.info("Disabling root login")
        _, _, code = self.ssh.run_command(
            'grep "^ssh.rootlogin all off" /cluster/etc/cluster.conf', fail_at_error=False)
        if code:
            _, stderr, code = self.ssh.run_command(
                "sed -i -e '0,/^# ssh listening networks/s/# ssh listening networks/# "
                "ssh root login\\nssh.rootlogin all off\\n\\n&/' /cluster/etc/cluster.conf",
                fail_at_error=False)
            if code != 0:
                self.log.error("Updating cluster.conf failed")
                self.log.debug(stderr)
                self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.log.info("Disabling root login done")
        self.update_state_file('disable_root_login_step')

    @skippable
    def prepare_sftp_connection_step(self):
        self.log.info("Prepare SFTP connection")
        _, stderr, code = self.ssh.run_command("groupadd sftpusers", fail_at_error=False)
        if code not in (0, 9):
            self.log.error("Adding SFTP group failed")
            self.log.debug(stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        _, stderr, code = self.ssh.run_command("useradd -m -G sftpusers oss_pm ", fail_at_error=False)
        if code not in (0, 9):
            self.log.error("Adding SFTP group, oss_user user failed")
            self.log.debug(stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.ssh.run_command("lde-global-user -g sftpusers", fail_at_error=False)
        self.ssh.run_command("lde-global-user -u oss_pm", fail_at_error=False)
        try:
            _, stderr, _ = self.ssh.run_command("usermod -p '%s' oss_pm" % self.config.oss_pm_password_hash)
        except Exception as err:
            self.log.error("Adding oss_pm/SFTP user failed")
            self.log.debug(stderr)
            self.log.debug("Exception: %s" % err)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.enable_user_access("oss_pm")

        _, _, code = self.ssh.run_command(
            "grep sftpusers /cluster/storage/system/config/mtas/sshd_config_sftp_filem", fail_at_error=False)
        if code in (1, 2):
            self.cp_file(
                "/cluster/storage/system/config/mtas/sshd_config_sftp_filem.template",
                "/cluster/storage/system/config/mtas/sshd_config_sftp_filem")
            self.ssh.run_command(
                "sed -i -e 's/<GROUP ID HERE>/sftpusers/g' "
                "/cluster/storage/system/config/mtas/sshd_config_sftp_filem",
                fail_at_error=False)

        self.update_state_file("prepare_sftp_connection_step")

    @skippable
    def com_restart_after_sftp_step(self):
        if not self.restart_com():
            self.quit_with_code(ReturnCode.REPEAT)

        self.update_state_file("com_restart_after_sftp_step")
        self.log.info("Prepare SFTP connection done")

    def run_command_match_string(self, p_command, p_match):
        stdout, _, _ = self.ssh.run_command(p_command, fail_at_error=False)
        if p_match in stdout:
            self.log.debug("Run command match string: %s string is matched in std out" % p_match)
            return True
        self.log.debug("Run command match string: %s string is NOT matched in std out" % p_match)
        return False

    def check_evip_alb_on_com_nbi(self, alb_name, retry=20, sleep=5):
        """ This function checks if the given alb_name is in ACTIVE state """
        self.log.info("Check eVIP %s alb on COM NBI" % alb_name)
        command = "show ManagedElement=1,Transport=1,Evip=1,EvipAlbs=1,EvipAlb=%s,state" % alb_name
        for _ in range(retry):
            com_result = self.run_com_cli_command(command, configure_mode=False)
            if com_result is None:
                self.log.error("eVIP verification failed. Check documentation!")
                self.quit_with_code(ReturnCode.RETURN_ERROR)

            match = re.search('state="(?P<state>.+?)"', com_result, re.MULTILINE)
            self.log.debug("EvipAlb: %s state: %s" % (alb_name, match.group('state')))
            if match.group('state') == "ACTIVE":
                self.log.info("eVIP %s alb is OK on COM NBI" % alb_name)
                return

            time.sleep(sleep)

        self.log.error("Timer expired. eVIP verification failed. Check documentation!")
        self.quit_with_code(ReturnCode.RETURN_ERROR)

    def prepare_evip_cmd(self, evip_cli_file):
        command = ""
        try:
            with open(evip_cli_file, 'r') as file:
                for line in file:
                    command += line
                command += "\nend"  # evip.txt stays in configure mode, so we need to exit with "\nend"
                return command
        except IOError:
            self.log.info("eVIP delta config file ./evip_cli.txt cannot be found, skipping eVIP delta configuration")
            return command

    @skippable
    def evip_delta_configure_step(self):
        self.log.info("Apply eVIP delta configuration")
        evip_cli_file = "%s/evip_cli.txt" % self.config.config_dir
        command = self.prepare_evip_cmd(evip_cli_file)
        if command == "":
            self.log.info("Skipping eVIP delta configuration")
            self.update_state_file("evip_delta_configure_step")
            return

        self.log.info("Executing eVIP CLI commands")
        self.run_com_cli_command(command, enforce_commit=False)
        # Verifying evip configuration, please add new ALB to the list if needed
        for alb in ["mtas_om", "mtas_sig"]:
            self.check_evip_alb_on_com_nbi(alb)

        self.update_state_file("evip_delta_configure_step")
        self.log.info("eVIP delta configuration done")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    def ss7_delta_configure_step(self):
        self.log.info("Apply SS7 delta configuration")
        ss7_config_file = "%s/ss7.conf" % self.config.config_dir
        command = "export PATH=$PATH:/opt/sign/EABss7069/jre/bin; echo \'expert: mode=on; confmode: mode=\"reconf\";"
        try:
            with open(ss7_config_file, 'r') as file:
                for line in file:
                    command += line.replace('\n', '')
        except IOError:
            self.log.info("SS7 delta config file ss7.conf cannot be found, skipping SS7 delta config")
            self.update_state_file("ss7_delta_configure_step")
            return

        command += "configure:INITIAL; exit;\' | timeout 60 /opt/sign/EABss7050/bin/signmcli" \
                   " -own.conf /storage/system/config/ss7caf-ana90137/etc/signmgr.cnf -online yes"
        _, stderr, code = self.ssh.run_command(command, fail_at_error=False)
        if code:
            self.log.error("Apply SS7 delta configuration Failed.")
            self.log.debug(stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.ssh.run_command("mkdir -p /cluster/storage/system/config/ss7caf-ana90137/etc/sctp/", fail_at_error=False)
        self.ssh.run_command(
            "cp -f /cluster/storage/system/config/ss7caf-ana90137/etc/* "
            "/cluster/storage/system/config/ss7caf-ana90137/etc/sctp/", fail_at_error=False)
        self.update_state_file("ss7_delta_configure_step")
        self.log.info("SS7 delta configuration done")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    def update_lm_config_step(self):
        """
        removes template parameters from the mentioned xml.
        e.g. <Path>%{LM_NeLS_SSL_ca_file}</Path> --> <Path></Path>
        :return:
        """
        self.log.info("Updating certificate_config.xml")
        _, stderr, code = self.ssh.run_command(
            "sed -i s/%\\{.*\\}// /cluster/storage/system/config/lm-apr9010503/certs/certificate_config.xml",
            fail_at_error=False)
        if code != 0:
            self.log.error("Error when updating certificate_config.xml: %s" % stderr)
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.update_state_file("update_lm_config_step")
        self.log.info("Updating certificate_config.xml done.")

    @skippable
    def cai3g_sessions_configure_step(self):
        self.log.info("Configuring CAI3G Maximum Sessions value")
        if self.config.cai3g_vip4 != "none" or self.config.cai3g_vip6 != "none":
            stdout = 0
            try:
                stdout, _, _ = self.ssh.run_command("cat /proc/cpuinfo | grep 'processor' | wc -l")
            except Exception:
                self.log.error("CAI3G Maximum Sessions value configuration failed!")
                self.quit_with_code(ReturnCode.RETURN_ERROR)

            command = "ManagedElement=1,MtasFunction=MtasFunction,MtasXdms=0,mtasXdmsCai3gMaximumSessions=%d" \
                      % (int(stdout) * 32)
            com_result = self.run_com_cli_command(command)
            if com_result is None:
                self.log.info("Could not set mtasXdmsCai3gMaximumSessions=%d" % (int(stdout) * 32))
                self.quit_with_code(ReturnCode.REPEAT)

        self.update_state_file("cai3g_sessions_configure_step")
        self.log.info("CAI3G Maximum Sessions value is configured")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    def managed_element_update_step(self, value):
        self.log.info("updating ManagedElement value to %s" % value)
        cmd_str = "ManagedElement=1,networkManagedElementId=%s" % value
        self.run_com_cli_command(cmd_str)
        self.update_state_file("managed_element_update_step")
        self.log.info("ManagedElement value updated to %s" % value)

    @skippable
    def enable_scaling_step(self):
        self.log.info("Enabling scaling")
        try:
            self.ssh.run_command("cmw-configuration --enable SCALING")
        except Exception:
            self.log.error("Could not enable scaling")
            self.quit_with_code(ReturnCode.RETURN_ERROR)
        self.update_state_file("enable_scaling_step")
        self.log.info("Enabling scaling done")

    @skippable
    def clear_logs_step(self):
        self.ssh.run_command("clurun.sh clear_logs", fail_at_error=False)
        self.ssh.run_command("rm -rf /opt/cdclsv/storage/dumps/*", fail_at_error=False)
        self.ssh.run_command("rm -rf /opt/cdclsv/storage/cadump/*", fail_at_error=False)
        self.update_state_file("clear_logs_step")

    def handle_pdb_error_xml(self, rpc_error, pdb_log_file, pdb_file):
        """
        Check the error-tag value in the rpc-error tag, and attempt to re-run the import tasks 10 times before
        giving up if error type was resource-denied.
        (Resource denied case might suggest that the VNF is not yet in a state where it can accept the configuration.)
        """
        error_tag = rpc_error.find('{*}error-tag')
        if error_tag.text == "resource-denied" and self.can_iterate_step("handle_pdb_error_%s" % pdb_file, 10):
            self.log.error("PDB configuration pending")
            self.run_pdb_background_importer(pdb_file)
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.error("Application configuration with pdb failed! Check PDB log file: %s" % pdb_log_file)
        self.quit_with_code(ReturnCode.RETURN_ERROR)

    def check_pdb_precondition(self):
        """
        Attempt to check if node is ready to accept the configuration.
        This might require additional checks.
        """
        admin_state = self.read_admin_state()
        if admin_state not in ('LOCKED', 'UNLOCKED'):
            self.log.info('Application is not ready for configuration.')
            self.quit_with_code(ReturnCode.REPEAT)

    def save_pdb_file_pid(self, pdb_file_name, pid, log):
        self.pdb_pid_data[pdb_file_name] = {
            'pid': pid,
            'log': log
        }
        self.write_vnflcm_file(json.dumps(self.pdb_pid_data), self.pdb_pid_data_file())

    def read_pdb_pid_data(self):
        data = self.read_vnflcm_file(self.pdb_pid_data_file())
        self.pdb_pid_data = json.loads(data.split("\n")[0]) if data else {}

    def check_pdb_background_process(self, pdb_file, pdb_info):
        """
        Try to check process status by PID by sending a kill signal 0.
        If this throws an OSError, that means the process already quit, or its owned by some other user.
        In both cases we should check the logs left by the import, to check for errors.
        """
        self.log.debug("check_pdb_background_process [%s] [%s]" % (pdb_file, pdb_info))
        try:
            os.kill(pdb_info['pid'], 0)
        except OSError:
            self.check_pdb_run_for_error(pdb_file, pdb_info['log'])
        else:
            self.log.info("PDB import is ongoing [%s]" % os.path.basename(pdb_file))
            self.quit_with_code(ReturnCode.REPEAT)

    def check_pdb_run_for_error(self, pdb_file, log_file_name):
        """ Parse the rpc-reply sections of the log file as xml, and check if there was any <rpc-error> """
        with open(log_file_name) as log_file:
            log_text = log_file.read()

        pattern = '^<\\?xml version="1\\.0" encoding="UTF-8"\\?>$\n^<rpc-reply.*?</rpc-reply>$'
        matches = re.findall(pattern, log_text, re.MULTILINE | re.DOTALL)

        pdb_file_name = os.path.basename(pdb_file)
        log_dir = "/tmp/%s_pdb_import" % self.config.workflow_instance_identifier
        if not matches:
            self.log.error("PDB import failed [%s]. No rpc-reply found in logs. Check configtool-*.log in %s dir" %
                           (pdb_file_name, log_dir))
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        for xml in matches:
            rpc_reply = etree.fromstring(xml)
            for reply in rpc_reply:
                if self.trim_namespace(reply.tag) == 'rpc-error':
                    self.handle_pdb_error_xml(reply, log_file_name, pdb_file)

        self.update_state_file("pdb_import__%s__done" % pdb_file_name)
        self.log.info("PDB import done [%s]" % pdb_file_name)
        self.quit_with_code(ReturnCode.REPEAT)

    @staticmethod
    def trim_namespace(ns_string):
        """ Remove namespace from the xml tag name """
        return re.match('{.*}(.*)', ns_string).group(1)

    def run_pdb_background_importer(self, pdb_file):
        pdb_work_dir = "/tmp/%s_pdb_import" % self.config.workflow_instance_identifier
        pdb_exec = PdbBackgroundExecutor(['-f', pdb_file, '-wd', pdb_work_dir])
        pid = pdb_exec.execute()
        self.log.debug("PDB executor pid is [%s], log file is at: [%s]" % (pid, pdb_exec.log_file))
        pdb_file_name = os.path.basename(pdb_file)
        self.save_pdb_file_pid(pdb_file_name, pid, pdb_exec.log_file)

    def cleanup_pdb_work_dir(self):
        pdb_work_dir = "/tmp/%s_pdb_import" % self.config.workflow_instance_identifier
        if os.path.isdir(pdb_work_dir):
            shutil.rmtree(pdb_work_dir)

    @skippable
    def apply_pdb_step(self):
        """
        Try to apply all PDB files in the config folder.

        This method will launch all pdb import tasks sequentially in the background, checking the PID
        of the import process on subsequent runs to see if the import task was finished.

        Upon completion the log is examined to see if there was any rpc-error during the operation,
        and if there was the import task will be re-applied with a 10 attempt timeout.
        """
        find_process = subprocess.Popen(['find', self.config.config_dir, '-iname', '*.zip', '-printf', "'%P\\0%p\\n'"],
                                        stdout=subprocess.PIPE)
        sort_process = subprocess.Popen(['sort', '-t', '\\0', '-n'],
                                        stdin=find_process.stdout, stdout=subprocess.PIPE)
        awk_process = subprocess.Popen(['awk', '-F', '\\0', '{print $2}'],
                                       stdin=sort_process.stdout, stdout=subprocess.PIPE)
        find_process.stdout.close()
        sort_process.stdout.close()
        found_files = awk_process.communicate()[0].strip().split("\n")
        pdb_files = [pdb_file for pdb_file in found_files if pdb_file != '']
        if not pdb_files:
            self.log.info("No PDB file found skipping application configuration")
            self.update_state_file("apply_pdb_step")
            self.quit_with_code(ReturnCode.REPEAT)

        self.check_pdb_precondition()
        self.read_pdb_pid_data()

        loop_counter = 1
        for pdb_file in pdb_files:
            pdb_file_name = os.path.basename(pdb_file)
            if self.is_config_step_done("pdb_import__%s__done" % pdb_file_name):
                loop_counter += 1
                continue

            if self.is_config_step_done("pdb_import__%s__start" % pdb_file_name):
                self.check_pdb_background_process(pdb_file, self.pdb_pid_data.get(pdb_file_name))

            self.update_state_file("pdb_import__%s__start" % pdb_file_name)
            self.log.info("Processing PDB file (%u/%u) [%s]" % (loop_counter, len(pdb_files), pdb_file_name))
            self.run_pdb_background_importer(pdb_file)
            self.quit_with_code(ReturnCode.REPEAT)

        self.ensure_admin_state_unlocked()
        self.log.info("Application configuration is done")
        self.rm_file(self.pdb_pid_data_file())
        self.cleanup_pdb_work_dir()
        self.update_state_file("apply_pdb_step")

    def ensure_admin_state_unlocked(self):
        admin_state = self.read_admin_state()
        if admin_state not in ('LOCKED', 'UNLOCKED'):
            self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

        self.update_admin_state("UNLOCKED")

    @skippable
    def check_backup_complete_step(self):
        progress_cmd = "show ManagedElement=1,SystemFunctions=1,BrM=1,BrmBackupManager=SYSTEM_DATA,progressReport"
        com_result = self.run_com_cli_command(progress_cmd)
        match = re.search(
            '^\\s*progressPercentage=(?P<progress>\\d+)$.*?^\\s*result=(?P<result>\\w+)$.*?^\\s*state=(?P<state>\\w+)$',
            com_result, re.MULTILINE | re.DOTALL)

        if match.group('state') == 'FINISHED' and match.group('result') == 'SUCCESS':
            self.log.info("Backup created successfuly")
            self.update_state_file("check_backup_complete_step")
            return

        if int(match.group('progress')) < 100:
            self.log.info("Backup progress: %s%%" % match.group('progress'))
            self.quit_with_code(ReturnCode.REPEAT)

        self.log.error("Could not create backup.")
        self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

    @skippable
    def create_backup_step(self):
        backup_cmd = "ManagedElement=1,SystemFunctions=1,BrM=1,BrmBackupManager=SYSTEM_DATA,createBackup"
        com_result = self.run_com_cli_command(backup_cmd)
        if com_result is None:
            self.log.error("Could not create backup.")
            self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

        self.log.info("Creating backup.")
        self.update_state_file('create_backup_step')

    def finalize_configuration(self):
        self.mtas_small_restart()
        self.rm_work_dir()
        self.log.info("Post-instantiation hook finished successfully")
        self.quit_with_code(ReturnCode.SUCCESS)

    def argument_parsing(self):
        parser = PostInstantiation.argmunet_parsing_base(description='post_instantiation hook for workflow')
        parser.add_argument('-c', '--config-dir', metavar='<CONFIG_DIR>',
                            help='Configuration directory.', type=str, required=True)
        args = parser.parse_args()
        self.log.debug("Args parsed from CLI: [%s]" % args)
        if args.stack_details_file.endswith('.xml'):
            self.log.debug("Parsing XML config file: %s" % args.stack_details_file)
            config = self.parse_vcd_xml_file(args.stack_details_file)
        else:
            self.log.debug("Parsing JSON config file: %s" % args.stack_details_file)
            config = self.parse_openstack_json_file(args.stack_details_file)
        config.workflow_instance_identifier = args.workflow_instance_identifier
        config.emergency_username = self.get_value_or_fallback_on_none(args.user_name, config.emergency_username)
        config.key_file = args.key_file
        config.password_file = args.password_file
        config.config_dir = args.config_dir
        self.log.debug("Parameters parsed from config: %s" % config)
        self.config = config
        self.check_if_canceled(args)
        return config

    def parse_openstack_json_file(self, config_file):
        with open(config_file) as json_file:
            config_data = json.load(json_file)

        config = LcmTaskConfig()
        try:
            config.stack_name = config_data["stack"]["stack_name"]
            stack_params = config_data["stack"]["parameters"]
            config.mip = self.get_value_or_fallback_on_match(
                stack_params["OM_IPv4_address"].strip(),
                stack_params["OM_IPv6_address"].strip(), "none")
            config.sc1_ip = self.get_value_or_fallback_on_match(
                stack_params["SC-1_IPv4_address"].strip().strip(),
                stack_params["SC-1_IPv6_address"].strip().strip(), "none")
            config.sc2_ip = self.get_value_or_fallback_on_match(
                stack_params["SC-2_IPv4_address"].strip().strip(),
                stack_params["SC-2_IPv6_address"].strip().strip(), "none")
            for cfg_key in PostInstantiation.CONFIG_KEYS:
                config[cfg_key.replace("-", "_")] = stack_params[cfg_key].strip()
        except KeyError as err:
            self.log.error("A field is missing from the JSON file: %s" % err)
            self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)
        return config

    def parse_vcd_xml_file(self, config_file):
        parser = VCDXmlParser(config_file)
        v_app = parser.vnf_status_file
        v_app_name = v_app.attrib.get("name")
        if v_app_name is None:
            self.log.error("Could not fetch 'name' parameter while parsing input data")
            self.handle_config_file_error(config_file)
        config = LcmTaskConfig()
        config.stack_name = v_app_name
        config.mip = self.get_value_or_fallback_on_match(
            parser.get_property('OM_IPv4_address').strip(),
            parser.get_property('OM_IPv6_address').strip(), "none")
        config.sc1_ip = self.get_value_or_fallback_on_match(
            parser.get_property('SC-1_IPv4_address').strip(),
            parser.get_property('SC-1_IPv6_address').strip(), "none")
        config.sc2_ip = self.get_value_or_fallback_on_match(
            parser.get_property('SC-2_IPv4_address').strip(),
            parser.get_property('SC-2_IPv6_address').strip(), "none")
        for cfg_key in PostInstantiation.CONFIG_KEYS:
            config[cfg_key.replace("-", "_")] = parser.get_property(cfg_key).strip()
        return config


if __name__ == '__main__':
    # C0103(invalid-name)
    # pylint: disable=C0103
    setup_default_logging()
    post_instantiation = PostInstantiation()
    post_instantiation.do_post_instantiation_steps()

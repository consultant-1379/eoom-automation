#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# C0111(missing-docstring)
# pylint: disable=C0111

# Continue refactoring these:
# R1702(too-many-nested-blocks), R0904(too-many-public-methods), W0141(use-builtin-function filter)
# pylint: disable=R0904, W0141

# Workaround for VMTAS-17068:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311
from __future__ import (absolute_import, division, print_function, unicode_literals)

from common import CommonLcmTask
from imscommon.consts import ReturnCode
from lcmUtilities.lcm_decorators import skippable


class ScaleLcmBaseTask(CommonLcmTask):
    SCALED_NUMBER_VAR_NAME = "number_of_scaled_out_VMs"

    def scale_in_cache_file(self):
        return "%s/scale-in_cache" % self.lcm_work_dir()

    @skippable
    def scale_in_keeping(self, keep_uuids):
        """
        This method will execute CMW scale-in commands in order to remove
        cluster members from the cluster.
        """
        pl_to_uuid = self.get_pl_name_to_uuid_dict(self.get_equipment_data())
        cmd = []
        for key in pl_to_uuid:
            if self.is_scalable_node(key) and pl_to_uuid.get(key) not in keep_uuids:
                self.log.debug("Removing PL: %s by UUID: %s" % (key, pl_to_uuid[key]))
                cmd.append("no ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=%s,provides" % key)

        if not cmd:
            self.log.warning("Nothing to scale in.")
            self.update_state_file("scale_in_keeping")
            return

        com_result = self.run_com_cli_command("\n".join(cmd), True)
        self.log.debug("CMW scale-in result [%s]" % com_result)

        self.update_state_file("scale_in_keeping")
        self.log.info("Executed scale-in command - waiting for VM to leave the cluster")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    def check_scale_in_complete(self, keep_uuids):
        """
        This method will check if CMW scale-in operation has been
        completed or not. If the scale-in PL(s) has not disappeared
        from COM CLI, it is assumed that scale-in still is ongoing.
        If scale-in is still ongoing, REPEAT exit code will be
        used.
        If the scale-in operation hasn't completed after 100 checks,
        scale-in operation is considered as failed.
        """
        pl_to_uuid = self.get_pl_name_to_uuid_dict(self.get_equipment_data())
        scaling_is_done = True
        for key in pl_to_uuid:
            if self.is_scalable_node(key) and pl_to_uuid.get(key) not in keep_uuids:
                self.log.debug("Wait scale-in complete Node [%s] is still active, must wait" % key)
                scaling_is_done = False

        if scaling_is_done:
            self.log.debug("ScaleIn hook finished")
            self.update_state_file("check_scale_in_complete")
            return

        if not self.can_iterate_step("scale_in_wait", 100):
            self.log.error("Timer expired! Scale-in failed")
            self.rm_work_dir()
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.log.info("Scale-in VMs are still active - waiting")
        self.quit_with_code(ReturnCode.REPEAT)

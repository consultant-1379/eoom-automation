#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# C0111(missing-docstring)
# pylint: disable=C0111

# Continue refactoring these:
# R1702(too-many-nested-blocks), R0904(too-many-public-methods)
# pylint: disable=R0904

# Workaround for VMTAS-17068:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311

from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import time

from common import CommonLcmTask, setup_default_logging
from imscommon.consts import ReturnCode
from imscommon.parsers import VCDXmlParser
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig


class PreTermination(CommonLcmTask):

    def __init__(self):
        super(PreTermination, self).__init__()
        self.termination_timer = None
        self.log = LcmOutputManager(tag="vMTAS-PreTermination")
        self.config = self.argument_parsing()
        self.log.tag = "vMTAS-PreTermination.%s" % self.config.stack_name

        # determine termination type
        if self.config.termination_type == "FORCEFUL":
            self.log.info("FORCEFUL TERMINATION Finished")
            self.quit_with_code(ReturnCode.SUCCESS)

        self.create_vnflcm_dir()
        self.connect_with_config()

    def do_pre_terminate(self):
        self.log.debug("Invoking %s Pre-Termination." % self.config.termination_type)

        self.termination_timer = self.read_terminate_timer()
        admin_state = self.read_admin_state()

        if self.termination_timer is None and admin_state != 'LOCKED':
            self.update_terminate_timer(self.config.termination_timer)
            self.update_admin_state("SHUTTINGDOWN")
            self.log.info("Update adminstate to SHUTTINGDOWN.")
            self.quit_with_code(ReturnCode.REPEAT)
        elif admin_state == "LOCKED":
            self.rm_work_dir()
            self.log.info("Termination is SUCCESS. Adminstate is LOCKED.")
            self.quit_with_code(ReturnCode.SUCCESS)
        elif admin_state != "SHUTTINGDOWN":
            self.update_admin_state("SHUTTINGDOWN")
            self.log.info("Adminstate is set to SHUTTINGDOWN.")
            self.quit_with_code(ReturnCode.REPEAT)
        elif self.is_valid_terminate_timer() and self.is_terminate_timer_expired():
            self.rm_work_dir()
            self.log.warning("Termination timer expired. Exit with SUCCESS.")
            self.quit_with_code(ReturnCode.SUCCESS)

        self.log.info("Waiting for node to shut down.")
        self.quit_with_code(ReturnCode.REPEAT)

    def graceful_cancel(self):
        self.quit_with_code(ReturnCode.REJECT)

    def read_terminate_timer(self):
        timer = self.read_vnflcm_file(self.config.termination_timer_file)
        if timer is None:
            return time.time()
        return int(float(timer.strip()))

    def update_terminate_timer(self, shut_timer):
        if shut_timer != -1:
            shut_timer = time.time() + shut_timer

        self.write_vnflcm_file(shut_timer, self.config.termination_timer_file)

    def is_terminate_timer_expired(self):
        cur_time = time.time()
        return self.termination_timer is not None and cur_time >= self.termination_timer

    def is_valid_terminate_timer(self):
        return self.termination_timer > 0

    def argument_parsing(self):
        parser = PreTermination.argmunet_parsing_base(description='pre_termination hook for workflow')
        parser.add_argument(
            '-t', '--termination-type', metavar='<TERMINATION_TYPE>', choices=['GRACEFUL', 'FORCEFUL'],
            help='Specifies whether GRACEFUL or FORCEFUL termination is desired',
            type=str, required=True)
        parser.add_argument(
            '-s', '--shutting-down-timer', metavar='<Timer>',
            help='Only applicable in case of GRACEFUL termination. After the timer(in seconds) '
                 'expires, the script takes the VNF out of service',
            type=int, required=False, default=-1)

        args = parser.parse_args()
        self.log.debug("Args parsed from CLI: [%s]" % args)
        if args.stack_details_file.endswith('.xml'):
            self.log.debug("Parsing XML config file: %s" % args.stack_details_file)
            config = self.parse_vcd_xml_file(args.stack_details_file)
        else:
            self.log.debug("Parsing JSON config file: %s" % args.stack_details_file)
            config = self.parse_openstack_json_file(args.stack_details_file)

        config.workflow_instance_identifier = args.workflow_instance_identifier
        config.emergency_username = self.get_value_or_fallback_on_none(args.user_name, config.emergency_username)
        config.key_file = args.key_file
        config.password_file = args.password_file
        config.termination_type = args.termination_type
        config.termination_timer = args.shutting_down_timer
        config.termination_timer_file = '/tmp/lcm_shutdown_timer_%s' % config.workflow_instance_identifier
        self.log.debug("Parameters parsed from config: %s" % config)
        self.config = config
        self.check_if_canceled(args)
        return config

    def parse_openstack_json_file(self, config_file):
        with open(config_file) as json_file:
            config_data = json.load(json_file)

        config = LcmTaskConfig()
        try:
            stack_params = config_data["stack"]["parameters"]
            config.stack_name = config_data["stack"]["stack_name"]
            config.emergency_username = config_data["stack"]["parameters"]["emergency_username"]
            config.mip = self.get_value_or_fallback_on_match(
                stack_params["OM_IPv4_address"].strip(),
                stack_params["OM_IPv6_address"].strip(), "none")
        except KeyError as ex:
            self.log.error("A field is missing from the JSON file: %s" % ex)
            self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)
        return config

    def parse_vcd_xml_file(self, config_file):
        parser = VCDXmlParser(config_file)
        v_app = parser.vnf_status_file
        v_app_name = v_app.attrib.get("name")
        if v_app_name is None:
            self.log.error("Could not fetch 'name' parameter while parsing input data")
            self.handle_config_file_error(config_file)

        config = LcmTaskConfig()
        config.stack_name = v_app_name
        config.emergency_username = parser.get_property("emergency_username").strip()
        config.mip = self.get_value_or_fallback_on_match(
            parser.get_property('OM_IPv4_address').strip(),
            parser.get_property('OM_IPv6_address').strip(), "none")
        return config


if __name__ == '__main__':
    # C0103(invalid-name)
    # pylint: disable=C0103
    setup_default_logging()
    pre_termination = PreTermination()
    pre_termination.do_pre_terminate()

# C0111(missing-docstring), R0205(useless-object-inheritance), R0903(too-few-public-methods)
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# pylint: disable=C0111, R0903

# Workaround for VMTAS-17068:
# W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=W0311


class LcmTaskConfig(object):
    """
    Lcm task configuration magic container.
    It can hold any configuration parameter, and returns undefined parameters as None
    """
    def __init__(self, **kwargs):
        if kwargs is not None:
            for key, value in kwargs.items():
                self.__dict__[key] = value

    def __setattr__(self, key, value):
        self.__dict__[key] = value

    def __setitem__(self, key, value):
        self.__dict__[key] = value

    def __getattr__(self, item):
        return None

    def __str__(self):
        return str(self.__dict__)

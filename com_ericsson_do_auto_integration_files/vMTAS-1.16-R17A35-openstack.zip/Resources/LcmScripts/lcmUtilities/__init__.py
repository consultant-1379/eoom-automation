# C0111(missing-docstring)
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# pylint: disable=C0111

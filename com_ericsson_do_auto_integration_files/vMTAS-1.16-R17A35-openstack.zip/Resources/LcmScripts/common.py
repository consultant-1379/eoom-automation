#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# C0111(missing-docstring), W0402(deprecated-module), R0205(useless-object-inheritance), W0703(broad-except)
# pylint: disable=C0111, W0402, W0703

# Required unused import for IDE type hinting: W0611(unused-import)
# pylint: disable=W0611

# Continue refactoring these:
# R0913(too-many-arguments), R0904(too-many-public-methods), W0141(use-builtin-function filter)
# pylint: disable=R0913, R0904, W0141

# Workaround for VMTAS-17068:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311

from __future__ import (absolute_import, division, print_function, unicode_literals)

import argparse
import os
import re
import shutil
import socket
import string
import sys
from os import path

from paramiko import SSHException, AuthenticationException
from paramiko.ssh_exception import NoValidConnectionsError

import imscommon.logging
from imscommon import SSHUtility
from imscommon.consts import ReturnCode
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig


# noinspection PyBroadException
class CommonLcmTask(object):
    STORAGE_PATH = "/tmp/workflow-hooks"
    ADMIN_STATE_MO = "ManagedElement=1,MtasFunction=MtasFunction,mtasFunctionAdministrativeState"
    ADMIN_STATE_NAME = "mtasFunctionAdministrativeState"

    def __init__(self):
        self.ssh = None
        self.state = []  # type: list
        self.workflow = None
        self.config = None  # type: LcmTaskConfig
        self.log = LcmOutputManager(tag="vMTAS-CommonLcmTask")
        self.log.debug("cli arguments: %s" % sys.argv)

    def __del__(self):
        if self.ssh:
            self.ssh.close()

    def lcm_work_dir(self):
        return "%s/%s" % (CommonLcmTask.STORAGE_PATH, self.config.workflow_instance_identifier)

    def quit_with_code(self, code):
        """ Prints textual representation of the error code to the debug log, then exits with that code """
        self.log.debug("Send result [%s]"
                       % list(vars(ReturnCode).keys())[list(vars(ReturnCode).values()).index(code)])
        if code not in (ReturnCode.REPEAT, ReturnCode.SUCCESS):
            self.rm_work_dir()
        sys.exit(code)

    def connect_to_host(self, host, username, key_filename=None, password=None, port=22):
        """ Connect to a remote host """
        if key_filename is None:
            self.ssh = SSHUtility.SSHUtility(ip=host, username=username, password=password, port=port, keep_alive=True)
        else:
            self.ssh = SSHUtility.SSHUtility(
                ip=host, username=username, key_filename=key_filename, port=port, keep_alive=True)

        try:
            self.ssh.connect()
        except (RuntimeError, NoValidConnectionsError, EOFError, socket.timeout, socket.error):
            self.log.info("Connecting to host is not yet successful")
            self.quit_with_code(ReturnCode.REPEAT)

        return self.ssh

    def connect_with_config(self):
        """ Connect to the VNF using the script configuration """
        if self.config.key_file is not None:
            if os.access(self.config.key_file, os.R_OK):
                try:
                    return self.connect_to_host(self.config.mip,
                                                self.config.emergency_username,
                                                key_filename=self.config.key_file)
                except Exception:
                    self.log.warning("Private key exists, but failed to log in using it.")
                    self.handle_connection_fallback()
            self.log.warning("Can't read private key: %s" % self.config.key_file)

        if self.config.password_file is not None:
            if os.access(self.config.password_file, os.R_OK):
                with open(self.config.password_file, 'r') as pw_file:
                    try:
                        return self.connect_to_host(self.config.mip,
                                                    self.config.emergency_username,
                                                    password=pw_file.read())
                    except Exception:
                        self.log.warning("Password file exists, but failed to log in using it.")
                        self.handle_connection_fallback()
            self.log.warning("Can't read password file: %s" % self.config.key_file)

        self.handle_connection_fallback()

    def handle_connection_fallback(self):
        """
        This method tries to log in using the emergency username, using paramiko key discovery, if that fails it will
        retry with the default root user, using the default root password or send a REPEAT code if that also fails.
        """
        try:
            # Fallback to key discovery if both password and key parameters are missing
            self.log.debug("Login using key discovery.")
            return self.connect_to_host(self.config.mip, self.config.emergency_username)
        except (AuthenticationException, SSHException):
            try:
                # Fallback to default password
                return self.connect_to_host(self.config.mip, username='root', password='rootroot')
            except Exception:
                # Retry if connection was not successful
                self.log.info("Connecting to host is not yet successful")
                self.quit_with_code(ReturnCode.REPEAT)

    @staticmethod
    def is_builtin_node(node):
        """
        Checks if the node name contains builtin names.
        On openstack it is an exact match, while in vmware it is substring match
        """
        for builtin in ("SC-1", "SC-2", "PL-3", "PL-4"):
            if builtin in node.upper():
                return True
        return False

    @staticmethod
    def is_scalable_node(node):
        return not CommonLcmTask.is_builtin_node(node)

    @staticmethod
    def filter_command_string(command):
        return ''.join([x for x in command if x in string.printable])

    def run_com_cli_command(self, command, configure_mode=True, enforce_commit=True):
        command = self.filter_command_string(command)
        if configure_mode:
            if not command.endswith("commit\n") and enforce_commit:
                command += "\ncommit\n"
            cmd = "(echo -e 'scriptmode --on\nconfigure\n%s\nexit\n'; sleep 1) | /opt/com/bin/cliss" % command
        else:
            cmd = "(echo -e 'scriptmode --on\n%s\nexit\n'; sleep 1) | /opt/com/bin/cliss" % command

        out, _, code = self.ssh.run_command(cmd, fail_at_error=False)
        if code:
            self.log.error("Could not run cliss command.")
            self.quit_with_code(ReturnCode.CLISS_ERROR)

        if re.search('^ERROR:', out, re.MULTILINE | re.IGNORECASE):
            self.log.debug("COM result contained ERROR!")
            return None

        return out

    def create_vnflcm_dir(self):
        if not os.path.exists(self.lcm_work_dir()):
            os.makedirs(self.lcm_work_dir(), mode=0o755)

    def read_state_file(self, workflow):
        self.workflow = workflow
        state_file = "%s/%s_wf_state" % (self.lcm_work_dir(), self.workflow)
        try:
            self.state = [line.rstrip('\n') for line in open(state_file)]
        except IOError:
            self.state = []

    def perform_step(self, config_step):
        return not self.is_config_step_done(config_step)

    def is_config_step_done(self, config_step):
        if config_step in self.state:
            self.log.debug("perform_step: [%s] is already performed" % config_step)
            return True
        self.log.debug("perform_step: [%s] is pending" % config_step)
        return False

    def rm_state_file(self):
        self.log.debug("rm_state_file: Deleting state file")
        state_file = "%s/%s_wf_state" % (self.lcm_work_dir(), self.workflow)
        os.remove(state_file)

    def rm_work_dir(self):
        self.log.debug("rm_work_dir: Deleting work directory")
        shutil.rmtree(self.lcm_work_dir())

    def update_state_file(self, config_step):
        self.log.debug("update_state_file: Updating state file with [%s]" % config_step)
        self.state.append(config_step)
        state_file = '%s/%s_wf_state' % (self.lcm_work_dir(), self.workflow)
        with open(state_file, 'w') as file:
            file.writelines(["%s\n" % item for item in self.state])

    def can_iterate_step(self, step_name, max_wait=999):
        """
        Simple way to make a step iterate a fixed amount of times over retried script executions
        """
        for count in range(max_wait):
            step_iteration_name = "%s_%03d" % (step_name, count)
            if not self.is_config_step_done(step_iteration_name):
                self.update_state_file(step_iteration_name)
                self.log.debug("can_iterate_step[%s], loop: %d" % (step_name, count))
                return True

        self.log.debug("Max waiting time exceeded")
        return False

    @staticmethod
    def write_vnflcm_file(text, file):
        with open(file, 'w') as file:
            file.write(text)

    @staticmethod
    def read_vnflcm_file(file):
        try:
            with open(file, 'r') as file:
                return file.read()
        except IOError:
            return None

    def write_file(self, text, file):
        cmd = "echo '%s' > '%s'" % (text, file)
        self.log.debug("write_file: running command [%s]" % cmd)
        _, _, code = self.ssh.run_command(cmd, fail_at_error=False)
        return code == 0

    def read_file(self, file):
        cmd = "cat '%s'" % file
        self.log.debug("read_file: running command [%s]" % cmd)
        stdout, _, code = self.ssh.run_command(cmd, fail_at_error=False)
        return stdout if code == 0 else None

    def cp_file(self, s_file, d_file):
        cmd = "cp -f %s %s" % (s_file, d_file)
        self.log.debug("cp_file: running command [%s]" % cmd)
        self.ssh.run_command(cmd, fail_at_error=False)

    def rm_file(self, file):
        cmd = "rm -f %s" % file
        self.log.debug("rm_file: running command [%s]" % cmd)
        self.ssh.run_command(cmd, fail_at_error=False)

    def mv_file(self, s_file, d_file):
        cmd = "mv -f %s %s" % (s_file, d_file)
        self.log.debug("mv_file: running command [%s]" % cmd)
        self.ssh.run_command(cmd, fail_at_error=False)

    def read_admin_state(self):
        command = "show %s" % self.ADMIN_STATE_MO
        com_result = self.run_com_cli_command(command, configure_mode=False)
        if com_result:
            for line in com_result.split("\n"):
                if "%s=" % self.ADMIN_STATE_NAME in line:
                    state = line.split("=")[1]
                    return state

        self.log.error("Failed to read %s" % self.ADMIN_STATE_NAME)
        self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

    def update_admin_state(self, status):
        command = "%s=%s" % (self.ADMIN_STATE_MO, status)
        com_result = self.run_com_cli_command(command)
        if com_result is None:
            self.log.error("Failed to update %s" % self.ADMIN_STATE_NAME)
            self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

    def get_equipment_data(self):
        """
        This method will fetch the node-names/cluster-members
        and their UUID from COM CLI
        """
        cmd = "show -r -m ComputeResource -p uuid"
        return self.run_com_cli_command(cmd, configure_mode=False)

    def get_pl_name_to_uuid_dict(self, equipment):
        """
        This method returns a hashmap/dict with node name as key (e.g. PL-3)
        and the value is the UUID of the node/cluster-member
        """
        match = re.findall('^[\\w,=-]+(\\w{2}-\\d+)$\\s+uuid="([\\w-]+)"$', equipment, re.MULTILINE)
        pl_to_uuid = dict(match)
        self.log.debug("PL to UUID [%s]" % pl_to_uuid)
        return pl_to_uuid

    def get_mac_to_sc_or_pl_name_dict(self):
        result = {}
        cmd = "show -r -m ComputeResource -p macAddress"
        try:
            com_result = self.run_com_cli_command(cmd, configure_mode=False)
            match = re.findall(
                '^[\\w,=-]+(\\w{2}-\\d+)$\\s+macAddress\\s*$((?:\\s*(?:\"(?:[\\w\\d]{2}:){5}[\\w\\d]{2}\"\\s*)$)+)',
                com_result, re.MULTILINE)

            for res in match:
                node = res[0]
                macs = res[1].strip().replace("\"", "").split()
                for mac in macs:
                    self.log.debug("MAC address [%s] belongs to VM/node [%s]" % (mac, node))
                    result[mac] = node
            self.log.debug("MAC to VM [%s]" % result)
            return result
        except Exception:
            self.log.error("Failed to get equipment data")
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def mtas_small_restart(self):
        self.run_com_cli_command(
            "ManagedElement=1,MtasFunction=MtasFunction,mtasFunctionSmallRestart", configure_mode=False)

    def string_to_int(self, int_str):
        try:
            return int(int_str)
        except Exception:
            self.quit_with_code(ReturnCode.STRING_TO_INT_ERROR)

    def handle_config_file_error(self, config_file_name):
        if path.exists(config_file_name):
            with open(config_file_name, 'r') as file_handle:
                self.log.debug("File [%s] had problems during parsing - file content:\n%s"
                               % (config_file_name, file_handle.read()))
        else:
            self.log.debug("File [%s] can not be opened - exiting..." % config_file_name)
        self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)

    @staticmethod
    def get_value_or_fallback_on_none(user, fallback):
        return fallback if user is None else user

    @staticmethod
    def get_value_or_fallback_on_match(value, fallback, match):
        return fallback if value == match else value

    def graceful_cancel(self):
        """ Default graceful cancel. Removes the work directory, then quits with REJECT """
        self.rm_work_dir()
        self.quit_with_code(ReturnCode.REJECT)

    def check_if_canceled(self, args):
        if args.quit_operation is not None:
            self.graceful_cancel()

    @staticmethod
    def argmunet_parsing_base(description):
        parser = argparse.ArgumentParser(description=description)
        parser.add_argument('-f', '--stack-details-file', '--vnf-instance-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of '
                                 'stack show details (OpenStack) or vAPP details (vCloud Director) '
                                 'command in json (OpenStack) or xml (vCloud Director) format.', required=True)
        parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                            help='Username to login into the VNF instance.', type=str, required=False)
        auth_args = parser.add_mutually_exclusive_group()
        auth_args.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                               help='Path to the file containing the private key for login.', type=str, required=False)
        auth_args.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                               help='Path to the file containing the password to login into the VNF instance.',
                               type=str, required=False)
        parser.add_argument('-i', '--workflow-instance-identifier', metavar='<ID>',
                            help='Clarifies which workflow instance is running currently.'
                                 ' Can be used to make the log more readable.', type=str, required=False)
        parser.add_argument('-q', '--quit-operation', metavar='cancel',
                            help='Gracefully cancels LCM script hook.'
                                 ' After the cancellation argument is passed, further overriding on the workflow UI'
                                 ' is disabled,but the script is still allowed to repeat with exit code 100'
                                 ' until it considers the cancellation complete.',
                            choices=['cancel'], type=str, required=False)
        return parser


def setup_default_logging():
    imscommon.logging.configure_logging()

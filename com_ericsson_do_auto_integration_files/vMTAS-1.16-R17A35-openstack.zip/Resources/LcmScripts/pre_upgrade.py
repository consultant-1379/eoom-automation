#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# C0111(missing-docstring)
# pylint: disable=C0111

# Workaround for VMTAS-17068:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311

import sys
from imscommon.consts import ReturnCode

if __name__ == '__main__':
    sys.stderr.write("This WF is not supported in the current release!")
    sys.exit(ReturnCode.RETURN_ERROR)

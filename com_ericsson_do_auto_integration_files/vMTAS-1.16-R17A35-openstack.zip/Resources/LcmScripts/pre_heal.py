#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034788/1
# Package Revision: R6E01
# Package Date: 2019-07-05
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

"""
This workflow will be reworked from the ground, pylint should be re-enabled at that point
"""
# pylint: disable-all
from __future__ import (absolute_import, division,
                        print_function, unicode_literals)

import argparse
import json
import logging
import os
import re
import sys
import time

from imscommon import SSHUtility
from imscommon.consts import ReturnCode


class preHealing:
    class InputData:
        def __init__(self, mip, key_file, emergency_user, id, uuids, paramValue, healType):
            self.mip = mip
            self.key_file = key_file
            self.emergency_user = emergency_user
            self.id = id
            self.paramValue = paramValue
            self.uuids = uuids
            self.healType = healType

    def __init__(self):
        self.input_data = preHealing.argument_parsing()
        self.ssh = self.connect_to_host(host=self.input_data.mip,
                                        username=self.input_data.emergency_user,
                                        key_filename=self.input_data.key_file,
                                        port=22)

        if not self.check_connection():
            logger.debug("Trying to SSH to the node")
            print("Trying to SSH to the node")
            sys.exit(ReturnCode.REPEAT)
        healingPl = None
        healingUUID = None
        if self.input_data.healType == "auto":
            m = re.search("SaClmNode\.safNode=(PL-[\d]+)", self.input_data.paramValue)
            if m:
               healingPl = m.group(1)
            if not healingPl:
               sys.stderr.write("The WF was triggered for a non-healable VM (SC-1 or SC-2).")
               sys.exit(ReturnCode.STD_ERROR)

            if healingPl in ["PL-3","PL-4"]:
               sys.stderr.write("The WF was triggered for a non-healable VM (PL-3 or PL-4).")
               sys.exit(ReturnCode.STD_ERROR)

            healingUUID = self.readUUIDfromFile()
            if not healingUUID:
               healingUUID = self.getPlUUID(healingPl)
            if not healingUUID:
               sys.stderr.write("The following PL is not part of the cluster: " + healingPl)
               sys.exit(ReturnCode.STD_ERROR)
        elif self.input_data.healType == "manual":
            healingUUID = self.input_data.paramValue
            if healingUUID not in self.input_data.uuids:
               sys.stderr.write(healingUUID + " is not a valid UUID. Not a scalable VM of the stack")
               sys.exit(ReturnCode.STD_ERROR)
            healingPl = self.getPlbyUUID(healingUUID)

        self.checkPlInscaling()
        if not self.getPlbyUUID(healingUUID):
           self.genScalingOutput(healingUUID)
           self.removeUUIDFile()
           sys.exit(ReturnCode.SUCCESS)
        self.checkPlStatus(healingPl)
        self.updateUUIDFile(healingUUID)
        self.scaleInPls(healingPl)
        sys.stdout.write("Healing is ongoing. Waiting for cluster activity to finish")
        time.sleep(10)
        sys.exit(ReturnCode.REPEAT)

    def genScalingOutput(self, uuid):
        result = {"UUIDToBeHealed": uuid}
        print(json.dumps(result))

    def getPlbyUUID(self, uuid):
        uuid_command = "show -r -m ComputeResource  -c uuid==" + uuid
        stdout, stderr, retcode = self.run_com_cli_command(uuid_command)
        if retcode != 0:
           sys.stderr.write("Failed to read PL node list")
           sys.exit(ReturnCode.RETURN_ERROR)
        m = re.findall("ComputeResource=(PL-[\d]+)",stdout)
        if m:
           return m[0]
        else:
           return None

    def scaleInPls(self, Pl):
        cmdStr = "no ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=" + Pl + ",provides\n"
        cmdStr += "commit\n"
        stdout, stderr, retcode = self.run_com_cli_command(cmdStr)
        if retcode !=0:
            sys.stderr.write("Scaling in is not possible. Error: " + stderr)
            sys.exit(ReturnCode.RETURN_ERROR)


    def checkPlInscaling(self):
        cmdInsState = "show -r -m ComputeResourceRole  -p instantiationState"
        stdout, stderr, retcode = self.run_com_cli_command(cmdInsState)
        if retcode == 0:
            m = re.findall("instantiationState=([\w]+)$",stdout,re.MULTILINE)
            for InsState in m:
                if InsState in ["INSTANTIATING","UNINSTANTIATING"]:
                   sys.stdout.write("| some PL is in " + InsState)
                   sys.exit(ReturnCode.REPEAT)
        else:
            sys.stderr.write("Failed to read PL status")
            sys.exit(ReturnCode.RETURN_ERROR)

    def checkPlStatus(self, Pl):
        cmdInsState = "show ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=" + Pl +",instantiationState"
        InsState = self.readParamStatus(cmdInsState)
        if InsState == "UNINSTANTIATION_FAILED":
           sys.stderr.write("Healing was unsuccessful because PL is in UNINSTANTIATION_FAILED")
           sys.exit(ReturnCode.RETURN_ERROR)

    def getPlUUID(self, Pl):
        cmdInsState = "show ManagedElement=1,Equipment=1,ComputeResource=" + Pl + ",uuid"
        uuid = self.readParamStatus(cmdInsState)

        return uuid.replace("\"","")


    def readUUIDfromFile(self):
        stdout, stderr, retcode = self.ssh.run_command("cat /cluster/home/vnflcm/uuid_" + self.input_data.id , fail_at_error=False)
        if retcode == 0:
            return stdout.strip()
        else:
            return None

    def updateUUIDFile(self, uuid):
        stdout, stderr, retcode = self.ssh.run_command("echo " + uuid + "> /cluster/home/vnflcm/uuid_"  + self.input_data.id, fail_at_error=False)
        if retcode != 0:
           logger.warn("Can not update the uuid file")

    def removeUUIDFile(self):
        self.ssh.run_command("rm -rf /cluster/home/vnflcm/uuid_*", fail_at_error=False)

    def connect_to_host(self, host, username, key_filename=None, port=22):
        ssh = SSHUtility.SSHUtility(ip=host,
                                    username=username,
                                    key_filename=key_filename,
                                    port=port,
                                    keep_alive=True)
        return ssh

    def check_connection(self):
        try:
            self.ssh.run_command("w")
        except:
            return False
        return True

    def run_com_cli_command(self, command, configure_mode=True):
        import string
        printable = set(string.printable)
        cmd = filter(lambda x: x in printable, command)
        if configure_mode:
            cmmnd = "(echo 'scriptmode --on\nconfigure\n" + cmd + "\nend\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        else:
            cmmnd = "(echo 'scriptmode --on\n" + cmd + "\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        stdout, stderr, retcode = self.ssh.run_command(cmmnd, fail_at_error=False)
        return stdout, stderr, retcode

    def readParamStatus(self, command):
        stdout, stderr, retcode = self.run_com_cli_command(command)
        if retcode == 0:
           for line in stdout.split("\n"):
               state = line.split("=")[1]
               logger.info(command + " " +state)
               return state

        logger.warn("Failed to read command: " + command)
        sys.exit(ReturnCode.ADMIN_STATE_ERROR)

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='pre_scale_in hook for workflow')
        parser.add_argument('-f', '--stack-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of '
                                 'stack show details (OpenStack) or vAPP details (vCloud Director) '
                                 'command in json (OpenStack) or xml (vCloud Director) format.',
                            type=str, required=True)
        parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                            help='Path to the file containing the private key for login', type=str, required=False)
        parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                            help='USERNAME', type=str, required=False)
        parser.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                            help='PASSWORD_FILE', type=str, required=False)
        parser.add_argument('-l', '--auto-healing-info-file', metavar='<AUTO_HEALING_INFO_FILE>',
                            help='Path to the file containing the alarm information parameters',
                            type=str, required=False)
        parser.add_argument('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
                            help='Path to the file containing UUID to be healed',
                            type=str, required=False)
        parser.add_argument('-i', '--workflow-instance-identifier', metavar='<ID>',
                            help='Clarifies which workflow instance is running currently.'
                                 ' Can be used to make the log more readable.',
                            type=str, required=False)
        args = parser.parse_args()
        with open(args.stack_details_file) as json_file:
            jsonfile = json.load(json_file)

        paramfile = args.auto_healing_info_file
        paramName = "managedObject"
        healType="auto"
        if not paramfile:
           paramfile = args.additional_param_file
           paramName = "UUIDToBeHealed"
           healType = "manual"

        key_file = args.key_file
        uuids = None
        mip = None
        managedObj = None
        specifiedUUID = None
        emergency_user = jsonfile["stack"]["parameters"]["emergency_username"]
        if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
            mip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
        else:
            mip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()

        obj = jsonfile["stack"]["outputs"]
        for x in obj:
            if x["output_key"] == "scaled_VMs_UUID":
                uuids = x["output_value"].strip().split()

        stack_file = os.path.basename(args.stack_details_file)
        id = stack_file.split('_')[1].split('.')[0]

        paramValue = None
        with open(paramfile) as alarm_json:
             alarmjs = json.load(alarm_json)
             paramValue = alarmjs[paramName].strip()


        return	preHealing.InputData(mip, key_file, emergency_user, id, uuids, paramValue, healType)

def main():
    prehealing = preHealing()

if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING,
                        format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
    logger = logging.getLogger('preHealing')
    main()



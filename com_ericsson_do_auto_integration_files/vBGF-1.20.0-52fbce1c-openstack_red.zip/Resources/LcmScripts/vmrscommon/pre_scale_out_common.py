#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

import json
import logging
from .lcm_common import (
    ReturnCode,
    Exit,
    LcmHook,
)

logger = logging.getLogger('pre_scale_out')


# https://github.com/PyCQA/pylint/issues/179
# Pylint can't detect if a class is less abstract but still not concrete.
# pylint: disable=W0223
class PrescaleOut(LcmHook):

    def __init__(self, args):
        super(PrescaleOut, self).__init__()
        self.number_of_steps, self.payload_instance_count = \
            self.argument_parsing(args)

    def argument_parsing(self, args):
        self.add_common_arguments('pre_scale_out hook for workflow')
        self.mandatory.add_argument(
            '-n', '--number-of-steps', metavar='<STEPS>',
            help='Number of scaling steps.',
            type=int,
            required=True)
        self.parser.add_argument(
            '-x', '--aspect-id', metavar='<ASPECT_ID>',
            help='The aspect ID of the scaling group to scale.',
            required=False)
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.', required=False)
        self.parser.add_argument(
            '-l', '--auto-scale-info-file',
            metavar='<AUTO_SCALE_INFO_FILE>',
            help='Auto Scale information parameters.',
            required=False)
        self.parsed_args = self.parser.parse_args(args)

        self.vnf_instance_file_parser = self.get_parser()

        number_of_steps = self.parsed_args.number_of_steps
        if number_of_steps < 0:
            logger.error("Invalid number of steps parameter: %s",
                         number_of_steps)
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)
        payload_instance_count = self.vnf_instance_file_parser.get_payload_instance_count()
        return number_of_steps, payload_instance_count

    def is_vcd(self):
        return self.parsed_args.vnf_instance_details_file.endswith('.xml')

    def dump_scaling_list_output_json(self):
        if self.is_vcd():
            return self.dump_scaling_list_output_json_vcd()
        else:
            return self.dump_scaling_list_output_json_os()

    def dump_scaling_list_output_json_os(self):
        count = self.number_of_steps + self.payload_instance_count
        output = {"payload_instance_count": str(count)}
        return json.dumps(output)

    def dump_scaling_list_output_json_vcd(self):
        count = self.number_of_steps
        output = {"number_of_vms_to_be_added": str(count)}
        return json.dumps(output)

    def pre_scale_out_hook(self):
        if self.parsed_args.quit_operation:
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        return self.dump_scaling_list_output_json()

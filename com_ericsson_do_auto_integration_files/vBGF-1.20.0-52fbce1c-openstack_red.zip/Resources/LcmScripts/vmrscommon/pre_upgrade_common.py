#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

import re
import os
import json
import yaml
import logging
from .lcm_data import VnfInstanceData
from .lcm_common import LcmHook
from imscommon.parsers import OpenstackJsonParser
try:
    from imscommon.parsers import VCDXmlParserExtended
except ImportError:
    # might happen with newer packages running with old workflows?
    # this should be fine if it is not a vmware VNF upgrade anyway
    pass
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from imscommon import SSHUtility
from .utils import CliExecutor

logger = logging.getLogger('pre_upgrade')


class PreUpgrade(LcmHook):
    """
    Pre upgrade for VNFs:

    create new environment file from stack details and etc
    """

    def generate_get_mo_instance_id_script(self, uuid):
        """ Upgrade does not need this. """
        raise NotImplementedError()

    @staticmethod
    def raise_if_vcd_parser_missing():
        try:
            VCDXmlParserExtended.__class__
        except NameError:
            # means it was not imported properly
            logger.error(
                "Class 'VCDXmlParserExtended' is missing from "
                "common workflows (imscommon). It is necessary to "
                "run the upgrade workflows on a VMWare VNF instance. "
                "Please uplift your vIMSWorkflows package "
                "to a newer version."
            )
            raise Exit(ReturnCode.PARSE_ERROR)

    class InputData:
        def __init__(self, user_name, ip,
                     uuids=None, resource_names=None,
                     key_filename=None, password=None, port=22,):
            self.user_name = user_name
            self.ip = ip
            self.uuids = uuids
            self.resource_names = resource_names
            self.port = port
            self.key_filename = key_filename
            self.password = password

    def __init__(self, args):
        super(PreUpgrade, self).__init__()
        self.input_data = self.argument_parsing(args)
        ssh = SSHUtility.SSHUtility(
            ip=self.input_data.ip,
            username=self.input_data.user_name,
            password=self.input_data.password,
            key_filename=self.input_data.key_filename,
            port=self.input_data.port,
            keep_alive=True
        )
        self.cli = CliExecutor(ssh)
        self.env = {}
        self.main_hot_yaml_path = None

    def argument_parsing(self, args):
        self.add_common_arguments('Pre upgarade script for vBGF')

        arg = self.parser.add_argument
        arg('-e', '--environment',
            help='Path to new environment file',
            required=True)
        arg('-s', '--sourceversion',
            help='Version of the source',
            required=True)
        arg('-t', '--targetversion',
            help='Version of the source will be converted',
            required=True)

        self.parsed_args = self.parser.parse_args(args)

        self.cloud_type = self.get_cloud_type()

        if self.cloud_type == 'OPENSTACK':
            self.vnf_instance_file_parser = OpenstackJsonParser(
                self.parsed_args.vnf_instance_details_file
            )
        elif self.cloud_type == 'VMWARE':
            self.raise_if_vcd_parser_missing()
            self.vnf_instance_file_parser = VCDXmlParserExtended(
                self.parsed_args.vnf_instance_details_file
            )

        self.vnf_instance_data = VnfInstanceData(
            *self.vnf_instance_file_parser.get_all_params()
        )

        input_data = PreUpgrade.InputData(
            self.get_active_user_name(),
            self.vnf_instance_file_parser.get_oam_public_ip(),
            self.vnf_instance_data.uuids,
            self.vnf_instance_data.resource_names,
            self.parsed_args.key_file
        )
        return input_data

    def get_cloud_type(self):
        instance_details_file = self.parsed_args.vnf_instance_details_file
        if instance_details_file.endswith('.json'):
            return 'OPENSTACK'
        if instance_details_file.endswith('.xml'):
            return 'VMWARE'

        logger.error(
            'Instance details file is unknown type (%s).',
            instance_details_file)
        raise Exit(ReturnCode.PARSE_ERROR)

    def pre_upgrade_hook(self):
        if self.parsed_args.quit_operation:
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        vnfdata = self.export_vnf_data()

        jsons = {}

        jsons['upgradeEnvironment'] = self.upgrade_environment(vnfdata)
        if self.cloud_type == 'OPENSTACK':
            self.hot_parameter_sanity_check(jsons['upgradeEnvironment'])

        jsons['rollbackEnvironment'] = self.create_rollback_env(vnfdata)

        return json.dumps(jsons)

    def get_main_hot_yaml_content(self):
        '''Return the parsed yaml contents of the main HOT file.'''
        with open(self.get_main_hot_yaml_path()) as f:
            return yaml.safe_load(f)

    def get_main_hot_yaml_path(self):
        '''
        This file can be in two locations relative to the LCM scripts:
            - vmrscommon/..(=lcmScripts)/..(=vnfDir)/main.ya?ml
            - vmrscommon/..(=LcmScripts)/..(=Resources)/..(=vnfDir)/*.ya?ml
        '''
        # if already found, do not look for it again:
        if self.main_hot_yaml_path is not None:
            return self.main_hot_yaml_path

        parent_dir = os.path.abspath(
            os.path.join(os.path.dirname(__file__), '..'))
        lcm_script_dirname = os.path.basename(parent_dir)

        if lcm_script_dirname == 'LcmScripts':
            logger.info('Upgrade package is ECM-HOT format.')
            vnfdir = os.path.abspath(
                os.path.join(parent_dir, '..', '..'))
            hotfile_re = r'\.ya?ml$'

        elif lcm_script_dirname == 'lcmScripts':
            logger.info('Upgrade package is legacy format?')
            vnfdir = os.path.abspath(
                os.path.join(parent_dir, '..'))
            hotfile_re = r'^main\.ya?ml$'
        else:
            logger.error(
                ('Cannot determine container package structure! '
                 'Parent dir was: %s'), parent_dir)
            raise Exit(ReturnCode.DATA_ERROR)

        logger.info('Looking for .ya?ml file under %s', vnfdir)
        for fname in os.listdir(vnfdir):
            fpath = os.path.join(vnfdir, fname)
            if not os.path.isfile(fpath):
                continue
            if re.search(hotfile_re, fname):
                logger.info('Found HOT file: %s', fpath)
                self.main_hot_yaml_path = fpath
                return fpath

        logger.error('Cannot find HOT file!')
        raise Exit(ReturnCode.RETURN_ERROR)

    def hot_parameter_sanity_check(self, upgrade_env):
        '''
        Make sure that all the mandatory HOT parameters (ie. the ones
        without defaults) are given values in the upgrade env.
        This might not be the case if a new HOT parameter was introduced.

        Make an exception for "vnf_name", as that will be overridden by
        the common workflows anyway.
        '''
        # /workaround for a test
        if self.parsed_args.no_package:
            logger.warn('Script not in package. Skipping check.')
            return
        # \workaround

        hot_params = self.get_main_hot_yaml_content()['parameters']

        params_missing = []
        for param in hot_params:
            # ignore 'vnf_name' and params which have defaults
            if (hot_params[param].get('default') is not None
                    or param == 'vnf_name'):
                continue
            if param not in upgrade_env['parameter_defaults']:
                params_missing.append(param)

        if params_missing:
            logger.error(
                ("Some HOT parameters are missing from the generated upgrade "
                 "env.yaml file (%s)! This is likely due to not providing "
                 "values to new HOT parameters added in this VNF version. "
                 "Please refer to the CPI."), params_missing)
            raise Exit(ReturnCode.REJECT)

    def upgrade_source_env_sanity_check_os(self):
        '''
        Make sure the upgrade source env file has the mandatory parameters.
        - In case of Openstack this means flavors and images at least
        '''
        params_expected = self.get_upgrade_env_mandatory_hot_params()
        params_missing = [
            p for p in params_expected
            if p not in self.env['parameter_defaults']
        ]
        if not params_missing:
            return

        logger.error(
            ('The following mandatory parameters are missing from '
             'the upgrade env.yaml file: %s'), params_missing)
        raise Exit(ReturnCode.REJECT)

    def get_upgrade_env_mandatory_hot_params(self):
        '''
        Get the mandatory HOT parameters that will not be migrated
        from older versions.
        '''
        raise NotImplementedError()

    def upgrade_source_env_sanity_check_vcd(self):
        '''
        Make sure the upgrade source env file has the mandatory parameters.
        - In case of vCD, this currently means the "template" key.
        '''
        if not self.env.get('template'):
            logger.error(
                "Upgrade environment file must contain a 'template' "
                "key that points to a valid vApp template!")
            raise Exit(ReturnCode.REJECT)

    def upgrade_environment(self, vnfdata):
        """Upgrade the environment file to the new version."""
        self.env = self.read_env()

        if self.cloud_type == 'OPENSTACK':
            self.upgrade_source_env_sanity_check_os()
            convrules = OpenstackJsonParser(
                self.get_convrules_path()).vnf_status_file
        elif self.cloud_type == 'VMWARE':
            self.upgrade_source_env_sanity_check_vcd()
            convrules = OpenstackJsonParser(
                self.get_convrules_path_vcd()).vnf_status_file
            if not self.env.get('product_section_parameters'):
                self.env['product_section_parameters'] = {}

        self.upgrade_env_with_rules(convrules)
        self.extract_secret_settings()
        self.add_instance_config(vnfdata)
        self.payload_instance_count_update()
        self.vnf_spec_upgrade()

        return self.env

    def read_env(self):
        """Load the environent file"""
        with open(self.parsed_args.environment) as yamfile:
            return yaml.safe_load(yamfile)

    def add_instance_config(self, vnfdata):
        if self.cloud_type == 'OPENSTACK':
            self.env['parameter_defaults'][self.get_vnf_data_env_key()] = vnfdata
        elif self.cloud_type == 'VMWARE':
            self.env['product_section_parameters'][self.get_vnf_data_env_key_vcd()] = vnfdata

    def payload_instance_count_update(self):
        """
        Update payload_instance_count based on number of VMs
        in 'cluster list' command. This is needed to keep backward
        compatibility with older vMRS versions deployed on OpenStack / CEE,
        where payload_instance_count was one less than actual number of VMs.
        If the 'standby_payload_instance_count' parameter exists
        in the stack show data, it needs to be substracted from
        the number of VMs in the cluster to get the true instance oount.
        """
        if self.cloud_type != 'OPENSTACK':
            return
        instance_count = len(
            json.loads(self.cli.run_cli_remote("cluster list --json"))
        )
        standby_count = self.env['parameter_defaults'].get(
            'standby_payload_instance_count', 0
        )
        try:
            standby_count = int(standby_count)
        except ValueError:
            logger.error(
                "Invalid 'standby_payload_instance_count' in input! ('%s')",
                standby_count
            )
            raise Exit(ReturnCode.INVALID_PAYLOAD_INSTANCE_COUNT)

        self.env['parameter_defaults']['payload_instance_count'] = str(
            instance_count - standby_count
        )

    def upgrade_env_with_rules(self, convrules):
        """
        Copy settings from stack data to env with respect to
        blocking rules and apply rules
        """
        block = ""
        for val in convrules['globalrules']['block']:
            block += val + '|'
        block += r'\0'
        logger.debug("Block regex: %r", block)
        regex = re.compile(block)

        if self.cloud_type == 'OPENSTACK':
            self.upgrade_env_with_rules_openstack(convrules, regex)
        elif self.cloud_type == 'VMWARE':
            self.upgrade_env_with_rules_vcd(convrules, regex)

    def upgrade_env_with_rules_openstack(self, convrules, regex):
        stack = self.vnf_instance_file_parser.vnf_status_file['stack']

        for attr, val in stack['parameters'].iteritems():
            if regex.search(attr) is None:
                self.env['parameter_defaults'][attr] = val

        self.process_conv_rulesets(
            self.env['parameter_defaults'], stack['parameters'], convrules
        )

    def upgrade_env_with_rules_vcd(self, convrules, regex):
        prod_section = self.env['product_section_parameters']
        vapp_properties = self.vnf_instance_file_parser.get_user_configurable_vapp_properties()
        for prop, val in vapp_properties.iteritems():
            if regex.match(prop) is None:
                logger.debug("Adding %r to env with value %r", prop, val)
                prod_section[prop] = val

        if not self.env.get('template', None):
            logger.error(
                "The upgrade target config (env-vcd.y(a)ml) is missing "
                "'template' entry! It must contain this parameter and "
                "it must point to a valid template "
                "in your vCloud Director!"
            )
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        if not self.env.get('vapp_affinity', None):
            aff_rule = self.vnf_instance_file_parser.get_affinity_rule()
            logger.info(
                ("Parameter 'vapp_affinity' was missing from upgrade "
                 "target config. Adding value %r"),
                aff_rule
            )
            self.env['vapp_affinity'] = aff_rule

        network_data = self.vnf_instance_file_parser.get_grouped_networks()
        self.upgrade_vcd_org_networks(
            network_data['org_networks'], convrules)
        self.upgrade_vcd_vapp_networks(
            network_data['vapp_networks'], convrules)
        self.process_conv_rulesets(prod_section, vapp_properties, convrules)

    def process_conv_rulesets(self, env, props, convrules):
        current_version = self.parsed_args.sourceversion
        rulesets = [
            val
            for val in convrules['rulesets']
            if current_version == val['sourceVersion']
        ]
        for val in rulesets:
            for rule in val['rules']:
                try:
                    del env[rule['source']]
                    env[rule['target']] = props[rule['source']]
                except KeyError:
                    logger.warning(
                        "Missing key from stack file or env file "
                        "while applying conversion rule"
                    )
            # TODO something seems amiss here.. this current_version
            #      is never used again, why is it being set?
            current_version = val['targetVersion']

    def upgrade_vcd_org_networks(self, org_network_dict, convrules=None):
        # TODO decide if convrules here are necessary/useful
        self.env['org_networks'] = org_network_dict

    def upgrade_vcd_vapp_networks(self, vapp_network_list, convrules=None):
        # TODO decide if convrules here are necessary/useful
        self.env['vapp_networks'] = vapp_network_list

    def create_rollback_env(self, vnfdata):
        """
        Create env-vcd.yaml or env-yaml that would be used
        by the rolled-back instance.
        """
        self.env = {}
        if self.cloud_type == 'OPENSTACK':
            self.create_rollback_env_openstack(vnfdata)
        elif self.cloud_type == 'VMWARE':
            self.create_rollback_env_vcd(vnfdata)

        self.add_instance_config(vnfdata)
        self.vnf_spec_upgrade()
        return self.env

    def create_rollback_env_vcd(self, vnfdata):
        """Create env-vcd.yaml from vApp details."""
        self.env['product_section_parameters'] = {}
        self.convert_vappdetails_to_env()
        self.extract_secret_settings()

    def create_rollback_env_openstack(self, vnfdata):
        """Create env.yaml from stackdetails."""
        self.env['parameter_defaults'] = {}
        self.convert_stackdetails_to_env()
        self.extract_secret_settings()

    def convert_vappdetails_to_env(self):
        """
        Convert vApp details XML into environment for orchestration.
        """
        # template name, affinity rule
        self.env['template'] = self.vnf_instance_file_parser.get_vapp_template_name()
        self.env['vapp_affinity'] = self.vnf_instance_file_parser.get_affinity_rule()
        # networks
        network_data = self.vnf_instance_file_parser.get_grouped_networks()
        self.upgrade_vcd_org_networks(network_data['org_networks'])
        self.upgrade_vcd_vapp_networks(network_data['vapp_networks'])

        # product section
        parameters = self.vnf_instance_file_parser.get_user_configurable_vapp_properties()
        for attr, val in parameters.iteritems():
            self.env['product_section_parameters'][attr] = val

    def convert_stackdetails_to_env(self):
        """
        Convert OS stack details json into environment for orchestration.
        """
        block = '[:]'
        regex = re.compile(block)

        parameters = self.vnf_instance_file_parser.vnf_status_file['stack']['parameters']
        for attr, val in parameters.iteritems():
            if regex.search(attr) is None:
                self.env['parameter_defaults'][attr] = val

    def extract_secret_settings(self):
        """
        Extract settings from vnf that cannot be extracted
        from stack/vApp status.
        """
        if self.cloud_type == 'OPENSTACK':
            self.extract_secret_settings_openstack()
        elif self.cloud_type == 'VMWARE':
            self.extract_secret_settings_vcd()

    def extract_secret_settings_openstack(self):
        param_defs = self.env['parameter_defaults']
        param_defs['admin_password_hash'] = self.get_pw_hash()
        param_defs['shared_storage_ssh_private_key'] = \
            self.get_shared_storage_pkey()

    def extract_secret_settings_vcd(self):
        """
        VMWare's OVF format contains most secrets already, but we should
        rewrite them, in case they changed since the OVF creation.
        """

        def escape_literal_newlines(text):
            return text.replace('\n', '\\n')

        param_defs = self.env['product_section_parameters']
        param_defs['Passwd'] = self.get_pw_hash()

        # in the OVF this should have literal '\n' characters,
        #   and not newlines. it will get extrapolated into newlines inside
        #   the vmware cloud-init equivalent:
        param_defs['Shared_storage_ssh_private_key'] = escape_literal_newlines(
            self.get_shared_storage_pkey()
        )

    def get_pw_hash(self):
        if self.cloud_type == "OPENSTACK":
            admin_username = self.env['parameter_defaults']['admin_username']
        elif self.cloud_type == "VMWARE":
            admin_username = self.env['product_section_parameters']['Username']
        pw_hash_cmd = (
            """sudo awk '/^%s:/{split($0,tokens,":")} END """
            """{print tokens[2]}' /etc/shadow"""
        ) % (admin_username)
        pw_hash = self.execute_on_vnf(pw_hash_cmd).strip()
        if not pw_hash:
            logger.error("Couldn't extract admin password hash from VNF!")
            raise Exit(ReturnCode.DATA_ERROR)
        return pw_hash

    def get_shared_storage_pkey(self):
        pk_cmd = "sudo cat /etc/shared_storage/storage.private.key"
        return self.execute_on_vnf(pk_cmd)

    def execute_on_vnf(self, command):
        """Execute command on the remote VM"""
        return self.cli.run_cli_remote(command)

    def export_vnf_data(self):
        """Export vnf data from vnf as base64 string"""
        export_command = self.vnf_conf_extract_command() + \
            ' /home/' + \
            self.vnf_instance_file_parser.get_admin_username() + \
            '/vnf_data_export'
        encode_command = 'cat /home/' + \
                         self.vnf_instance_file_parser.get_admin_username() + \
                         '/vnf_data_export.tar.gz | base64 -w 0'

        self.cli.run_cli_remote(export_command)
        return self.cli.run_cli_remote(encode_command)

    def get_vnf_data_env_key_vcd(self):
        """
        Found in the OVF template of the VNF.
        Refers to the vnf initial configuration in base64.
        Eg. in case of vBGF: 'Init_config'
        """
        raise NotImplementedError()

    def get_vnf_data_env_key(self):
        """
        The key name that refers to the vnf initial configuration in base64.
        Eg. in case of vBGF: 'bgf_config'
        """
        raise NotImplementedError()

    def vnf_spec_upgrade(self):
        raise NotImplementedError()

    def vnf_conf_extract_command(self):
        """
        Command(s) to issue on the VNF cluster node
        to extract the configuration file.
        """
        raise NotImplementedError()

    def get_convrules_path_vcd(self):
        """
        The path to the json file which contains conversion rules when
        upgrading between versions of the VNF on a VMWare VIM.
        """
        raise NotImplementedError()

    def get_convrules_path(self):
        """
        The path to json file which contains conversion rules when
        upgrading between versions of the VNF on an Openstack VIM.
        """
        raise NotImplementedError()

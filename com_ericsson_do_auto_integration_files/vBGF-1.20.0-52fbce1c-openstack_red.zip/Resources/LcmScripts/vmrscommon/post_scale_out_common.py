#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

import logging
from .lcm_common import PostScaleHook, with_coremw_cleanup
from imscommon.parsers import VCDXmlParser

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode

logger = logging.getLogger('post_scale_out')


class PostScaleOut(PostScaleHook):

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def add_additional_arguments(self):
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.',
            required=False)
        self.parser.add_argument(
            '-n', '--number-of-steps', metavar='<STEPS>',
            help='Number of scaling steps.',
            type=int,
            required=False)
        self.parser.add_argument(
            '-x', '--aspect-id', metavar='<ASPECT_ID>',
            help='The aspect ID of the scaling group to scale.',
            required=False)
        self.parser.add_argument(
            '-l', '--auto-scale-info-file',
            metavar='<AUTO_SCALE_INFO_FILE>',
            help='Auto Scale information parameters.',
            required=False)

    def post_scale_out_hook(self):
        if self.parsed_args.quit_operation:
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        return self.post_scale_hook()

    # OVERRIDE until VCD VM UUID check against cluster list problem is solved
    # TODO: remove decorator after coreMW is uplifted
    @with_coremw_cleanup
    def post_scale_hook(self):
        if isinstance(self.vnf_instance_file_parser, VCDXmlParser):
            return self.verify_cluster_status()
        else:
            # TODO: rewrite if Python uplifted to 2.7 or 3.x to new style class
            return super(PostScaleOut, self).post_scale_hook()

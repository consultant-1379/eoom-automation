#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""


class VnfInstanceData:
    def __init__(self,
                 ip,
                 user_name,
                 uuids=None,
                 resource_names=None,
                 payload_instance_count=None,
                 standby_payload_instance_count=None):
        self.ip = ip
        self.user_name = user_name
        self.uuids = uuids
        self.resource_names = resource_names
        self.payload_instance_count = payload_instance_count
        self.standby_payload_instance_count = standby_payload_instance_count


class VmDescriptor:
    def __init__(self,
                 instance,
                 admin_state,
                 uuid=None,
                 resource_name=None):
        self.instance = instance
        self.admin_state = admin_state
        self.uuid = uuid
        self.resource_name = resource_name

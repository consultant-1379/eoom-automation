#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import json
import logging
import re

from imscommon.exceptions import Exit
from imscommon import SSHUtility
from imscommon.consts import ReturnCode, VmAdminState
from imscommon.parsers import OpenstackJsonParser, VCDXmlParser
from .lcm_common import LockingLcmHook
from .lcm_data import VmDescriptor, VnfInstanceData
from .utils import CliExecutor, RemoteError

logger = logging.getLogger('pre_scale_in')


# https://github.com/PyCQA/pylint/issues/179
# Pylint can't detect if a class is less abstract but still not concrete.
# pylint: disable=W0223
class PrescaleIn(LockingLcmHook):

    STANDBY_ASPECTID = 'standby'

    class PrescaleInJsonParser(OpenstackJsonParser):
        def get_standby_payload_instance_count(self):
            try:
                parameters = self.vnf_status_file["stack"]["parameters"]
                count_standby = int(
                    parameters.get("standby_payload_instance_count", 0)
                )
            except ValueError:
                self._logger.error(
                    "Invalid value for standby payload instance count!"
                )
                raise Exit(ReturnCode.INVALID_PAYLOAD_INSTANCE_COUNT)
            if count_standby < 0:
                self._logger.error(
                    "Payload instance counter(s) must be non-negative."
                )
                raise Exit(ReturnCode.INVALID_PAYLOAD_INSTANCE_COUNT)
            return count_standby

        def get_all_params(self):
            self._logger.debug('parsed dict: %s', self.vnf_status_file)
            user_name = self.get_admin_username()
            payload_instance_count = self.get_payload_instance_count()
            self._logger.debug('payload_instance_count: %s', payload_instance_count)
            standby_payload_instance_count = self.get_standby_payload_instance_count()
            self._logger.debug('standby: %s', standby_payload_instance_count)
            ip = None
            uuids = None
            resource_names = None
            obj = self.vnf_status_file["stack"]["outputs"]
            for x in obj:
                try:
                    if x["output_key"] == "oam_public_ip":
                        ip = x["output_value"].strip()
                    elif x["output_key"] == "resource_list":
                        uuids = x["output_value"].strip().split()
                    elif x["output_key"] == "resource_names":
                        resource_names = x["output_value"].strip().split()
                except KeyError as e:
                    self._logger.warn('Unexpected value in outputs? %s', e)

            if any(var is None for var in (ip, uuids, resource_names)):
                self._logger.error(
                    ("Expected field(s) are missing from the input JSON file"
                     "\nip: %s\nuuids: %s\nresource_names: %s"),
                    ip, uuids, resource_names
                )
                raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

            return (
                ip, user_name, uuids, resource_names,
                payload_instance_count, standby_payload_instance_count
            )

    class PrescaleInXMLParser(VCDXmlParser):
        def __init__(self, filename):
            super(PrescaleIn.PrescaleInXMLParser, self).__init__(filename)
            self.uuids = self.get_uuids()

        def get_standby_payload_instance_count(self):
            '''
            Can just pretend this is zero at this point, the standby VMs are
            discovered later in the code logic and this is set appropriately.
            '''
            return 0

        def get_all_params(self):
            user_name = self.get_admin_username()
            ip = self.get_oam_public_ip()
            payload_instance_count = self.get_payload_instance_count()
            standby_payload_instance_count = self.get_standby_payload_instance_count()
            resource_names = self.get_vm_names()

            return (
                ip, user_name, self.uuids, resource_names,
                payload_instance_count, standby_payload_instance_count
            )

        def get_vm_names(self):
            names = []

            xpath = './/vcloud:Vm'
            vms = self.vnf_status_file.findall(self.replace_xpath_namespaces(xpath))

            try:
                for vm in vms:
                    names.append(vm.attrib.get(self.replace_xpath_namespaces('name')))

            except KeyError as ex:
                self._logger.error("A field is missing from the XML file: %s", ex)
                raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

            return names

    class InputData:
        def __init__(self,
                     user_name,
                     ip,
                     number_of_steps,
                     payload_instance_count,
                     standby_payload_instance_count,
                     uuids,
                     resource_names,
                     preferred_uuids=None,
                     key_filename=None,
                     password=None,
                     port=22):
            if preferred_uuids is None:
                preferred_uuids = []
            self.user_name = user_name
            self.ip = ip
            self.number_of_steps = number_of_steps
            self.payload_instance_count = payload_instance_count
            self.standby_payload_instance_count = standby_payload_instance_count
            self.total_payload_instance_count = (
                payload_instance_count
                + standby_payload_instance_count
            )
            self.uuids = uuids
            self.resource_names = resource_names
            self.port = port
            self.key_filename = key_filename
            self.password = password
            self.preferred_uuids = preferred_uuids or []

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def generate_shutdown_timer_script(self, shutdown_min):
        raise NotImplementedError()

    def __init__(self, args):
        super(PrescaleIn, self).__init__()
        input_data = self.argument_parsing(args)
        ssh = SSHUtility.SSHUtility(
            ip=input_data.ip,
            username=input_data.user_name,
            password=input_data.password,
            key_filename=input_data.key_filename,
            port=input_data.port,
            keep_alive=True
        )
        self.cli = CliExecutor(ssh)

        self.compute_resources = None
        try:
            self.cli.set_exit_on_error(False)
            self.compute_resources = self.get_compute_resources()
        except RemoteError:
            logger.error(
                'Cannot access O&M, but scale mode is forceful - continuing')
        finally:
            self.cli.set_exit_on_error(True)

        self.vcd_vm_mapping = None
        if self.compute_resources is not None:
            if self.is_vcd():
                self.vcd_vm_mapping = self.map_vcd_data_to_cluster()
            self.compare_cluster_to_vim(input_data)
            sc_uuid = self.get_sc_uuid()
        else:
            sc_uuid = None

        if self.is_vcd() and input_data.preferred_uuids:
            input_data.preferred_uuids = self.map_preferred_uuids_to_vcd(
                input_data)

        pl_standby_uuids = self.get_pl_standby_uuids(input_data)
        self.input_data = PrescaleIn.generate_scale_in_data(
            input_data, sc_uuid, pl_standby_uuids
        )

        self.vm_descriptor_list = self.init_vm_descriptors()

    def map_preferred_uuids_to_vcd(self, input_data):
        '''The uuids are expected either all from vCD, or all from BIOS.'''
        preferred_uuids = input_data.preferred_uuids
        presumed_bios_uuids = [
            u for u in preferred_uuids
            if u not in input_data.uuids
        ]
        if not presumed_bios_uuids:
            logger.info('All preferred uuids are vCD uuids')
            return preferred_uuids

        # mixed vCD and (maybe-)BIOS is presumed to be a user error:
        if len(presumed_bios_uuids) != len(preferred_uuids):
            logger.error(
                'Some preferred uuids are missing in vCD: %s',
                presumed_bios_uuids)
            raise Exit(ReturnCode.REJECT)

        if self.vcd_vm_mapping is None:
            logger.error(
                'None of the preferred uuids are from vCD, but O&M endpoint '
                'is unavailable, hence cannot map them as BIOS uuids either.')
            raise Exit(ReturnCode.MO_INSTANCE_ERROR)

        logger.info(
            'All preferred uuids are missing from vCD - '
            'looking for them as BIOS uuids instead.')
        return [
            self.get_vcd_uuid_for_bios_uuid(u) for u in presumed_bios_uuids
        ]

    def map_vcd_data_to_cluster(self):
        '''
        Create a map structure from which vCD uuid can be obtained
        using BIOS uuids and vice versa. Do this via associating them
        with MAC addresses. All of these should be unique at least within
        the vApp.
        '''
        vcd_mac_dict = dict([
            # parser returns xml node objects, extract actual mac addr:
            (k.text.lower(), v)
            for (k, v)
            in self.vnf_instance_file_parser.get_mac_to_vm_name_dict().items()
            # only if the key is an actual mac addr:
            if re.match('[A-Fa-f0-9]{2}(:[A-Fa-f0-9]{2}){5}', k.text)
        ])

        vcd_name_id_dict = self.vnf_instance_file_parser.get_vm_name_to_id_dict()
        # strip namespace prefix from ids:
        for k in vcd_name_id_dict:
            vcd_name_id_dict[k] = vcd_name_id_dict[k].split(':')[-1]

        mapping = {}
        for vm_cluster_name in self.compute_resources:
            vm = self.compute_resources[vm_cluster_name]
            vm_mac1 = vm['macs'][0].lower()  # MAC addresses should be unique
            if vm_mac1 not in vcd_mac_dict:
                logger.error('Could not find VM in vCD data with mac %s', vm_mac1)
                raise Exit(ReturnCode.DATA_ERROR)

            vm_name_vcd = vcd_mac_dict[vm_mac1]

            vm_uuid_vcd = vcd_name_id_dict[vm_name_vcd]
            vm_dict = {}
            vm_dict['cluster_uuid'] = vm['uuid']
            vm_dict['vcd_uuid'] = vm_uuid_vcd
            vm_dict['cluster_name'] = vm_cluster_name
            vm_dict['cluster_macs'] = vm['macs']
            vm_dict['vcd_macs'] = [
                k for k in vcd_mac_dict if vcd_mac_dict[k] == vm_name_vcd
            ]

            mapping[vm_name_vcd] = vm_dict

        logger.info('vCD to cluster mapping:\n%s', json.dumps(mapping, indent=2))
        return mapping

    def get_vcd_uuid_for_bios_uuid(self, bios_uuid):
        for vm_name in self.vcd_vm_mapping:
            vm_data = self.vcd_vm_mapping[vm_name]
            if vm_data['cluster_uuid'] == bios_uuid:
                return vm_data['vcd_uuid']

        logger.error(
            'BIOS uuid (%s) could not be mapped to any vCD uuid!', bios_uuid)
        raise Exit(ReturnCode.REJECT)

    def compare_cluster_to_vim(self, input_data):
        """Compare VMs that are seen from inside BGF cluster
        to the ones seen by VIM (Openstack or VMWare)."""
        cluster = self.compute_resources
        if self.is_vcd():
            PrescaleIn.compare_cluster_to_vim_macs(cluster, self.vnf_instance_file_parser.get_mac_addresses())
        else:
            PrescaleIn.compare_cluster_to_vim_uuids(cluster, input_data.uuids)

    @staticmethod
    def compare_cluster_to_vim_uuids(cluster, vim_uuids):
        ids_not_in_cluster = list(vim_uuids)
        ids_not_in_vim = []
        for name in cluster:
            uuid = cluster[name]['uuid']
            if uuid in ids_not_in_cluster:
                ids_not_in_cluster.remove(uuid)
            else:
                ids_not_in_vim.append(uuid)

        cardinality_mismatch = False
        if len(ids_not_in_cluster) > 0:
            logger.error("---> Cluster doesn't know about these VMs: %s", ids_not_in_cluster)
            cardinality_mismatch = True

        if len(ids_not_in_vim) > 0:
            logger.error("---> VIM doesn't know about VMs %s", ids_not_in_vim)
            cardinality_mismatch = True

        # raise separately to log all errors
        if cardinality_mismatch:
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    @staticmethod
    def compare_cluster_to_vim_macs(cluster_vms, vim_all_macs):
        def lower_macs(mac_list):
            return [m.lower() for m in mac_list]

        def remove_cluster_vm_macs_from_vim_macs(cl_vm_macs, vim_macs):
            for vim_vm_macs in vim_macs:
                if set(cl_vm_macs).issubset(set(lower_macs(vim_vm_macs))):
                    vim_macs.remove(vim_vm_macs)
                    return True

            return False

        logger.debug("\ncluster_vms: %s\nvim_all_macs: %s", cluster_vms, vim_all_macs)

        vms_unknown_to_vim = []
        for vm_name in cluster_vms:
            cluster_vm_macs = lower_macs(cluster_vms[vm_name]['macs'])
            found_current = remove_cluster_vm_macs_from_vim_macs(
                cluster_vm_macs, vim_all_macs)
            if not found_current:
                vms_unknown_to_vim.append(vm_name)

        cardinality_mismatch = False
        if vms_unknown_to_vim:
            logger.error("---> VIM doesn't know about these VMs: %s",
                         vms_unknown_to_vim)
            cardinality_mismatch = True

        if len(vim_all_macs) != 0:
            logger.error("---> Cluster doesn't know about these VMs: %s",
                         vim_all_macs)
            cardinality_mismatch = True

        if cardinality_mismatch:
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    def get_cluster_uuids_and_names_vcd(self):
        '''
        Map the uuids in input_data (vCD ids at this point)
        to cluster/BIOS uuids using existing mapping data.
        If the mapping data is unavailable because eg. connection
        errors, then this returns an array of Nones
        '''
        if self.vcd_vm_mapping is None:
            logger.info('Cannot fetch BIOS uuids.')
            return [None, ] * len(self.input_data.uuids), self.input_data.resource_names

        cluster_uuids = []
        for vcd_uuid in self.input_data.uuids:
            cluster_uuid = None
            for vm_name in self.vcd_vm_mapping:
                vm_data = self.vcd_vm_mapping[vm_name]
                if vm_data['vcd_uuid'] == vcd_uuid:
                    cluster_uuid = vm_data['cluster_uuid']
                    break
            if cluster_uuid is None:
                logger.error("Couldn't find VM with vcd_uuid %s", vcd_uuid)
                raise Exit(ReturnCode.MO_INSTANCE_ERROR)
            cluster_uuids.append(cluster_uuid)

        # resource names can stay vCD names
        return cluster_uuids, self.input_data.resource_names

    def init_vm_descriptors(self):
        if self.is_vcd():
            cluster_uuids, cluster_names = self.get_cluster_uuids_and_names_vcd()
        else:
            cluster_uuids = self.input_data.uuids
            cluster_names = self.input_data.resource_names

        vm_descriptors = []
        for uuid, name in zip(cluster_uuids, cluster_names):
            mo_instance = self.get_mo_instance_of_uuid(uuid) if not self.forceful_lock_requested() else None
            vm_descriptors.append(
                VmDescriptor(
                    mo_instance,
                    self.get_mo_admin_state(mo_instance) if not self.forceful_lock_requested() else None,
                    uuid,
                    name,
                )
            )

        return vm_descriptors

    @staticmethod
    def check_empty_data(input_data):
        data = (input_data.user_name,
                input_data.ip,
                input_data.number_of_steps,
                input_data.payload_instance_count,
                input_data.uuids,
                input_data.resource_names)

        if any(x is None for x in data):
            logger.error('not all params parsed from json: %s', data)
            raise Exit(ReturnCode.PARSE_ERROR)

    @staticmethod
    def check_number_of_steps(input_data):
        if input_data.number_of_steps < 0:
            logger.error("Invalid step number: %d",
                         input_data.number_of_steps)
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)

        if input_data.number_of_steps > len(input_data.resource_names):
            logger.error(
                "Error: step number (%d) larger than resource count (%d)",
                input_data.number_of_steps,
                len(input_data.resource_names),
            )
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)

    @staticmethod
    def check_resource_cardinality(input_data):
        # include standby pl count:
        total_pl_count = input_data.total_payload_instance_count
        mismatch = (
            total_pl_count != len(input_data.resource_names)
            or total_pl_count != len(input_data.uuids)
        )
        if mismatch:
            logger.error(
                ("Resource name counts do not match! "
                 "Resource name count: %d "
                 "UUID count: %d "
                 "total payload instance count: %d"),
                len(input_data.resource_names),
                len(input_data.uuids),
                total_pl_count,
            )
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    @staticmethod
    def validate_input(input_data, is_vcd=False):
        PrescaleIn.check_empty_data(input_data)
        PrescaleIn.check_number_of_steps(input_data)
        # TODO: Check is invalid on VMWARE.
        if not is_vcd:
            PrescaleIn.check_resource_cardinality(input_data)

        logger.info("the params parsed from json is: (%s)",
                    (input_data.user_name,
                     input_data.ip,
                     input_data.number_of_steps,
                     input_data.payload_instance_count,
                     input_data.uuids,
                     input_data.resource_names))

    @staticmethod
    def move_sc_uuid_to_scale_in_last(input_data, sc):
        idx = input_data.uuids.index(sc)
        input_data.uuids.remove(sc)
        input_data.uuids.insert(0, sc)

        resource = input_data.resource_names[idx]
        input_data.resource_names.remove(resource)
        input_data.resource_names.insert(0, resource)

    @staticmethod
    def generate_scale_in_data(input_data, sc=None, pl_standby_vms=None):
        # remove standby instances from uuid list:
        for uuid in (pl_standby_vms or []):
            if uuid in input_data.uuids:
                input_data.uuids.remove(uuid)
        logger.info("VM(s) which can be scaled in: %s", input_data.uuids)

        if input_data.preferred_uuids:
            offending_vms = [
                uuid for uuid in (pl_standby_vms or [])
                if uuid in input_data.preferred_uuids
            ]
            if offending_vms:
                logger.error(
                    ("Scaling in VM(s) with redundancy role "
                     "is not permitted! Offending uuid(s): %s"), offending_vms
                )
                raise Exit(ReturnCode.REJECT)

            PrescaleIn.reorder_uuids(input_data)

        logger.info("SC UUID: %s", sc)
        logger.info("Input UUIDs: %s", input_data.uuids)
        logger.info("Preferred UUIDs: %s", input_data.preferred_uuids)
        if sc and sc in input_data.uuids and sc not in input_data.preferred_uuids:
            PrescaleIn.move_sc_uuid_to_scale_in_last(input_data, sc)

        scale_in_range = input_data.number_of_steps
        if len(input_data.preferred_uuids) > scale_in_range:
            logger.error('Too many uuids were requested to be scaled in!')
            raise Exit(ReturnCode.REJECT)

        input_data.uuids = input_data.uuids[::-1][:scale_in_range]
        input_data.resource_names = \
            input_data.resource_names[::-1][:scale_in_range]
        return input_data

    @staticmethod
    def reorder_uuids(input_data):
        ''' Put preferred uuids at the end of the list, along with names. '''
        for puuid in input_data.preferred_uuids:
            idx = input_data.uuids.index(puuid)
            input_data.uuids.append(puuid)
            input_data.uuids.remove(puuid)

            resource_names = input_data.resource_names
            pname = resource_names[idx]
            resource_names.append(pname)
            resource_names.remove(pname)

    def parse_input_json_file(self, input_json_file):
        if not input_json_file:
            return None
        try:
            with open(input_json_file) as json_file:
                return json.load(json_file)
        except Exception as ex:
            logger.error(
                "Input JSON file is invalid: %s, caught exception: %s ",
                input_json_file, ex
            )
            raise Exit(ReturnCode.INVALID_JSON)

    def get_preferred_uuids(self):
        if not self.auto_scale_info_params:
            if not self.additional_params:
                return []
            return self.additional_params.get('listOfUUIDsToBeDeleted', [])
        additional_info = self.auto_scale_info_params.get('additionalInformation', '')
        split_info = additional_info.split("uuid:")
        if not len(split_info) == 2:
            logger.error("Auto Scale additional information is invalid: %s", additional_info)
            return []
        return [split_info[1]]

    def get_additional_param(self, param):
        if not self.additional_params:
            return None
        return self.additional_params.get(param, None)

    def get_pl_standby_uuids(self, input_data):
        if self.is_vcd():
            return PrescaleIn.get_pl_standby_uuids_vcd(
                input_data, self.vnf_instance_file_parser
            )
        return PrescaleIn.get_pl_standby_uuids_os(
            input_data
        )

    @staticmethod
    def get_pl_standby_uuids_os(input_data):
        '''
        In case of Openstack:
            The inputs data's last 'n' UUID entries, where n = standby_count,
            are standby VMs because of the HOT layout of vBGF.
        In case of vmware:
            TODO - get VMs with 'standby' aspectId
        '''
        standby_count = input_data.standby_payload_instance_count
        if standby_count == 0:
            logger.info('No payload standby instances.')
            return []
        standby_uuids = input_data.uuids[-standby_count:]
        logger.info('Payload standby instances: %s', standby_uuids)
        return standby_uuids

    @staticmethod
    def get_pl_standby_uuids_vcd(input_data, vcd_parser):
        '''
        Find the VMs with the aspectId ovf:Property tag where its
        value is 'standby'.
        '''
        if not hasattr(vcd_parser, 'get_aspectid_to_vm_dict'):
            # this function is missing from older imscommon, but it is not
            #   critical, so the script should proceed
            logger.error('Missing function to check for aspectIds')
            return []

        aspectid_to_vm = vcd_parser.get_aspectid_to_vm_dict()
        standby_vms = aspectid_to_vm.get(PrescaleIn.STANDBY_ASPECTID, [])
        logger.info(
            'There are %s standby aspectId instances', len(standby_vms))
        input_data.standby_payload_instance_count = len(standby_vms)
        return [
            vm.get('id').split(':')[-1].lower() for vm in standby_vms
        ]

    def get_sc_uuid(self):
        cluster_list_output = self.cli.run_cli_remote("cluster list --json")
        logger.info("Cluster list output: %s", cluster_list_output)
        vm_states = json.loads(cluster_list_output)
        bios_uuid = next(
            (vm['uuid'] for vm in vm_states if vm['role'] == 'ACTIVE'),
            None
        )
        if bios_uuid and self.is_vcd():
            return self.get_vcd_uuid_for_bios_uuid(bios_uuid)
        return bios_uuid

    def get_scale_in_parser(self):
        if self.parsed_args.vnf_instance_details_file.endswith('.xml'):
            return PrescaleIn.PrescaleInXMLParser(
                self.parsed_args.vnf_instance_details_file)
        else:
            return PrescaleIn.PrescaleInJsonParser(
                self.parsed_args.vnf_instance_details_file)

    def argument_parsing(self, args):
        self.add_common_arguments('pre_scale_in hook for workflow')
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.')
        self.parser.add_argument(
            '-l', '--auto-scale-info-file',
            metavar='<AUTO_SCALE_INFO_FILE>',
            help='Auto Scale information parameters.',
            required=False)
        self.mandatory.add_argument(
            '-n', '--number-of-steps', metavar='<STEPS>',
            help='Number of scaling steps.',
            type=int,
            required=True)
        self.parser.add_argument(
            '-x', '--aspect-id', metavar='<ASPECT_ID>',
            help='The aspect ID of the scaling group to scale.',
            required=False)
        self.parsed_args = self.parser.parse_args(args)
        self.password = self.read_password_from_file()

        self.vnf_instance_file_parser = self.get_scale_in_parser()

        logger.debug('json file [%s] loaded',
                     self.parsed_args.vnf_instance_details_file)

        self.vnf_instance_data = VnfInstanceData(*self.vnf_instance_file_parser.get_all_params())
        self.active_user_name = self.get_active_user_name()
        self.auto_scale_info_params = self.parse_input_json_file(self.parsed_args.auto_scale_info_file)
        self.additional_params = self.parse_input_json_file(self.parsed_args.additional_param_file)

        input_data = PrescaleIn.InputData(
            self.active_user_name,
            self.vnf_instance_data.ip,
            self.parsed_args.number_of_steps,
            self.vnf_instance_data.payload_instance_count,
            self.vnf_instance_data.standby_payload_instance_count,
            self.vnf_instance_data.uuids,
            self.vnf_instance_data.resource_names,
            self.get_preferred_uuids(),
            self.parsed_args.key_file,
            self.password,
        )

        self.shutting_down_timeout = \
            self.get_additional_param('shuttingDownTimeout')
        self.shutdown_type = self.get_additional_param('shutdownType')
        LockingLcmHook.check_shutdown_type(self.shutdown_type)

        PrescaleIn.validate_input(input_data, self.is_vcd())
        return input_data

    def update_vm_states(self):
        for vm in self.vm_descriptor_list:
            vm.admin_state = self.get_mo_admin_state(vm.instance)

    def print_unbound_vms(self):
        for vm in self.vm_descriptor_list:
            if vm.admin_state == VmAdminState.UNBOUND:
                logger.error(
                    "Unbound VM found with UUID: %s Resource name: %s",
                    vm.uuid, vm.resource_name)

    def dump_scaling_list_output_json(self):
        if self.is_vcd():
            return self.dump_scaling_list_output_json_vcd()
        else:
            return self.dump_scaling_list_output_json_os()

    def dump_scaling_list_output_json_os(self):
        data = self.input_data
        logger.debug(
            'payload_count: %s, no_of_steps: %s',
            data.payload_instance_count,
            data.number_of_steps
        )
        icount = data.payload_instance_count - data.number_of_steps
        index = [
            PrescaleIn.get_index(vm.resource_name)
            for vm in self.vm_descriptor_list
        ]
        output = {
            "payload_instance_count": str(icount),
            "payload_scaling_in_list": ','.join(index),
        }
        return json.dumps(output)

    def dump_scaling_list_output_json_vcd(self):
        # keep compatibility with older workflows
        # by adding the namespace prefix:
        def add_prefix(uuid):
            return 'urn:vcloud:vm:{}'.format(uuid)

        output = {
            "number_of_vms_to_be_removed": str(self.input_data.number_of_steps),
            "vmuuids_to_remove": [add_prefix(u) for u in self.input_data.uuids]
        }
        return json.dumps(output)

    def check_locked_instances(self):
        self.update_vm_states()
        if all(vm.admin_state in (VmAdminState.LOCKED, VmAdminState.UNBOUND)
               for vm in self.vm_descriptor_list):
            self.print_unbound_vms()
        else:
            logger.debug("not all vm's are locked at")
            print("Waiting for LOCKED state.")
            raise Exit(ReturnCode.REPEAT)

    @staticmethod
    def get_index(resource_name):
        regex = r".*-([0-9]+)$"
        matches = re.search(regex, resource_name)
        logger.debug("Getting index of %s. Index is: %s", resource_name, matches.group(1))
        return matches.group(1)

    def check_if_vms_unlocked(self):
        for vm in self.vm_descriptor_list:
            admin_state = self.get_mo_admin_state(vm.instance)
            if admin_state in (VmAdminState.LOCKED,
                               VmAdminState.SHUTTINGDOWN):
                logger.debug("Not all VMs are unlocked yet")
                print("Waiting for UNLOCKED state.")
                raise Exit(ReturnCode.REPEAT)

    def pre_scale_in_hook(self):
        if self.parsed_args.quit_operation:
            self.unlock_vms()
            self.check_if_vms_unlocked()
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        if not self.forceful_lock_requested():
            self.lock_instances()
            self.check_locked_instances()

        return self.dump_scaling_list_output_json()

    @staticmethod
    def get_uuid_of_compute_resource_by_mac_list(compute_resources, maclist):
        maclist_lower = [mac.lower() for mac in maclist]
        for key, resource in compute_resources.iteritems():
            logger.debug(
                "Compute resource working on key: %s --- value: %s",
                key, resource
            )
            if any([mac_of_rsc.lower() in maclist_lower
                    for mac_of_rsc in resource['macs']]):
                return resource['uuid']
        return None

    def is_vcd(self):
        return isinstance(self.vnf_instance_file_parser, PrescaleIn.PrescaleInXMLParser)

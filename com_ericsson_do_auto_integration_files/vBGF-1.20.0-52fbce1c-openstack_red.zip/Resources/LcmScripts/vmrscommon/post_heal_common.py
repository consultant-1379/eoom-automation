#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import logging

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode

from imscommon import SSHUtility
from vmrscommon.utils import CliExecutor
from vmrscommon.lcm_data import VnfInstanceData
from .lcm_common import (
    OpenstackJsonParser, PostHook, with_coremw_cleanup
)

logger = logging.getLogger('post_heal')


class PostHeal(PostHook):

    class PostHealJsonParser(OpenstackJsonParser):
        pass

    def __init__(self, args):
        super(PostHeal, self).__init__()
        self.payload_instance_count = self.argument_parsing(args)
        if self.parsed_args.quit_operation:
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def parse_auto_healing_info_params(self):
        if not self.parsed_args.auto_healing_info_file:
            return None
        return self.json_parser.parse_vnf_status_file(
            self.parsed_args.auto_healing_info_file)

    def parse_additional_params(self):
        if not self.parsed_args.additional_param_file:
            return None
        return self.json_parser.parse_vnf_status_file(
            self.parsed_args.additional_param_file)

    def argument_parsing(self, args):
        self.add_common_arguments('post_heal hook for workflow')
        self.parser.add_argument(
            '-l', '--auto-healing-info-file',
            metavar='<AUTO_HEALING_INFO_FILE>',
            help='Auto Healing information parameters.')
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.')

        self.parsed_args = self.parser.parse_args(args)
        self.json_parser = PostHeal.PostHealJsonParser(
            self.parsed_args.vnf_instance_details_file)

        payload_instance_count = self.json_parser.get_payload_instance_count()
        self.auto_healing_info_params = self.parse_auto_healing_info_params()
        self.additional_params = self.parse_additional_params()

        self.password = self.read_password_from_file()
        self.vnf_instance_data = VnfInstanceData(*self.json_parser.get_all_params())

        ssh = SSHUtility.SSHUtility(
            ip=self.vnf_instance_data.ip,
            username=self.vnf_instance_data.user_name,
            password=self.password, key_filename=self.parsed_args.key_file,
            port=22, keep_alive=True)
        self.cli = CliExecutor(ssh)

        return payload_instance_count

    def get_expected_coremw_uuid_count(self):
        '''
        When called by a very old common-workflows version,
        the instance identifier is not given. In this case, the old
        healing mechanism is in effect in the workflow, which solves
        the coreMW issues internally because of scale in+out, and
        there is no need to also do the workaround here,
        hence returning 0 in that case.
        For newer workflows, return 1.
        '''
        called_by_legacy_wf = (
            self.parsed_args.workflow_instance_identifier in ('', None))
        return 0 if called_by_legacy_wf else 1

    # TODO Remove it after after coreMW uplift.
    @with_coremw_cleanup
    def post_heal_hook(self):
        self.verify_cluster_status()

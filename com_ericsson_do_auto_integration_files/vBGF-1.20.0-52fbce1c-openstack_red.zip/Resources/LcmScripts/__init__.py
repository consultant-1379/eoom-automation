#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

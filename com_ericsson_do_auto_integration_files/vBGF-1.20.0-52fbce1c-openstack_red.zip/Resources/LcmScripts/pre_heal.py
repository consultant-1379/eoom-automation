#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import vmrscommon.pre_heal_common as preheal
from vmrscommon.lcm_common import Exit, ReturnCode, setup_default_logging
import sys


class VBGFPreHeal(preheal.PreHeal):

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def get_supported_alarm_types(self):
        return ['COM SA, CLM Cluster Node Unavailable']

    def get_uuid_to_autoheal(self):
        uuid = self.find_uuid_in_text(
            self.auto_healing_info_params.get('managedObject')
        )
        if not uuid:
            raise Exit(ReturnCode.INVALID_JSON)
        return uuid


def main():
    try:
        print(VBGFPreHeal(sys.argv[1:]).pre_heal_hook())
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    setup_default_logging()
    main()

#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""
from __future__ import absolute_import, print_function

import sys
import os
import logging
import vmrscommon.pre_upgrade_common as preupgrade
from vmrscommon.lcm_common import Exit, ReturnCode, setup_default_logging

logger = logging.getLogger('VBGFPreUpgrade')

DIR = os.path.abspath(os.path.dirname(__file__))
CONVRULES_FILE = os.path.abspath(
    os.path.join(DIR, "conversionrules.json"))
CONVRULES_FILE_VCD = os.path.abspath(
    os.path.join(DIR, "conversionrules_vcd.json"))


class VBGFPreUpgrade(preupgrade.PreUpgrade):
    """ Implementation of vbfg specific pre upgrade functions"""
    REDUNDANCY_PARAMETER_OS = 'standby_payload_instance_count'

    def generate_get_mo_instance_id_script(self, uuid):
        """Not used, just present to pass pylint error."""
        raise NotImplementedError()

    def get_vnf_data_env_key_vcd(self):
        return 'Init_config'

    def get_vnf_data_env_key(self):
        return 'bgf_config'

    def get_upgr_source_deployment_type(self):
        '''
        Should be redundancy-enabled or no-redundancy.
        On vmware, return 'N/A' because we cannot check the target,
        as we would need the OVF file for that, which may not be
        in the onboarded package.
        '''
        if self.cloud_type == 'OPENSTACK':
            stack = self.vnf_instance_file_parser.vnf_status_file['stack']
            return 'redundancy-enabled' if (
                self.REDUNDANCY_PARAMETER_OS in stack['parameters']
            ) else 'no-redundancy'

        elif self.cloud_type == 'VMWARE':
            return 'N/A'

        else:
            logger.error('Unexpected cloud_type %s', self.cloud_type)
            raise Exit(ReturnCode.RETURN_ERROR)

    def get_upgr_target_deployment_type(self):
        '''
        Should be redundancy-enabled or no-redundancy.
        On vmware, return 'N/A' because we cannot check the target,
        as we would need the OVF file for that, which may not be
        in the onboarded package.
        '''
        if self.cloud_type == 'OPENSTACK':
            current_main_yaml = self.get_main_hot_yaml_content()
            return 'redundancy-enabled' if (
                self.REDUNDANCY_PARAMETER_OS in current_main_yaml['parameters']
            ) else 'no-redundancy'

        elif self.cloud_type == 'VMWARE':
            return 'N/A'

        else:
            logger.error('Unexpected cloud_type %s', self.cloud_type)
            raise Exit(ReturnCode.RETURN_ERROR)

    def deployment_type_sanity_check(self):
        '''
        Check that the upgrade is either doing:
            - red => red
            or
            - non-red => non-red
        Upgrading from one kind to the other is not supported.
        '''
        upgr_target_type = self.get_upgr_target_deployment_type()
        upgr_source_type = self.get_upgr_source_deployment_type()
        logger.debug(
            'Upgrade source deployment has type %s, upgrade target has %s',
            upgr_target_type, upgr_source_type
        )
        if upgr_target_type != upgr_source_type:
            logger.error(
                'Cannot upgrade from deployment type %r to type %r!',
                upgr_source_type, upgr_target_type
            )
            raise Exit(ReturnCode.REJECT)

    def vnf_spec_upgrade(self):
        if not self.parsed_args.no_package:
            self.deployment_type_sanity_check()

    def vnf_conf_extract_command(self):
        return '/opt/bgf_director/bgf_export_conf.py'

    def get_convrules_path(self):
        return CONVRULES_FILE

    def get_convrules_path_vcd(self):
        return CONVRULES_FILE_VCD

    def get_upgrade_env_mandatory_hot_params(self):
        return ['bgf_image', 'bgf_flavor']


def main():
    try:
        print(VBGFPreUpgrade(sys.argv[1:]).pre_upgrade_hook())
    except Exit as exc:
        sys.exit(exc.return_code)


if __name__ == '__main__':
    setup_default_logging()
    main()

#!/usr/bin/env python
import sys
RETURN_ERROR = 4
if __name__ == '__main__':
   sys.stderr.write("This WF is not supported in the current release!")
   sys.exit(RETURN_ERROR)

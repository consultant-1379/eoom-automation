#!/usr/bin/env python
import argparse
import json
import logging
import sys
from imscommon import SSHUtility

RETURN_ERROR = 4
REPEAT = 100

class PostScaleOut:

    class InputData:
        def __init__(self, ip, uuids, emergency_username, key_file):
            self.ip = ip
            self.uuids = uuids
            self.emergency_username = emergency_username
            self.key_file = key_file

    def __init__(self):
        self.input_data = PostScaleOut.argument_parsing()
        self.ssh = self.connect_to_host(host=self.input_data.ip,
                                        username=self.input_data.emergency_username,
                                        key_file=self.input_data.key_file,
                                        port=22,
                                       )

        if not self.check_connection():
            print("Trying to SSH to the node")
            sys.exit(REPEAT)

        self.numOfScaledVM = self.readNumOfVMScaled()
        if self.numOfScaledVM is None:
           sys.stderr.write("Failed to read /cluster/home/vnflcm/scaleOut_num")
           self.numOfScaledVM = 1
        #sys.stdout.write(str(self.numOfScaledVM) + " is being scaled out")

        self.post_scale_out_hook()

    def check_connection(self):
        try:
            self.ssh.run_command("w")
        except:
            return False
        return True

    def readNumOfVMScaled(self):
        stdout, stderr, retcode = self.ssh.run_command("cat /cluster/home/vnflcm/scaleOut_num", fail_at_error=False)
        if retcode == 0:
            return int((stdout.split("\n")[0].split("=")[1]))
        else:
            return None

    def check_uninstantiated_vms(self):
        uninstantiated_vms = []

        for uuid in self.input_data.uuids[-self.numOfScaledVM:]:
            logger.info("Current UUID: %s" % uuid)
            mo_instance = self.get_mo_instance_of_uuid(uuid)
            logger.debug("Checking instance: %s", mo_instance)
            if "instantiationState=INSTANTIATED" and "operationalState=ENABLED" not in mo_instance:
                if "instantiationState=INSTANTIATION_FAILED" not in mo_instance:
                    uninstantiated_vms.append(uuid)
                    logger.debug("Found uninstantiated VM: %s", mo_instance)
                else:
                    print uuid + " VM fail to be scaled out on CBA level"
                    sys.exit(RETURN_ERROR)

        return uninstantiated_vms

    def post_scale_out_hook(self):
        uninstantiated_vms = self.check_uninstantiated_vms()
        if uninstantiated_vms:
            logger.debug("Uninstantiated VMs were found: %s" % str(uninstantiated_vms))
            print "SCALE OUT is in progress"
            sys.exit(REPEAT)

        logger.info("All checks passed!")

    def connect_to_host(self, host, username, key_file=None, port=22):
        ssh = SSHUtility.SSHUtility(ip=host,
                                    username=username,
                                    key_filename=key_file,
                                    port=port,
                                    keep_alive=True
                                   )
        return ssh

    def generate_get_mo_instance_id_script(self, uuid):
        return 'uuid=' + uuid + '''
        computeResource=$({ echo 'show -r -m ComputeResource  -c uuid=='${uuid}'  -p '; echo 'exit';} |\
                        /opt/com/bin/cliss -sb )
        Instance=$({ echo 'show -r -m ComputeResourceRole -c uses=='${computeResource}' '; echo 'exit';}|\
                    /opt/com/bin/cliss -sb )
        echo -n $Instance
        '''

    def get_mo_instance_of_uuid(self, uuid):
        script = self.generate_get_mo_instance_id_script(uuid)
        try:
            stdout, stderr, ret = self.ssh.run_command(script)
            return stdout
        except Exception as ex:
            logger.error("Failed to get MO instance: %s" % str(ex))
            sys.exit(RETURN_ERROR)

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='post_scaleout hook for workflow')
        parser.add_argument('-f', '--stack-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of stack show details command in json format.',
                            type=str, required=True)
        parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                            help='Path to the file containing the private key for login', type=str, required=False)
        args = parser.parse_args()
        with open(args.stack_details_file) as json_file:
            jsonfile = json.load(json_file)
        logger.debug('json file [%s] loaded', args.stack_details_file)
        key_file = args.key_file
        uuids = None
        try:
            if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
                ip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
            else:
                ip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()
            emergency_username = jsonfile["stack"]["parameters"]["emergency_username"].strip()

            obj = jsonfile["stack"]["outputs"]
            for x in obj:
                if x["output_key"] == "scaled_VMs_UUID":
                    uuids = x["output_value"].strip().split()
        except KeyError as ex:
            logger.error("A field is missing from the JSON file: %s " % str(ex))
            print "A field is missing from the JSON file: %s " % str(ex)
            sys.exit(RETURN_ERROR)

        if uuids is None:
            logger.error("Missing mandatory 'scaled_VMs_UUID' output.")
            print "Missing mandatory 'scaled_VMs_UUID' output."
            sys.exit(RETURN_ERROR)

        logger.info("the params parsed from json is: %s" %
                    ((ip, uuids, emergency_username),))

        return PostScaleOut.InputData(ip, uuids, emergency_username, key_file)

def main():
    postscaleout = PostScaleOut()

if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING,
                        format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
    logger = logging.getLogger("post_scaleout")
    main()

#!/usr/bin/env python
import argparse
import os
import json
import logging
import time
import sys
from imscommon import SSHUtility

SUCCESS = 0
PARSE_ERROR = 1
MO_INSTANCE_ERROR = 2
CM_STATE_ERROR = 3
RETURN_ERROR = 4
RETURN_NOR_STD_ERROR = 5
REJECT = 6
REPEAT = 100

class PostScaleIn:
    class InputData:
        def __init__(self, mip, key_file, emergency_user, uuids, number_of_scaled_out_VMs):
            self.mip = mip
            self.key_file = key_file
            self.emergency_user = emergency_user
            self.uuids = uuids
            self.number_of_scaled_out_VMs = number_of_scaled_out_VMs

    def __init__(self):
        self.input_data = PostScaleIn.argument_parsing()
        self.ssh = self.connect_to_host(host=self.input_data.mip,
                                        username=self.input_data.emergency_user,
                                        key_filename=self.input_data.key_file,
                                        port=22)

        if not self.check_connection():
            logger.debug("Trying to SSH to the node")
            print("Trying to SSH to the node")
            sys.exit(REPEAT)
        self.scaleIn()
        sys.exit(SUCCESS)

    def connect_to_host(self, host, username, key_filename=None, port=22):
        ssh = SSHUtility.SSHUtility(ip=host,
                                    username=username,
                                    key_filename=key_filename,
                                    port=port,
                                    keep_alive=True)
        return ssh

    def check_connection(self):
        try:
            self.ssh.run_command("w")
        except:
            return False
        return True

    def get_PL_List(self):
        stdout, stderr, retcode = self.ssh.run_command("immfind safAmfCluster=myAmfCluster | grep '^safAmfNode=' | egrep -o 'PL-[0-9]+,'")
        if retcode != 0:
           print("Failed to get PL node list")
           sys.exit(RETURN_ERROR)
        node_list = []
        for node in stdout.split():
            node_list.append(node[:-1])
        node_list.sort(key=lambda x: int(x.split("-")[-1]))
        print(node_list)
        return node_list

    def get_PL_name_to_uuid_dict(self, node_list):
        PL_to_uuid = {}

        for node in node_list:
            uuid_command = "show ManagedElement=1,Equipment=1,ComputeResource=" + node + ",uuid"
            stdout, stderr, retcode = self.run_com_cli_command(uuid_command)
            if retcode != 0:
               print("Failed to read PL node list")
               sys.exit(RETURN_ERROR)
            uuid = stdout.strip().split('=')[-1].replace('"','')
            PL_to_uuid[node] = uuid.strip()

        print(PL_to_uuid)
        return PL_to_uuid

    def scaleIn(self):
        node_list = self.get_PL_List()
        PL_to_uuid = self.get_PL_name_to_uuid_dict(node_list)
        for key in PL_to_uuid:
            if key != "PL-3" and key != "PL-4" and PL_to_uuid[key]  not in self.input_data.uuids:
               self.scaleInNode(key)
               time.sleep(20)
               print("remove node " + key)
               sys.exit(REPEAT)

    def scaleInNode(self,node):
        scalein_command = "no ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=" + node + ",provides\n"
        scalein_command += "commit\n"
        stdout, stderr, retcode = self.run_com_cli_command(scalein_command)
        if retcode !=0:
            print("Failed to scale in " + node)
            sys.exit(RETURN_ERROR)
        print("Scale in " + node)

    def run_com_cli_command(self, command, configure_mode=True):
        import string
        printable = set(string.printable)
        cmd = filter(lambda x: x in printable, command)
        if configure_mode:
            cmmnd = "(echo 'scriptmode --on\nconfigure\n" + cmd + "\nend\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        else:
            cmmnd = "(echo 'scriptmode --on\n" + cmd + "\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        stdout, stderr, retcode = self.ssh.run_command(cmmnd, fail_at_error=False)
        return stdout, stderr, retcode

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='pre_scale_in hook for workflow')
        parser.add_argument('-f', '--stack-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of stack show details command in json format.',
                            type=str, required=True)
        parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                            help='Path to the file containing the private key for login', type=str, required=False)
        parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                            help='USERNAME', type=str, required=False)
        parser.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                            help='PASSWORD_FILE', type=str, required=False)
        args = parser.parse_args()
        with open(args.stack_details_file) as json_file:
            jsonfile = json.load(json_file)

        key_file = args.key_file

        uuids = None
        mip = None
        emergency_user = jsonfile["stack"]["parameters"]["emergency_username"]
        if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
            mip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
        else:
            mip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()

        obj = jsonfile["stack"]["outputs"]
        for x in obj:
            if x["output_key"] == "scaled_VMs_UUID":
                uuids = x["output_value"].strip().split()
        number_of_scaled_out_VMs = int(jsonfile["stack"]["parameters"]["number_of_scaled_out_VMs"].strip())

        return	PostScaleIn.InputData(mip, key_file, emergency_user,uuids,number_of_scaled_out_VMs)

def main():
    postscalein = PostScaleIn()

if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING,
                        format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
    logger = logging.getLogger('PostScaleIn')
    main()
#!/usr/bin/env python
import argparse
import os
import json
import logging
import time
import sys
from imscommon import SSHUtility

SUCCESS = 0
PARSE_ERROR = 1
MO_INSTANCE_ERROR = 2
CM_STATE_ERROR = 3
RETURN_ERROR = 4
RETURN_NOR_STD_ERROR = 5
REJECT = 6
REPEAT = 100

class preScalein:
    class InputData:
        def __init__(self, mip, scalein_num, key_file, emergency_user, uuids,vmNames,number_of_scaled_out_VMs,scaleType,specifiedUUIDs):
            self.mip = mip
            self.scalein_num = scalein_num
            self.key_file = key_file
            self.emergency_user = emergency_user
            self.uuids = uuids
            self.number_of_scaled_out_VMs = number_of_scaled_out_VMs
            self.scaleType = scaleType
            self.specifiedUUIDs = specifiedUUIDs
            self.vmNames = vmNames

    def __init__(self):
        self.input_data = preScalein.argument_parsing()
        self.ssh = self.connect_to_host(host=self.input_data.mip,
                                        username=self.input_data.emergency_user,
                                        key_filename=self.input_data.key_file,
                                        port=22)

        if not self.check_connection():
            logger.debug("Trying to SSH to the node")
            print("Trying to SSH to the node")
            sys.exit(REPEAT)

        if self.input_data.scalein_num > self.input_data.number_of_scaled_out_VMs :
            logger.info("Only " + str(self.input_data.number_of_scaled_out_VMs) + " VM(s) can be scaled in")
            sys.stderr.write("Only " + str(self.input_data.number_of_scaled_out_VMs) + " VM(s) can be scaled in")
            sys.exit(REJECT)

        if self.input_data.scaleType == None:
            self.scaleType = "GRACEFUL"
        elif self.input_data.scaleType.upper() == "GRACEFUL":
            self.scaleType = "GRACEFUL"
        elif self.input_data.scaleType.upper() == "FORCEFUL":
            self.scaleType = "FORCEFUL"
        else:
            sys.stderr.write("Invalid scale-in type. Valid scale-in types: GRACEFUL, FORCEFUL")
            sys.exit(REJECT)

        specifiedUUIDs = []
        if len(self.input_data.specifiedUUIDs) > 0:
            for uuid in self.input_data.specifiedUUIDs:
                if uuid.strip():
                   specifiedUUIDs.append(uuid.strip())

        if len(specifiedUUIDs)  > 0 and  len(specifiedUUIDs) != self.input_data.scalein_num:
            sys.stderr.write("Number of steps does not match the length of specified UUIDs")
            sys.exit(REJECT)

        if len(specifiedUUIDs)  > 0 :
            for uuid in specifiedUUIDs:
              if uuid not in self.input_data.uuids:
                 sys.stderr.write("The specified UUID " + uuid + " is not a valid UUID. Valid UUIDs: " + str(self.input_data.uuids))
                 sys.exit(REJECT)

        scaleUuids = []
        if len(specifiedUUIDs)  > 0:
            scaleUuids = specifiedUUIDs
        else:
            if self.input_data.scalein_num > 0 :
               scaleUuids = self.input_data.uuids[-self.input_data.scalein_num:]

        indexList = self.genScaleInList(self.input_data.vmNames, specifiedUUIDs)
        if self.scaleType == "FORCEFUL":
           output = {"number_of_scaled_out_VMs": str(self.input_data.number_of_scaled_out_VMs - self.input_data.scalein_num),"VM_to_be_scaled_in": indexList}
           print json.dumps(output)
           sys.exit(SUCCESS)

        PLs=self.getPLBasedUuid(scaleUuids)

        if len(PLs) == 0:
           output = {"number_of_scaled_out_VMs": str(self.input_data.number_of_scaled_out_VMs - self.input_data.scalein_num),"VM_to_be_scaled_in": indexList}
           print json.dumps(output)
           sys.exit(SUCCESS)

        self.verifyPLStatus(PLs)
        if self.checkPreCondition() == False:
           sys.exit(REJECT)
        self.scaleInPLs(PLs)
        sys.stdout.write("|Scaling in is ongoing, waiting...")
        time.sleep(10)
        sys.exit(REPEAT)

    def genScaleInList(self,vmNames, specifiedUUIDs):
        indexList=[]
        for uuid in specifiedUUIDs:
            VMname=vmNames[self.input_data.uuids.index(uuid)]
            index=VMname.split('-')[-1]
            indexList.append(index)
        return indexList

    def scaleInPLs(self, PLs):
        cmdStr = ""
        for PL in PLs:
           cmdStr = cmdStr + "no ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=" + PL + ",provides\n"
        cmdStr += "commit\n"
        stdout, stderr, retcode = self.run_com_cli_command(cmdStr)
        if retcode !=0:
            sys.stderr.write("Scaling in is not possible. Error: " + stderr)
            sys.exit(RETURN_ERROR)

    def verifyPLStatus(self, PLs):
        ContinueStat = False
        WaitStat = False
        for PL in PLs:
           cmdInsState = "show ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=" + PL +",instantiationState"
           cmdOprState = "show ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=" + PL +",operationalState"
           InsState = self.readParamStatus(cmdInsState)
           OprState = self.readParamStatus(cmdOprState)
           sys.stdout.write("|" + PL + " is in " + InsState)
           if InsState in ["INSTANTIATING","INSTANTIATION_FAILED","UNINSTANTIATION_FAILED"]:
              sys.stderr.write("|" +PL + " is in wrong state: " + InsState)
              sys.exit(RETURN_ERROR)
           elif InsState in ["SHUTTINGDOWN","UNINSTANTIATING"]:
              WaitStat = True
           elif InsState == "INSTANTIATED":
              ContinueStat = True

        if WaitStat and not ContinueStat:
           sys.stdout.write("|Scaling in is ongoing, waiting...")
           time.sleep(20)
           sys.exit(REPEAT)
        elif not WaitStat and ContinueStat:
           pass
        elif not WaitStat and not ContinueStat:
           pass
        else:
           sys.stderr.write("Some PL status is wrong but we can still go")

    def getPLBasedUuid(self, uuids):
        PLlist = self.getAllPL()
        return self.filterPLByUuid(PLlist,uuids)

    def getAllPL(self):
        stdout, stderr, retcode = self.ssh.run_command("immfind safAmfCluster=myAmfCluster | grep '^safAmfNode=' | egrep -o 'PL-[0-9]+,'")
        if retcode != 0:
           sys.stderr.write("Failed to get PL node list")
           sys.exit(RETURN_ERROR)
        node_list = []
        for node in stdout.split():
            node_list.append(node[:-1])
        node_list.sort(key=lambda x: int(x.split("-")[-1]))
        return node_list

    def filterPLByUuid(self, PLlist, uuids):
        PLmap = {}
        for node in PLlist:
            uuid_command = "show ManagedElement=1,Equipment=1,ComputeResource=" + node + ",uuid"
            stdout, stderr, retcode = self.run_com_cli_command(uuid_command)
            if retcode != 0:
               sys.stderr.write("Failed to read PL node list")
               sys.exit(RETURN_ERROR)
            uuid = stdout.strip().split('=')[-1].replace('"','').strip()
            if uuid in uuids:
               PLmap[node]=uuid
        PLs = []
        for uuid in uuids:
           if uuid in PLmap.values():
              PLs.append(PLmap.keys()[PLmap.values().index(uuid)])
        #we first scale in the last PL
        return list(reversed(PLs))


    def checkPreCondition(self):
        if self.checkOutOfMemory():
           sys.stderr.write("Scaling in is not possible because of Insufficient Memory Capabilities of Target Sized Cluster (DBS, Memory Limit Reached alarm is active). Hint: 1) If multiple VMs were tried to be scaled in parallel, it is recommended to scale in the VMs one by one. 2) Check MTAS troubleshooting guide")
           return False

        command = "show ManagedElement=1,MtasFunction=MtasFunction,MtasSupportFunctions=0,CarSel-Application=CarrierSelect,CarSelDialedStringAnalysisTable=0,carSelDialedStringAnalysisTableSynchronization"
        if self.readParamStatus(command) == "true" :
           sys.stderr.write("Scaling in is not allowed when there is hanging Carrier Select. Hint: Check MTAS troubleshooting guide")
           return False

        command ="show ManagedElement=1,MtasFunction=MtasFunction,MtasSupportFunctions=0,CarSel-Application=CarrierSelect,CarSelCarrierTable=0,carSelCarrierTableSynchronization"
        if self.readParamStatus(command) == "true" :
           sys.stderr.write("Scaling in is not allowed when there is Carrier Synchronization. Hint: Check MTAS troubleshooting guide")
           return False

        command ="show ManagedElement=1,MtasFunction=MtasFunction,MtasSupportFunctions=0,NumAna-Application=NumberAnalysis,NumAnaLocalCallTable=0,numAnaLocalCallTableSynchronization"
        if self.readParamStatus(command) == "true" :
           sys.stderr.write("Scaling in is not allowed when there is hunging Number Analysis. Hint: Check MTAS troubleshooting guide")
           return False

        command ="show ManagedElement=1,MtasFunction=MtasFunction,MtasSupportFunctions=0,NumberNormalisation=NumberNormalisation,numberNormalisationTableSync"
        if self.readParamStatus(command) == "SYNCHRONIZING" :
           sys.stderr.write("Scaling in is not allowed when there is Number Normalization Synchronization. Hint: Check MTAS troubleshooting guide")
           return False

    def connect_to_host(self, host, username, key_filename=None, port=22):
        ssh = SSHUtility.SSHUtility(ip=host,
                                    username=username,
                                    key_filename=key_filename,
                                    port=port,
                                    keep_alive=True)
        return ssh

    def check_connection(self):
        try:
            self.ssh.run_command("w")
        except:
            return False
        return True

    def run_com_cli_command(self, command, configure_mode=True):
        import string
        printable = set(string.printable)
        cmd = filter(lambda x: x in printable, command)
        if configure_mode:
            cmmnd = "(echo 'scriptmode --on\nconfigure\n" + cmd + "\nend\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        else:
            cmmnd = "(echo 'scriptmode --on\n" + cmd + "\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        stdout, stderr, retcode = self.ssh.run_command(cmmnd, fail_at_error=False)
        return stdout, stderr, retcode

    def checkOutOfMemory(self):
        command = "show ManagedElement=1,SystemFunctions=1,Fm=1 -m FmAlarm -c majorType=193 && minorType=917505 && probableCause=162 && specificProblem=\"DBS, Memory Limit Reached\""
        stdout, stderr, retcode = self.run_com_cli_command(command)
        if retcode == 0:
            if stdout.strip() != "":
               return True
        return False

    def readParamStatus(self, command):
        stdout, stderr, retcode = self.run_com_cli_command(command)
        if retcode == 0:
           for line in stdout.split("\n"):
               state = line.split("=")[1]
               logger.info(command + " " +state)
               return state

        logger.warn("Failed to read command: " + command)
        sys.exit(CM_STATE_ERROR)

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='pre_scale_in hook for workflow')
        parser.add_argument('-f', '--stack-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of stack show details command in json format.',
                            type=str, required=True)
        parser.add_argument('-n', '--number-of-steps', metavar='<STEPS>',
                            help='Number of scaling steps', type=int, required=True)
        parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                            help='Path to the file containing the private key for login', type=str, required=False)
        parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                            help='USERNAME', type=str, required=False)
        parser.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                            help='PASSWORD_FILE', type=str, required=False)
        parser.add_argument('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
                            help='All additional parameters in json format.',
                            type=str, required=False)
        args = parser.parse_args()
        with open(args.stack_details_file) as json_file:
            jsonfile = json.load(json_file)

        additonalParamsfile=args.additional_param_file

        key_file = args.key_file
        scalein_num = args.number_of_steps
        uuids = None
        mip = None
        vmNames = None
        emergency_user = jsonfile["stack"]["parameters"]["emergency_username"]
        if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
            mip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
        else:
            mip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()

        obj = jsonfile["stack"]["outputs"]
        for x in obj:
            if x["output_key"] == "scaled_VMs_UUID":
                uuids = x["output_value"].strip().split()
            if x["output_key"] == "scaled_VMs_name":
                vmNames = x["output_value"].strip().split()
        number_of_scaled_out_VMs = int(jsonfile["stack"]["parameters"]["number_of_scaled_out_VMs"].strip())
        specifiedUUIDs = []
        scaleType = None
        if additonalParamsfile:
            with open(additonalParamsfile) as adp_json:
                additionjs = json.load(adp_json)
            scaleType= additionjs.get("scaleInType",None)
            uuidList = additionjs.get("listOfUUIDsToBeDeleted",None)
            if uuidList:
               specifiedUUIDs = uuidList

        return	preScalein.InputData(mip, scalein_num, key_file, emergency_user,uuids,vmNames,number_of_scaled_out_VMs,scaleType,specifiedUUIDs)

def main():
    prescalein = preScalein()

if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING,
                        format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
    logger = logging.getLogger('preScaleIn')
    main()



#!/usr/bin/env python
import logging
import os
import re
import sys
import time
import imscommon.logging
from imscommon import SSHUtility

class ReturnCode:
    SUCCESS = 0
    PARSE_ERROR = 1
    MO_INSTANCE_ERROR = 2
    ADMIN_STATE_ERROR = 3
    RETURN_ERROR = 4
    RETURN_NOR_STD_ERROR = 5
    STD_ERROR = 6
    CLISS_ERROR = 7
    INVALID_JSON = 8
    MISSING_JSON_PARAMETER = 9
    INVALID_PAYLOAD_INSTANCE_COUNT = 10
    INVALID_STEP_NUMBER = 11
    RESOURCE_CARDINALITY_MISMATCH = 12
    INVALID_SHUTDOWN_TYPE = 13
    REPEAT = 100

class Exit(Exception):
    def __init__(self, return_code):
        self.return_code = return_code

logger = logging.getLogger("vMtasLcmCommon")

class CommonLcmTask(object):

    def __init__(self):
        self.ssh = None
        self.state = None
        self.workflow = None

    def connect_to_host(self, host, username, key_filename=None, password=None, port=22):
        if key_filename is None:
            self.ssh = SSHUtility.SSHUtility(ip=host,
                                             username=username,
                                             password=password,
                                             port=port,
                                             keep_alive=True)
        else:
            self.ssh = SSHUtility.SSHUtility(ip=host,
                                             username=username,
                                             key_filename=key_filename,
                                             port=port,
                                             keep_alive=True)
        return self.ssh

    def check_connection(self):
        try:
            self.ssh.run_command("w")
        except:
            return False
        return True

    def run_com_cli_command(self, command, configure_mode=True):
        """
        Note that this method takes the input from create_com_cli_cmd_string
        """
        import string
        printable = set(string.printable)
        cmd = filter(lambda x: x in printable, command)
        if configure_mode:
            cmmnd = "{ echo 'configure' ; " + command +\
                    " echo 'commit' ; echo 'exit' ; } | /opt/com/bin/cliss -sb"
        else:
            cmmnd = "{ " + command + " echo 'exit' ; } | /opt/com/bin/cliss -sb"
        try:
            stdout, stderr, retcode = self.ssh.run_command(cmmnd, fail_at_error=False)
            logger.debug("stdout: " + stdout)
        except:
            logger.error("Command execution failed. Bailing out.")
            print (" Failed to run command [" + cmmnd + "]")
            sys.exit(ReturnCode.RETURN_ERROR)
        return stdout, stderr, retcode

    def create_com_cli_cmd_string(self, cmd):
        """
        This method creates the command string that should be provided to
        run_com_cli_command. If it is required to run multiple commands,
        the output from this method should be concatenated
        """
        s = "echo '" + cmd + "' ; "
        return s

    def run_show_com_cli_command(self, command):
        stdout, stderr, retcode = self.run_com_cli_command(self.create_com_cli_cmd_string(command), configure_mode=False)
        return stdout, stderr, retcode

    def create_vnflcm_dir(self):
        try:
            self.ssh.run_command("if [ ! -d /cluster/home/vnflcm ]; then     mkdir -m 777 /cluster/home/vnflcm; fi")
        except:
            print "ERROR: Failed to create dir /cluster/home/vnflcm/  |"
            sys.exit(ReturnCode.RETURN_ERROR)

    def read_state_file(self, wflow):
        self.workflow = wflow
        try:
            stdout, _, retcode = self.ssh.run_command("cat /cluster/home/vnflcm/" + self.workflow + "_wf_state", fail_at_error=False)
            if retcode == 0:
                #print "Workflows state file read successfully |"
                self.state = stdout
            else:
                logger.debug("ERROR: Could not read workflows state file  |")
                self.state = ""
        except:
            print "Failed to read state file - retrying |"
            sys.exit(ReturnCode.REPEAT)

    def perform_step(self, config_step):
        if config_step in self.state:
        #print(config_step + " config step is already performed")
            logger.debug(config_step + " config step is already performed")
            return False
        return True

    def rm_state_file(self):
        logger.debug("Deleting state file")
        cmd = "rm -f " + "/cluster/home/vnflcm/" + self.workflow + "_wf_state"
        self.ssh.run_command(cmd, fail_at_error=False)
        return

    def update_state_file(self, config_step):
        logger.debug("Updating state file with " + config_step)
        cmd = "echo '" + config_step + "' >> '/cluster/home/vnflcm/" +\
              self.workflow + "_wf_state'"
        self.ssh.run_command(cmd, fail_at_error=False)
        return True

    def maxWaitingExceeded(self, maxwait):
        """
        Very simple way to implement waiting logic
        """
        waitstate = "wait"
        if maxwait > 999:
            return True
        for count in xrange(1, 999, 1):
            if count > maxwait:
                print("Max waiting time exceeded")
                self.update_state_file("error")
                return True
            checkfor = waitstate + "%02d" % count
            if self.perform_step(checkfor):
                self.update_state_file(checkfor)
                return False
        return True

    def cp_file(self, s_file, d_file):
        cmd = "cp -f " + s_file + d_file
        self.ssh.run_command(cmd, fail_at_error=False)
        return

    def rm_file(self, file):
        cmd = "rm -f " + file
        self.ssh.run_command(cmd, fail_at_error=False)
        return

    def mv_file(self, s_file, d_file):
        cmd = "mv -f " + s_file  + d_file
        self.ssh.run_command(cmd, fail_at_error=False)
        return

    def readAdmStatus(self):
        logger.debug("Reading cscfAdministrativeState")
        command = self.create_com_cli_cmd_string("show ManagedElement=1,CscfFunction=1,CSCF-Application=CSCF,cscfAdministrativeState")
        stdout, stderr, retcode = self.run_com_cli_command(command, configure_mode=False)
        if retcode == 0:
           for line in stdout.split("\n"):
               if "cscfAdministrativeState=" in line:
                  state = line.split("=")[1]
                  logger.debug("cscfAdministrativeState=" + state)
                  return state

        logger.error("Failed to read cscfAdministrativeState. Bailing out.")
        print("Failed to read cscfAdministrativeState")
        sys.exit(ReturnCode.ADMIN_STATE_ERROR)

    def updateAdminstatus(self, status):
        logger.debug("Updating cscfAdministrativeState")
        command = self.create_com_cli_cmd_string("ManagedElement=1,CscfFunction=1,CSCF-Application=CSCF,cscfAdministrativeState=%s" % status)
        stdout, stderr, retcode = self.run_com_cli_command(command)
        if retcode != 0:
           logger.error("Failed to update cscfAdministrativeState. Bailing out.")
           print("Failed to update cscfAdministrativeState")
           return False
        return True

    def checkVdicosStatus(self):
        """
        This method will check if 'cdsv-get-user-state' indicates that a
        reconfiguration in DBS is ongoing.
        If this is the case, scaling will be rejected.
        """
        logger.debug("Checking vDicos status")
        try:
            stdout, stderr, retcode = self.ssh.run_command("cdsv-get-user-state", fail_at_error=False)
            m = re.findall("cluster state: Idle", stdout, re.IGNORECASE)
            if (len(m) < 2):
                logger.debug("vdicos is not idle")
                return False
        except Exception as ex:
            logger.error("Failed to get vDicos status: %s" % str(ex))
            # TODO: What do we print here?
            sys.stderr.write("Failed to check VNF status")
            # TODO: How do we handle this case?
            sys.exit(ReturnCode.RETURN_ERROR)
        logger.debug("vDicos status is OK")

        return True

    def checkCrMStatus(self):
        """
        This method will check if any ComputeResourceRole is in wrong status.
        If this is the case, scaling will be rejected.
        """
        logger.debug("Checking CrM status")
        CRM_status = self.get_all_CrM_status()
        for key, value in CRM_status.items():
            if key != "SC-1" and key != "SC-2" and \
               key != "PL-3" and key != "PL-4":
                if value['instantiationState'] in ["INSTANTIATING", "INSTANTIATION_FAILED", "UNINSTANTIATION_FAILED"]:
                    return False
        return True

    def get_all_CrM_status(self):
        """
        This method returns a hashmap/dict with node name as key (e.g. PL-3)
        and the value is a dict with adminState,instantiationState and operationalState.
        """
        logger.debug("Get CrM status")
        cmd = "show -r -m ComputeResourceRole -p adminState,instantiationState,operationalState "
        try:
            stdout, _, _ = self.run_show_com_cli_command(cmd)
            logger.debug(stdout)
        except Exception as ex:
            logger.error("Failed to get compute resource data: %s" % str(ex))
            # TODO: What do we print here?
            print("Failed to check VNF status")
            sys.exit(ReturnCode.RETURN_ERROR)

        m = re.findall('^[\w,=]+(\w{2}-\d+)$\s+adminState=([\w]+)$\s+instantiationState=([\w]+)$\s+operationalState=([\w]+)$',
                        stdout,
                        re.MULTILINE)
        CRM_status = {}
        for i in m:
            status = { 'adminState': i[1], 'instantiationState': i[2], 'operationalState': i[3] }
            CRM_status[i[0]] = status
        logger.debug("CrM status [" + str(CRM_status) + "]")
        return CRM_status

    def get_equipment_data(self):
        """
        This method will fetch the node-names/cluster-members
        and their UUID from COM CLI
        """
        cmd = "show -r -m ComputeResource  -p uuid "
        try:
            stdout, _, _ = self.run_show_com_cli_command(cmd)
            return stdout
        except Exception as ex:
            logger.error("Failed to get equipment data: %s" % str(ex))
            sys.exit(ReturnCode.RETURN_ERROR)

    def get_PL_name_to_uuid_dict(self, equipment):
        """
        This method returns a hashmap/dict with node name as key (e.g. PL-3)
        and the value is the UUID of the node/cluster-member
        """
        logger.debug(equipment)
        m = re.findall('^[\w,=]+(\w{2}-\d+)$\s+uuid="([\w-]+)"$',
                        equipment,
                        re.MULTILINE)
        PL_to_uuid = {}
        for i in m:
            PL_to_uuid[i[0]] = i[1]
        logger.debug("PL to UUID [" + str(PL_to_uuid) + "]")
        return PL_to_uuid

    def getScaleInVmIndexList(self, scaleinuuids):
        """
        This method will return a list of VM numbers for the VM(s) that
        should be removed during the stack-update.
        """
        vmIndexList = []
        for uuid in scaleinuuids:
            vmname = self.input_data.vmnames[self.input_data.uuids.index(uuid)]
            vmindex = vmname.split('-')[-1]
            vmIndexList.append(vmindex)
        return vmIndexList

    def cbaScaleIn(self, uuids):
        """
        This method will execute CMW scale-in commands in order to remove
        cluster members from the cluster.
        """
        logger.debug("Scaling in: " + ", ".join(uuids))
        if not self.perform_step("cbaScaleIn"):
            # All PL has already been removed
            logger.debug("All PL has already been removed")
            return
        PL_to_uuid = self.get_PL_name_to_uuid_dict(self.get_equipment_data())
        logger.debug("PL-to-UUID [" + str(PL_to_uuid) + "]")
        cmd = ""
        for key in PL_to_uuid:
             if key != "SC-1" and key != "SC-2" and \
               key != "PL-3" and key != "PL-4" and \
               PL_to_uuid[key] not in uuids:
                cmd = cmd + self.create_com_cli_cmd_string(\
                      "no ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,"+\
                      "ComputeResourceRole=" + key + ",provides")
        if not cmd:
            #nothing to scale in
            logger.debug("Nothing to scale in")
            self.update_state_file("cbaScaleIn")
            return
        logger.debug("Running CMW scale-in command [" + cmd + "]")
        stdout, stderr, retcode = self.run_com_cli_command(cmd, configure_mode=True)
        logger.debug("CMW scale-in result STDOUT [" + stdout +\
                     "] STDERR [" + stderr + "] RES [" +\
                     str(retcode) + "]")
        if retcode != 0:
            logger.error("Failed to run scale in CMD [" + cmd + "")
            # TODO: Do we want to print this?
            print("Failed to run scale in CMD [" + cmd + "")
            self.rm_state_file()
            sys.exit(ReturnCode.RETURN_ERROR)
        time.sleep(20)
        self.update_state_file("cbaScaleIn")
        sys.exit(ReturnCode.REPEAT)

    def checkScaleInComplete(self):
        """
        This method will check if CMW scale-in operation has been
        completed or not. If the scale-in PL(s) has not disappeared
        from COM CLI, it is assumed that scale-in still is ongoing.
        If scale-in is still ongoing, REPEAT exit code will be
        used.
        If the scale-in operation hasn't completed after 30 checks,
        scale-in operation is considered as failed.
        """
        logger.debug("Check if scale-in is complete")
        if not self.perform_step("checkScaleInComplete"):
            # All PL has already been removed
            return
        PL_to_uuid = self.get_PL_name_to_uuid_dict(self.get_equipment_data())
        mustwait = False
        logger.debug("checkScaleInComplete PL-to-UUID [" +\
                     str(PL_to_uuid) + "]")
        for key in PL_to_uuid:
            if key != "SC-1" and key != "SC-2" and \
               key != "PL-3" and key != "PL-4" and \
               PL_to_uuid[key] not in self.input_data.uuids:

                logger.debug("Wait scale-in complete Node [" + \
                             key + "] is still active, must wait")
                mustwait = True
        if mustwait:
            #Scale in still ongoing
            time.sleep(20)
            logger.debug("Scale-in operation is NOT completed")
            if self.maxWaitingExceeded(30):
                logger.error("Exceeded max waiting time for scale-in, " +\
                             "most likely scale-in is rejected")
                self.rm_state_file()
                sys.exit(ReturnCode.RETURN_ERROR)
        else:
            logger.debug("Scale-in operation is completed")
            self.update_state_file("checkScaleInComplete")
        sys.exit(ReturnCode.REPEAT)

def setup_default_logging():
    imscommon.logging.configure_logging()

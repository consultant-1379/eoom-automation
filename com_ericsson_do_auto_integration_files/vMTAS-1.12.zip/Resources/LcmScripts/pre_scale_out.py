#!/usr/bin/env python
import argparse
import json
import logging
import sys
from imscommon import SSHUtility

REPEAT = 100

class PrescaleOut:

    class InputData:
         def __init__(self, number_of_scaled_out_VMs, number_of_steps, mip, emergency_user, key_file):
             self.number_of_scaled_out_VMs = number_of_scaled_out_VMs
             self.number_of_steps = number_of_steps
             self.mip = mip
             self.key_file = key_file
             self.emergency_user = emergency_user

    def __init__(self):
        self.inputData = PrescaleOut.argument_parsing()
        output = {"number_of_scaled_out_VMs": str(self.inputData.number_of_steps + self.inputData.number_of_scaled_out_VMs)}
        print json.dumps(output)
        #Store it in one file
        self.ssh = self.connect_to_host(host=self.inputData.mip,
                                        username=self.inputData.emergency_user,
                                        key_filename=self.inputData.key_file,
                                        port=22)
        if not self.check_connection():
            logger.debug("Trying to SSH to the node")
            print("Trying to SSH to the node")
            sys.exit(REPEAT)

        self.storeNumOfStep()

    def connect_to_host(self, host, username, key_filename=None, port=22):
        ssh = SSHUtility.SSHUtility(ip=host,
                                    username=username,
                                    key_filename=key_filename,
                                    port=port,
                                    keep_alive=True)
        return ssh

    def check_connection(self):
        try:
            self.ssh.run_command("w")
        except:
            return False
        return True

    def storeNumOfStep(self):
        stdout, stderr, retcode = self.ssh.run_command("echo number-of-steps=" + str(self.inputData.number_of_steps) + " > /cluster/home/vnflcm/scaleOut_num", fail_at_error=False)
        if retcode != 0:
           logger.warn("Can not store the number of step")

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='pre_scale_out hook for workflow')
        parser.add_argument('-f', '--stack-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of stack show details command in json format.',
                            type=str, required=True)
        parser.add_argument('-n', '--number-of-steps', metavar='<STEPS>',
                            help='Number of scaling steps.', type=int, required=True)
        parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                            help='Path to the file containing the private key for login', type=str, required=False)
        parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                            help='Username to login into the VNF instance', type=str, required=False)
        parser.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                            help='Path to the file containing the password to login into \
                            the VNF instance.', type=str, required=False)
        args = parser.parse_args()
        key_file = args.key_file
        logger.info(args.stack_details_file)
        with open(args.stack_details_file) as json_file:
            jsonfile = json.load(json_file)
        emergency_user = jsonfile["stack"]["parameters"]["emergency_username"]
        number_of_steps = args.number_of_steps
        number_of_scaled_out_VMs = int(jsonfile["stack"]["parameters"]["number_of_scaled_out_VMs"].strip())
        mip = None
        if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
            mip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
        else:
            mip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()

        return PrescaleOut.InputData(number_of_scaled_out_VMs, number_of_steps, mip, emergency_user, key_file)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
    logger = logging.getLogger('pre_scaleOut')
    PrescaleOut()

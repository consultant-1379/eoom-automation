#!/usr/bin/env python
import argparse
import os
import json
import logging
import time
import sys
import subprocess
from common import setup_default_logging
from common import CommonLcmTask
from parsers import VCDXmlParser


SUCCESS = 0
ERROR = 1
REPEAT = 100

logger = None

class Exit(Exception):
    pass


class PreTermination(CommonLcmTask):
    class InputData:
        def __init__(self, mip, termination_type, termination_timer, key_file, id, emergency_user):
            self.mip = mip
            self.termination_type = termination_type
            self.key_file = key_file
            self.termination_timer = termination_timer
            self.termination_timer_file = "/tmp/lcm_shutdown_" + id
            self.id = id
            self.emergency_user = emergency_user

#### Main logic of PreTermination hook ####
    def __init__(self):
        global logger
        self.input_data = PreTermination.argument_parsing()
	print("Starting "+self.input_data.termination_type+" termination |")

        # determine termination type
        if self.input_data.termination_type == "FORCEFUL":
           logger.debug("FORCEFUL TERMINATION")
           print("Finished")
           sys.exit(SUCCESS)

        amethod = None

        # determine authentication method and initiate connection
        if hasattr(self.input_data,'key_file'):
           print("Establishing ssh connection using publickey for user "+self.input_data.emergency_user+"|")
           amethod = 'publickey'
           self.connect_to_host(
               host=self.input_data.mip,
               username=self.input_data.emergency_user,
               key_filename=self.input_data.key_file,
               port=22)

        elif hasattr(self.input_data,'password_file'):
            print("Establishing ssh connection using password |")
            amethod = 'password'
            with open(self.input_data.password_file, 'r') as f:
                self.connect_to_host(
                    host=self.input_data.mip,
                    username=self.input_data.emergency_user,
                    password=f.read(),
                    port=22)

        if amethod == None:
            print("No known autentication method specified; attempting to connect with default credentials |")
            logger.debug("No known authentication info is supplied for SSH connection to the node; defaulting to root; mIP is "+self.input_data.mip)
            self.connect_to_host(
                host=self.input_data.mip,
                username='root',
                password='rootroot',
                port=22)
            sys.exit(ERROR)

        # wait until the connection is established
        if not self.check_connection():
            logger.debug("Trying to SSH to the node via "+self.input_data.mip+" using "+amethod)
            print("Still trying to SSH to the node via "+self.input_data.mip+" using "+amethod+ " |")
            sys.exit(REPEAT)

        logger.debug("Successfully established SSH connection to the node via "+self.input_data.mip+" using "+amethod)

        # check termination timer
        self.termination_timer = self.readTerminateTimer()
        if self.termination_timer is None:
           logger.debug("Update the termination Timer")
           self.updateTerminateTimer(self.input_data.termination_timer)
           self.updateAdminState("SHUTTINGDOWN")
           print("Graceful shutdown of the node is in progress |")
           sys.exit(REPEAT)

        # when no termination timeout specified, wait for admin state transition to LOCKED
        adminState = self.readAdminState()
        if self.termination_timer == -1:
           # already locked
           if adminState == "LOCKED":
              logger.debug("Administrative State is %s", adminState)
              print("Administrative State is " + adminState + " |")
              self.removeTerminateTimer()
              sys.exit(SUCCESS)
           # still in progress
           else:
              if adminState != "SHUTTINGDOWN" :
                 self.updateAdminState("SHUTTINGDOWN")
              sys.exit(REPEAT)

        # when termination timer is specified, wait for either termination timer expiry
        # or admin state transition to LOCKED
        logger.debug("Administrative State is %s", adminState)
        print("Administrative State is " + adminState + " |")
        if self.hasTerminateTimerExpired() or (adminState == "LOCKED") :
            self.removeTerminateTimer()
            print("Graceful shutdown of the node succeeded |")
            sys.exit(SUCCESS)
        else:
            sys.exit(REPEAT)

########

    def readAdminState(self):
        command = "show ManagedElement=1,MtasFunction=MtasFunction,mtasFunctionAdministrativeState"
        stdout, stderr, retcode = self.run_com_cli_command(command, configure_mode=False)
        if retcode == 0:
           for line in stdout.split("\n"):
               if "mtasFunctionAdministrativeState=" in line:
                  state = line.split("=")[1]
                  return state

        logger.debug("Failed to read mtasFunctionAdministrativeState")
        print("Failed to read mtasFunctionAdministrativeState")
        sys.exit(ERROR)

    def updateAdminState(self, status):
        command = """ManagedElement=1,MtasFunction=MtasFunction,mtasFunctionAdministrativeState=%s
commit""" %  status

        stdout, stderr, retcode = self.run_com_cli_command(command)
        if retcode != 0:
           logger.debug("Failed to update mtasFunctionAdministrativeState")
           print("Failed to update mtasFunctionAdministrativeState")
           return False
        return True

    def readTerminateTimer(self):
        stdout, stderr, retcode = self.ssh.run_command("cat '"+self.input_data.termination_timer_file+"'" , fail_at_error=False)
        if retcode == 0:
            return int(float(stdout.split("\n")[0]))
        else:
            logger.debug("Cannot read termination timer file. Shell response: "+ stderr)
            return None

    def updateTerminateTimer(self,delta):
        if delta == -1 :
           shutTimer = -1
        else:
           shutTimer = time.time() + delta
        stdout, stderr, retcode = self.ssh.run_command("echo '" + str(shutTimer) + "' > '"+self.input_data.termination_timer_file+"'", fail_at_error=False)
        if retcode != 0:
           logger.debug("Cannot update termination timer file. Shell response: "+ stderr)

    def removeTerminateTimer(self):
        self.ssh.run_command("rm -f '"+self.input_data.termination_timer_file+"'", fail_at_error=False)

    def hasTerminateTimerExpired(self):
        curTime = time.time()
        if curTime >= self.termination_timer:
           logger.debug("Termination timer expired")
           print("Termination timer expired")
           return True
        else:
           return False

    def run_com_cli_command(self, command, configure_mode=True):
        import string
        printable = set(string.printable)
        cmd = filter(lambda x: x in printable, command)
        if configure_mode:
            cmmnd = "(echo 'scriptmode --on\nconfigure\n" + cmd + "\nend\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        else:
            cmmnd = "(echo 'scriptmode --on\n" + cmd + "\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        stdout, stderr, retcode = self.ssh.run_command(cmmnd, fail_at_error=False)
        return stdout, stderr, retcode

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='PreTermination hook for workflow')
        parser.add_argument(
            '-f', '--vnf-instance-details-file', '--stack-details-file', metavar='<FILE>',
            help=('Path to the file containing the response of '
                  'stack show details (OpenStack) or vAPP details (vCloud Director) '
                  'command in json (OpenStack) or xml (vCloud Director) format.'),
                   required=True)

        parser.add_argument(
           '-t', '--termination-type', metavar='<TERMINATION_TYPE>',
           choices=['GRACEFUL','FORCEFUL'],
           help='Specifies whether GRACEFUL or FORCEFUL termination is desired',
           type=str, required=True)

        parser.add_argument(
           '-s', '--shutting-down-timer', metavar='<Timer>',
           help=('Only applicable in case of GRACEFUL termination. After the timer '
                '(in seconds) expires, the script takes the VNF out of service'),
                type=int, required=False)

        parser.add_argument(
           '-u', '--user-name', metavar='<USERNAME>',
           help='Username to login into the VNF instance',
           type=str, required=False)

        parser.add_argument(
           '-k', '--key-file', metavar='<KEY_FILE>',
           help='Path to the file containing the private key for login',
           type=str, required=False)

        parser.add_argument(
           '-p', '--password-file', metavar='<PASSWORD_FILE>',
           help=('Path to the file containing the password to login into '
           'the VNF instance.'),
           type=str, required=False)

        args = parser.parse_args()

        logger = logging.getLogger('vMtasLcmPreTermination.argParsing')
        logger.debug("argDetailsFile = " + args.vnf_instance_details_file)

        if args.vnf_instance_details_file.endswith('.xml'):
            return PreTermination.parseVCDXmlFile(args)
        else:
            return PreTermination.parseOpenStackJsonFile(args)

    @staticmethod
    def parseOpenStackJsonFile(args):
       global logger

       with open(args.vnf_instance_details_file) as json_file:
           jsonfile = json.load(json_file)

       logger = logging.getLogger('vMtasLcmPreTermination.' + jsonfile["stack"]["stack_name"])
       logger.debug("Parsing Openstack JSON file...")

       logger.debug('json file [%s] loaded', args.vnf_instance_details_file)
       logger.debug('Termination_type [%s] loaded', args.termination_type)
       termination_timer = args.shutting_down_timer
       if termination_timer is None:
          termination_timer = -1
       logger.debug("shutting_down_timer is %d",termination_timer)

       mip = None
       stack_file = os.path.basename(args.vnf_instance_details_file)

       id = stack_file.split('_')[1].split('.')[0]
       emergency_user = None
       if args.user_name is not None:
           emergency_user = args.user_name
       else:
           emergency_user = jsonfile["stack"]["parameters"]["emergency_username"]

       if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
           mip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
       else:
           mip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()

       return PreTermination.InputData(mip, args.termination_type, termination_timer, args.key_file, id, emergency_user)

    @staticmethod
    def parseVCDXmlFile(args):
       vcdParser = VCDXmlParser(args.vnf_instance_details_file)
       vApp = vcdParser.vnf_status_file
       vAppName = vApp.attrib.get("name")
       if vAppName == None:
           sys.exit(ERROR)
       global logger
       logger = logging.getLogger('vMtasLcmPreTermination.' + vAppName)
       logger.debug("Parsing VCD XML file...")

       logger.debug('VCD xml file [%s] loaded', args.vnf_instance_details_file)
       logger.debug('Termination_type [%s] loaded', args.termination_type)
       termination_timer = args.shutting_down_timer
       if termination_timer is None:
          termination_timer = -1
       logger.debug("shutting_down_timer is %d",termination_timer)

       mip = None
       vnf_file = os.path.basename(args.vnf_instance_details_file)

       id = vnf_file.split('.')[0]
       emergency_user = vcdParser.get_property('emergency_username')
       OM_IPv4_address = vcdParser.get_property('OM_IPv4_address').strip()
       if OM_IPv4_address == "none":
           mip = vcdParser.get_property('OM_IPv6_address').strip()
       else:
           mip = OM_IPv4_address

       key_file = os.path.expanduser('~')+"/.ssh/id_rsa"

       return PreTermination.InputData(mip, args.termination_type, termination_timer, key_file, id, emergency_user)

def main():
#    with open("/tmp/workflows_test/"+os.path.basename(__file__), "w+") as f:
#        f.write('** Command Line **\n"'+'" "'.join(sys.argv)+'"\n\n')
#        f.write("** Environment **\n")
#        for a in os.environ.keys():
#            f.write(a+"="+os.environ[a]+'\n')
#        f.write("\n\n")
#        f.write("** Content of /proc/self/ **\n"+subprocess.Popen(['ls','-lh','/proc/self/'],stdout=subprocess.PIPE).stdout.read())
    pretermination = PreTermination()

if __name__ == '__main__':
    setup_default_logging()
    main()

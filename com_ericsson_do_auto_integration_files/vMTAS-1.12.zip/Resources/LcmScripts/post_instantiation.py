#!/usr/bin/env python
import argparse
import os
import json
import logging
import time
import sys
import re
import subprocess
sys.path.append(os.path.dirname(__file__))
from common import setup_default_logging
from common import CommonLcmTask
#from imscommon import SSHUtility
from imscommon import PdbConfigExecutor
from parsers import VCDXmlParser

logger = None # logging.getLogger("vMtasLcmPostInstantiation")

SUCCESS = 0
PARSE_ERROR = 1
MO_INSTANCE_ERROR = 2
ADMIN_STATE_ERROR = 3
RETURN_ERROR = 4
RETURN_NOR_stderrOR = 5
stderrOR = 6
REPEAT = 100


class Exit(Exception):
    pass

class PostInstantiation(CommonLcmTask):
    class InputData:
        def __init__(self, mip, config_dir, key_file, sc1_ip, sc2_ip, platform_vip, platform_vip6, tasvip4, tasvip6,
                     ut_vip4, ut_vip6, cai3g_vip4, cai3g_vip6, sigtran1_vip4,
                     sigtran1_vip6, sigtran2_vip4, sigtran2_vip6,
                     emergency_username, emergency_password_hash,
                     secla_password_hash, root_password_hash, oss_pm_password_hash, stack_name):
            self.mip = mip
            self.config_dir = config_dir
            self.key_file = key_file
            self.sc1_ip = sc1_ip
            self.sc2_ip = sc2_ip
            self.platform_vip = platform_vip
            self.platform_vip6 = platform_vip6
            self.tasvip4 = tasvip4
            self.tasvip6 = tasvip6
            self.ut_vip4 = ut_vip4
            self.ut_vip6 = ut_vip6
            self.cai3g_vip4 = cai3g_vip4
            self.cai3g_vip6 = cai3g_vip6
            self.sigtran1_vip4 = sigtran1_vip4
            self.sigtran1_vip6 = sigtran1_vip6
            self.sigtran2_vip4 = sigtran2_vip4
            self.sigtran2_vip6 = sigtran2_vip6
            self.emergency_username = emergency_username
            self.emergency_password_hash = emergency_password_hash
            self.secla_password_hash = secla_password_hash
            self.root_password_hash = root_password_hash
            self.oss_pm_password_hash = oss_pm_password_hash
            self.stack_name = stack_name

    def __init__(self):
        global logger
        self.input_data = PostInstantiation.argument_parsing()

	#print("Establishing ssh connection to "+self.input_data.mip)

        try:
            self.connect_to_host(host=self.input_data.mip,
                                 username="root",
                                 password="rootroot",
                                 port=22)
        except:
            logger.debug("Connecting to host is not yet successful - Repeat ")
            print(" Connecting to host is not yet successful  |")
            sys.exit(REPEAT)

        if not self.check_connection():
            logger.debug("Trying to SSH")
            print(" Waiting for NBI to become available  |")
            sys.exit(REPEAT)

	#print("Creating LCM home dir")
        self.create_vnflcm_dir()

	#print("Reading post install state")
        self.read_state_file("post_install")

	#print("State is "+self.state)

	#print("Waiting for cmw status to become OK")
        self.waiting_for_cmw_status_ok()

	#print("Checking cmw status")
        self.check_cmw_status_node_su_sg()

	#print("Checking ESM image")
        self.check_esm_image()

	#print("Checking hardware clock")
        self.check_hw_clock()

	#print("Reconfiguring cluster")
        self.cluster_delta_configure()

	#print("Reconfiguring eVIP")
        self.evip_delta_configure()

	#print("Reconfiguring SS7")
        self.ss7_delta_configure()

	#print("Updating COM with stack name")
        self.managedElement_update(self.input_data.stack_name)

	#print("Configuring Cai3g")
        self.cai3g_max_sessions_cofigure()
        self.apply_pdb()
        self.add_emergency_user()
        self.change_secla_password()
        self.add_vnflcm_key()
        self.prepare_sftp_connection()
        self.enable_scaling()
        self.disable_root_login()  # needs a: cluster config -r -a
        self.change_root_password()
        self.ssh.run_command("clurun.sh clear_logs", fail_at_error=False)
        self.ssh.run_command("rm -rf /opt/cdclsv/storage/dumps/*", fail_at_error=False)
        self.ssh.run_command("rm -rf /opt/cdclsv/storage/cadump/*", fail_at_error=False)
        self.rm_file("/cluster/home/vnflcm/post_install_wf_state")
        self.ssh.close()
        logger.debug("Post-instantiation hook finished successfully")
        sys.exit(SUCCESS)

    def perform_config_step(self, config_step):
        return not self.perform_step(config_step)

    def waiting_for_cmd_status_ok(self, p_cmd, p_retry_loop=20, p_sleep=5):
        logger.debug("Waiting for " + p_cmd + " status OK...")
        for l_attempt in range(1, p_retry_loop):
            try:
                self.ssh.run_command(p_cmd)
                logger.debug("cmd status is OK")
                return "OK"
            except:
                logger.debug("cmd status is NOT OK, retry... " + str(l_attempt) + "/" + str(p_retry_loop))
                time.sleep(p_sleep)
        logger.error(p_cmd + " status is NOT OK")
        return "NOT OK"

    def waiting_for_cmw_status_ok(self, retry_loop=10):
        logger.debug("Waiting for CoreMW")
        state = self.waiting_for_cmd_status_ok("cmw-status node", p_retry_loop=retry_loop)
        logger.debug("CoreMW status: " + str(state))
        #print(" CoreMW status: " + str(state) + "  |")
        if state == "NOT OK":
            print(" CoreMW status: " + str(state) + " yet  |")
            logger.debug("CoreMW status: " + str(state) + ", exit with REPEAT")
            sys.exit(REPEAT)

    def check_cmw_status_fails_beside_locked_mmas_oam(self, cmw_status):
        for line in cmw_status:
            if (line.startswith("safSu=") or line.startswith("safSg=")) and not ("MMAS" in line and "oam" in line):
                return True
        return False

    def check_cmw_status_node_su_sg(self, p_retry=9, p_sleep=5):
        logger.debug("Waiting for cmw-status node su sg to become OK")
        l_retry = 0
        return_ok = False
        while not return_ok:
            l_retry += 1
            if l_retry > p_retry:
                logger.debug("cmw-status node su sg was NOT OK")
                print (" cmw-status node su sg was NOT OK yet  |")
                sys.exit(REPEAT)
            logger.debug("l_retry: " + str(l_retry))
            try:
                stdout, stderr, retcode = self.ssh.run_command("cmw-status node su sg", fail_at_error=False)
            except:
                logger.debug("cmw-status node su sg was NOT OK yet  |")
                print (" cmw-status node su sg was NOT OK yet  |")
                sys.exit(REPEAT)
            lines = stdout.split("\n")
            if lines[0] == "Status OK":
                return_ok = True
                logger.debug("cmw-status node su sg IS OK")
                #print(" cmw-status node su sg IS OK  |")
                continue
            else:
                # additional check due to locked MMAS OAM
                if (not ("safSu=" in stdout or "safSg=" in stdout) or
                        self.check_cmw_status_fails_beside_locked_mmas_oam(lines)):
                    logger.debug(" CMW SU check sleeping  |")
                    time.sleep(p_sleep)
                    continue
                else:
                    return_ok = True
                    logger.debug("cmw-status node su sg IS OK")
                    #print(" cmw-status node su sg IS OK  |")

    def is_esm(self):
        stdout, stderr, retcode = self.ssh.run_command("test -e /cluster/storage/system/config/lde/csm/finalized/csm.yml", fail_at_error=False)
        return (retcode == 0)

    def read_esm_timer_file(self):
        stdout, stderr, retcode = self.ssh.run_command("cat /cluster/home/vnflcm/post_install_esm_time", fail_at_error=False)
        if retcode == 0:
            self.esm_time = float(stdout.strip('\n'))
        else:
            self.esm_time = time.time()

    def update_esm_timer_file(self):
        stdout, stderr, retcode = self.ssh.run_command("test -e /cluster/home/vnflcm/post_install_esm_time", fail_at_error=False)
        if retcode == 0:
            logger.debug("ESM timer file already exist")
            #print("ESM timer file already exist |")
            return False
        else:
            self.esm_time = time.time()
            cmd = "echo " + str(self.esm_time) + " > /cluster/home/vnflcm/post_install_esm_time"
            self.ssh.run_command(cmd, fail_at_error=False)
            return True

    def check_esm_image(self):
        if self.perform_config_step("ESM"):
            return
        logger.debug("Checking for ESM image.")
        # print("Checking for ESM image.")
        if not self.is_esm():
            logger.debug("Not ESM image.")
            # print("Not ESM image.")
        else:
            logger.debug("Checking ESM installation status.")
            #print("Checking ESM installation status |")
            self.update_esm_timer_file()
            self.check_esm_image_status()
        self.update_state_file("ESM")

    def check_esm_image_status(self):
        stdout, stderr, retcode = self.ssh.run_command("grep \"Offline Instantiation was successful\" /var/log/messages", fail_at_error=False)
        if retcode != 0:
            self.read_esm_timer_file()
            if(time.time() - self.esm_time >= 1200):    # 20 minutes timeout
                logger.debug("ESM installation status timeout. Exiting Installation...")
                print("ESM installation status timeout. Exiting Installation...")
                self.rm_file("/cluster/home/vnflcm/post_install_esm_time")
                sys.exit(RETURN_ERROR)
            else:
                print(" ESM installation ongoing be patient  |")
                logger.debug(" ESM installation ongoing be patient  |")
                sys.exit(REPEAT)
        else:
            logger.debug("ESM installation successful")
            print("ESM installation successful |")
            self.rm_file("/cluster/home/vnflcm/post_install_esm_time")



    def check_hw_clock(self):
        if self.perform_config_step("RTC"):
            return
        logger.debug("Verifying HW clock behavior")
        print(" Verifying HW clock behavior  |")
        for i in range(1,3):
            if self.run_command_match_string(
                    "hwclock --test --show --debug","synchronization failed") and\
                    self.run_command_match_string(
                        "hwclock --test --show --debug", "synchronization failed"):

                logger.debug("Applying RTC patch")
                self.ssh.run_command(
                    "immcfg -a value=enabled MtasParameter=TimerPatch,MtasInt=1,MtasSite=1", fail_at_error=False)

                self.update_state_file("RTC")
                logger.debug("Apply RTC patch done, exit with REPEAT")
                print(" Apply RTC patch done  |")
                sys.exit(REPEAT)

        self.update_state_file("RTC")
        logger.debug("HW clock behavior appropriate")
        print(" HW clock behavior appropriate  |")

    def prepare_hostname_cmd(self):
        """ Insert hostnames to cluster.conf after timezone """
        command = ('sed -i \'/^timezone/a \\'
                       '\n \\'
                       '\n#  ----------- \\'
                       '\n# | HOSTNAMES | \\'
                       '\n#  -----------  \\')

        if self.input_data.platform_vip != "none":
            command += "\nhost all %s platform-vip\\" % self.input_data.platform_vip
        if self.input_data.platform_vip6 != "none":
            command += "\nhost all %s platform-vip6\\" % self.input_data.platform_vip6

        if self.input_data.tasvip4 != "none":
            command += "\nhost all %s tasvip4\\" % self.input_data.tasvip4
        if self.input_data.tasvip6 != "none":
            command += "\nhost all %s tasvip6\\" % self.input_data.tasvip6

        if self.input_data.ut_vip4 != "none":
            command += "\nhost all %s ut-vip4\\" % self.input_data.ut_vip4
        if self.input_data.ut_vip6 != "none":
            command += "\nhost all %s ut-vip6\\" % self.input_data.ut_vip6

        if self.input_data.cai3g_vip4 != "none":
            command += "\nhost all %s cai3g-vip4\\" % self.input_data.cai3g_vip4
        if self.input_data.cai3g_vip6 != "none":
            command += "\nhost all %s cai3g-vip6\\" % self.input_data.cai3g_vip6

        if self.input_data.sigtran1_vip4 != "none":
            command += "\nhost all %s sigtran1-vip4\\" % self.input_data.sigtran1_vip4
        if self.input_data.sigtran1_vip6 != "none":
            command += "\nhost all %s sigtran1-vip6\\" % self.input_data.sigtran1_vip6

        if self.input_data.sigtran2_vip4 != "none":
            command += "\nhost all %s sigtran2-vip4\\" % self.input_data.sigtran2_vip4
        if self.input_data.sigtran2_vip6 != "none":
            command += "\nhost all %s sigtran2-vip6\\" % self.input_data.sigtran2_vip6

        command += "\n\'"

        command = command + " /cluster/etc/cluster.conf"
        return command

    def update_cluster_conf(self):
        commands = []
        commands.append(self.prepare_hostname_cmd())

        """Add other cluster.conf customization here,
        for instance eth4 support.Make sure MACs added to output section of main HOT.
        """
        logger.debug("update_cluster_conf with hostname: " + str(commands))
        for command in commands:
            try:
                self.cp_file("/cluster/etc/cluster.conf", "/cluster/etc/cluster.conf.orig")
                self.ssh.run_command(command)
            except:
                logger.error("Something went wrong with cluster.conf update. HINT: check documentation!")
                print (" Something went wrong with cluster.conf update. HINT: check documentation!  |")
                self.mv_file("/cluster/etc/cluster.conf.orig", "/cluster/etc/cluster.conf")
                sys.exit(RETURN_ERROR)

    def reload_and_apply_cluster_conf_all(self):
        logger.debug("Reload/apply cluster config")
        self.cp_file("/cluster/etc/cluster.conf", "/boot/.cluster.conf")
        try:
             self.ssh.run_command("cluster config -r")
             self.ssh.run_command("cluster reboot -a > /dev/null 2>&1 &")
        except:
            logger.error("Apply cluster configuration is not done. Reloading the node failed")
            print(" Reload/apply cluster config failed  |")
            self.ssh.run_command("sed -i -e '/LDE/d' /cluster/home/vnflcm/post_install_wf_state", fail_at_error=False)
            sys.exit(RETURN_ERROR)

        logger.debug("Reloading/apply cluster config done")
        print(" Reloading/apply cluster config done  |")
        time.sleep(30)
        return True

    def validate_cluster_conf(self):
        logger.debug("Validate cluster config")

        stdout, stderr, retcode = self.ssh.run_command("cluster config -v", fail_at_error=False)
        if retcode != 0:
            logger.error("Validate cluster config failed: " + str(stderr))
            print("Validate cluster config failed: " + str(stderr))
            self.mv_file("/cluster/etc/cluster.conf.org", "/cluster/etc/cluster.conf")
            sys.exit(RETURN_ERROR)
        else:
            logger.debug("Validate cluster config done")
            self.rm_file("/cluster/etc/cluster.conf.org")
            return True

    def manage_xdms_key_store(self):
        logger.debug("manage_xdms_key_store")
        try:
            self.ssh.run_command(
                "echo 'emergency ALL=(root) NOPASSWD:/usr/java/latest/bin/keytool'> /etc/sudoers.d/mtas-xdms-keytool")
        except:
            logger.error("Enable emergency user to manage MTAS XDMS key-store failed")
            logger.error(stderr)
            return False
        try:
            # Check where the file was created in previous step
            self.ssh.run_command(
                "scp /etc/sudoers.d/mtas-xdms-keytool sc-2:/etc/sudoers.d/mtas-xdms-keytool")
        except:
            logger.error("Failed to copy file mtas-xdms-keytool to sc-2:/etc/sudoers.d/mtas-xdms-keytool")
            logger.error(stderr)
            return False
        try:
            self.ssh.run_command("scp /etc/sudoers.d/mtas-xdms-keytool sc-1:/etc/sudoers.d/mtas-xdms-keytool")
        except:
            logger.error("Failed to copy file mtas-xdms-keytool to sc-1:/etc/sudoers.d/mtas-xdms-keytool")
            logger.error(stderr)
            return False
        return True


    def cluster_delta_configure(self):
        if self.perform_config_step("LDE"):
            return
        logger.debug("Apply cluster delta configuration")
        print(" Apply cluster delta configuration  |")

        self.cp_file("/cluster/etc/cluster.conf", "/cluster/etc/cluster.conf.org")
        print("Updating cluster.conf\n")
        self.update_cluster_conf()
        print("Validating cluster.conf\n")
        self.validate_cluster_conf()
        print("Updating state file\n")
        self.update_state_file("LDE")
        print("Do reboot\n")
        self.reload_and_apply_cluster_conf_all()

        logger.debug("Apply cluster delta configuration done, exit with REPEAT")
        print(" Apply cluster delta configuration done. |")
        sys.exit(REPEAT)

    def config_emergency_user_account(self):
        logger.debug("config_emergency_user_account")
        stdout, stderr, retcode = self.ssh.run_command(
            "useradd -G com-emergency " + self.input_data.emergency_username, fail_at_error=False)
        if retcode == 9 or retcode == 0:
            if retcode == 9:
                logger.debug("User already exists")
            stdout, stderr, retcode = self.ssh.run_command(
                "lde-global-user -u " + self.input_data.emergency_username, fail_at_error=False)
            # same error code is returned for all errors...syntax or user already added...so we skip it and assume that it is still ok?
            # if (retcode not 0):
            #    logger.error("Adding emergency user failed")
            #    return False
            try:
                stdout, stderr, retcode = self.ssh.run_command(
                    "usermod -p '" + self.input_data.emergency_password_hash + "' " + self.input_data.emergency_username)
            except:
                logger.error("Adding emergency user failed")
                logger.error(stderr)
                print(" Adding emergency user failed  |")
                sys.exit(RETURN_ERROR)
        else:
            logger.error("Adding emergency user failed")
            logger.error(stderr)
            print(" Adding emergency user failed  |")
            sys.exit(RETURN_ERROR)

    def enable_user_access(self, username):
        stdout, stderr, retcode = self.ssh.run_command(
            "grep " + username + " /cluster/etc/login.allow", fail_at_error=False)
        if (retcode == 1):
            stdout, stderr, retcode = self.ssh.run_command(
                "echo \"" + username + " all\" >> /cluster/etc/login.allow")
            if (retcode != 0):
                logger.error("Adding %s user failed", user_name)
                logger.error(stderr)
                print(" Adding %s user failed  |", user_name)
                sys.exit(RETURN_ERROR)
        return True

    def add_emergency_user(self):
        logger.debug("Adding emergency user")
        print(" Adding emergency user  |")

        self.config_emergency_user_account()
        self.enable_user_access(self.input_data.emergency_username)
        if not self.manage_xdms_key_store():
            logger.error("Emergency user not added successfully")
            print(" Emergency user not added successfully  |")
            sys.exit(RETURN_ERROR)

        logger.debug("Emergency user added successfully")
        print(" Emergency user added successfully  |")

    def restart_com(self):
        isesm = self.is_esm()
        logger.debug("Restarting COM")
        activeSCindex = "2"
        standbySCindex = "1"

        cond1 = (    isesm and self.run_command_match_string("amf-state csiass | grep -A 2 -i Com   | grep -A 1 -F 'com-sshd-manager\,safSu=SC-1' | grep saAmfCSICompHAState=ACTIVE", "saAmfCSICompHAState=ACTIVE(1)"))
        cond2 = (not isesm and self.run_command_match_string("amf-state csiass | grep -A 2 -i ComSa | grep -A 1 -F 'ERIC-ComSa-sshd\,safSu=Cmw1'  | grep saAmfCSICompHAState=ACTIVE", "saAmfCSICompHAState=ACTIVE(1)"))

        if cond1 or cond2:
            activeSCindex = "1"
            standbySCindex = "2"

        try:
            if isesm:
               self.ssh.run_command("amf-adm lock safSu=SC-" + standbySCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm lock-in safSu=SC-" + standbySCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm lock safSu=SC-" + activeSCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm lock-in safSu=SC-" + activeSCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm unlock-in safSu=SC-" + activeSCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm unlock safSu=SC-" + activeSCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm unlock-in safSu=SC-" + standbySCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")
               self.ssh.run_command("amf-adm unlock safSu=SC-" + standbySCindex + ",safSg=2N,safApp=ERIC-com.oam.access.aggregation")

            else:
               self.ssh.run_command("amf-adm lock safSu=Cmw" + standbySCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm lock-in safSu=Cmw" + standbySCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm lock safSu=Cmw" + activeSCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm lock-in safSu=Cmw" + activeSCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm unlock-in safSu=Cmw" + activeSCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm unlock safSu=Cmw" + activeSCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm unlock-in safSu=Cmw" + standbySCindex + ",safSg=2N,safApp=ERIC-ComSa")
               self.ssh.run_command("amf-adm unlock safSu=Cmw" + standbySCindex + ",safSg=2N,safApp=ERIC-ComSa")

        except:
            logger.error("Restarting COM failed!")
            return False

        logger.debug("Restarting COM done")
        return True

    def enable_com_sshd_manager(self):
        logger.debug("Enabling COM ssh manager")
        self.ssh.run_command(
            "sed -i -e 's/<cliPort>22<\/cliPort>/<cliPort>2022<\/cliPort>/g'"
            " /cluster/storage/system/config/com-apr9010443/lib/comp/libcom_sshd_manager.cfg",
            fail_at_error=False)
        self.ssh.run_command(
            "sed -i -e 's/<sshdManagement>false<\/sshdManagement>/<sshdManagement>true<\/sshdManagement>/g'"
            " /cluster/storage/system/config/com-apr9010443/lib/comp/libcom_sshd_manager.cfg",
            fail_at_error=False)
        #self.restart_com()
        logger.debug("Enabling COM ssh manager done")
        return True

    def secla_psw_change(self):
        for sc in ['sc-1','sc-2']:
            try:
                # this needs to be done on a specific SC, which may, or may not, be the active SC...
                stdout, stderr, retcode = self.ssh.run_command("ssh "+sc+" ps -ef | grep slapd | fgrep -v grep", fail_at_error=False)
                if retcode == 0:
                    stdout, stderr, retcode = self.ssh.run_command(
                        "ssh "+sc+" /opt/eric/sec-la-cxp9026994/bin/sec-la-passwd la-admin -h '" + self.input_data.secla_password_hash + "'")
                    if retcode == 0:
                        print(" SEC-LA password change succeeded. |")
                        return True

                    else:
                        print(" SEC-LA command failed on "+sc)

            except:
                continue

        logger.error("Changing password failed.")
        print(" SEC-LA password change failed. |")
        sys.exit(RETURN_ERROR)

    def change_secla_password(self):
        logger.debug("Change default SEC-LA password")
        print(" Change default SEC-LA password  |")

        self.enable_com_sshd_manager()
        self.secla_psw_change()

        logger.debug("SEC-LA password changed")
        print(" SEC-LA password changed  |")

    def add_vnflcm_key(self):
        logger.debug("Add VNF-LCM's key to emergency user")
        print(" Add VNF-LCM's key to emergency user  |")

        key_file = self.input_data.config_dir + "/id_rsa.pub"

        try:
            self.ssh.send_file(key_file, "/tmp/id_rsa.pub")
            self.ssh.run_command("su - " + self.input_data.emergency_username + " -c 'mkdir -p .ssh'")
            self.ssh.run_command("su - " + self.input_data.emergency_username + " -c 'cat /tmp/id_rsa.pub >> .ssh/authorized_keys'")
            self.ssh.run_command("rm -f /tmp/id_rsa.pub")
        except:
            logger.error("Add VNF-LCM's key to emergency user failed")
            print(" Add VNF-LCM's key to emergency user failed  |")
            sys.exit(RETURN_ERROR)

        logger.debug("Add VNF-LCM's key to emergency user done")
        print(" Add VNF-LCM's key to emergency user done  |")

    def change_root_password(self):
        logger.debug("Changing root password")
        print(" Changing root password  |")

        try:
            self.ssh.run_command(
                "usermod -p '" + self.input_data.root_password_hash + "' root; cluster config -r -a")
        except:
            logger.error("Changing root password failed")
            print(" Changing root password failed  |")
            sys.exit(RETURN_ERROR)

        logger.debug("root password changed")
        print(" root password changed  |")

    def disable_root_login(self):
        logger.debug("Disabling root login")
        print(" Disabling root login  |")

        stdout, stderr, retcode = self.ssh.run_command(
            "grep \"^ssh.rootlogin all off\" /cluster/etc/cluster.conf", fail_at_error=False)
        if (retcode != 0):
            stdout, stderr, retcode = self.ssh.run_command(
                "sed -i -e '0,/^# ssh listening networks/s/# ssh listening networks/# "
                "ssh root login\\nssh.rootlogin all off\\n\\n&/' /cluster/etc/cluster.conf",
                fail_at_error=False)
            if (retcode != 0):
                logger.error("Updating cluster.conf failed")
                logger.error(stderr)
                print(" Updating cluster.conf failed  |")
                sys.exit(RETURN_ERROR)
        else:
            logger.debug("cluster.conf already updated with ssh.rootlogin all off")

        logger.debug("Disabling root login done")
        print(" Disabling root login done  |")

    def com_switchover(self):
        stdout, stderr, retcode = self.ssh.run_command("comsa-mim-tool com_switchover", fail_at_error=False)
        if not (retcode == 0 or retcode == 1):
            logger.error("Prepare SFTP connection failed, because comsa-mim-tool com_switchover")
            logger.error(stderr)
            return False
        return True

    def prepare_sftp_connection(self):
        logger.debug("Prepare SFTP connection")
        print(" Prepare SFTP connection  |")

        stdout, stderr, retcode = self.ssh.run_command("groupadd sftpusers", fail_at_error=False)
        if (retcode == 9 or retcode == 0):
            if (retcode == 9):
                logger.debug("SFTP Group already exists")

        stdout, stderr, retcode = self.ssh.run_command("useradd -m -G sftpusers oss_pm ", fail_at_error=False)
        if (retcode == 9 or retcode == 0):
            if (retcode == 9):
                logger.debug("User already exists")

            self.ssh.run_command("lde-global-user -g sftpusers", fail_at_error=False)
            self.ssh.run_command("lde-global-user -u oss_pm", fail_at_error=False)

            try:
                self.ssh.run_command(
                "usermod -p '" + self.input_data.oss_pm_password_hash + "' oss_pm")

            except:
                logger.error("Adding oss_pm/SFTP user failed")
                print(" Adding oss_pm/SFTP user failed  |")
                return False
            self.enable_user_access("oss_pm")

        else:
            logger.error("Adding SFTP group, oss_user user failed")
            print(" Adding oss_pm/SFTP user failed  |")
            return False

        stdout, stderr, retcode = self.ssh.run_command(
            "grep sftpusers /cluster/storage/system/config/mtas/sshd_config_sftp_filem", fail_at_error=False)
        if (retcode == 1 or retcode == 2):
            self.cp_file(
                "/cluster/storage/system/config/mtas/sshd_config_sftp_filem.template",
                "/cluster/storage/system/config/mtas/sshd_config_sftp_filem")
            self.ssh.run_command(
                "sed -i -e 's/<GROUP ID HERE>/sftpusers/g' "
                "/cluster/storage/system/config/mtas/sshd_config_sftp_filem",
                fail_at_error=False)
#            if not self.com_switchover():
            if not self.restart_com():
                print(" Prepare SFTP connection failed |")
                return False

        logger.debug("Prepare SFTP connection done")
        print(" Prepare SFTP connection done  |")

    def run_com_cli_command(self, command, configure_mode=True):
        import string
        printable = set(string.printable)
        cmd = filter(lambda x: x in printable, command)
        if configure_mode:
            cmmnd = "(echo 'scriptmode --on\nconfigure\n" + cmd + "\nend\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        else:
            cmmnd = "(echo 'scriptmode --on\n" + cmd + "\nexit\n'; sleep 1) | /opt/com/bin/cliss"
        stdout, stderr, retcode = self.ssh.run_command(cmmnd, fail_at_error=False)
        return stdout, stderr, retcode

    def run_command_match_string(self, p_command, p_match):
        stdout, stderr, retcode = self.ssh.run_command(p_command, fail_at_error=False)
        if p_match in stdout:
            logger.debug("Run command match string: " + p_match + " string is matched in std out")
            return True
        logger.debug("Run command match string: " + p_match + " string is NOT matched in std out")
        return False

    def check_evip_alb_on_com_nbi(self, alb_name, retry=20, sleep=5):
        logger.debug("Check eVIP " + alb_name + " alb on COM NBI")
        l_retry = 0
        while True:
            l_retry += 1
            logger.debug("l_retry: " + str(l_retry))
            command = "show ManagedElement=1,Transport=1,Evip=1,EvipAlbs=1,EvipAlb=" + alb_name + ",state"
            stdout, stderr, retcode = self.run_com_cli_command(command, configure_mode=False)
            if retcode == 0:
                for line in stdout.split("\n"):
                    if "state=" in line:
                        state = line.split("=")[1].replace('\"', '')
                        logger.debug(alb_name + " state: " + str(state))
                        if state != "ACTIVE":
                            if l_retry == retry:
                                logger.error("Timer expired: " + alb_name + " alb state is: " + str(state))
                                logger.error("eVIP verification failed. HINT: check documentation! ")
                                print(" eVIP verification failed. HINT: check documentation!  |")
                                sys.exit(RETURN_ERROR)
                            time.sleep(sleep)
                        else:
                            logger.debug("eVIP " + alb_name + " alb is OK on COM NBI")
                            print(" eVIP " + alb_name + " alb is OK on COM NBI  |")
                            return True
            else:
                logger.error("eVIP verification failed. HINT: check documentation!")
                print(" eVIP verification failed. HINT: check documentation!  |")
                sys.exit(RETURN_ERROR)

    def prepare_evip_cmd(self):
        command = ""
        try:
            with open(self.evip_cli, 'r') as f:
                for line in f:
                    command += line
                return command
        except:
            logger.debug("eVIP delta config file ./evip_cli.txt cannot be found, skipping eVIP delta configuration")
            print(" eVIP delta config file ./evip_cli.txt cannot be found, skipping eVIP delta configuration  |")
            self.update_state_file("eVIP")
            return command

    def evip_delta_configure(self):
        if self.perform_config_step("eVIP"):
            return
        logger.debug("Apply eVIP delta configuration")
        print(" Apply eVIP delta configuration  |")

        self.evip_cli = self.input_data.config_dir + "/evip_cli.txt"
        command = self.prepare_evip_cmd()
        if command == "":
            logger.debug("Skipping eVIP delta configuration")
            print(" skipping eVIP delta configuration  |")
            return True

        logger.debug("Executing eVIP CLI commands")
        print(" Executing eVIP CLI commands  |")
        self.run_com_cli_command(command)

        # Verifying evip configuration, please add new ALB to the list if needed
        for alb in ["mtas_om", "mtas_sig"]:
            self.check_evip_alb_on_com_nbi(alb)

        self.update_state_file("eVIP")
        logger.debug("Apply eVIP delta configuration done")
        print(" Apply eVIP delta configuration done  |")
        sys.exit(REPEAT)

    def ss7_delta_configure(self, ipversion="ipv4ipv6"):
        if self.perform_config_step("SS7"):
            return
        logger.debug("Apply SS7 delta configuration")
        print(" Apply SS7 delta configuration  |")

        self.ss7_cli = self.input_data.config_dir + "ss7.conf"
        command = "export PATH=$PATH:/opt/sign/EABss7069/jre/bin; echo \'expert: mode=on; confmode: mode=\"reconf\";"
        try:
            with open(self.ss7_cli, 'r') as f:
                for line in f:
                    command += line.replace('\n', '')
        except:
            print (" SS7 delta config file ./ss7.conf cannot be found, skipping SS7 delta config  |")
            logger.debug("SS7 delta config file ./ss7.conf cannot be found, skipping SS7 delta config")
            self.update_state_file("SS7")
            return True

        command += "configure:INITIAL; exit;\' | timeout 60 /opt/sign/EABss7050/bin/signmcli -own.conf /storage/system/config/ss7caf-ana90137/etc/signmgr.cnf -online yes"
        stdout, stderr, retcode = self.ssh.run_command(command, fail_at_error=False)
        if retcode != 0:
            logger.debug("Apply SS7 delta configuration Failed. " + stderr)
            print(" Apply SS7 delta configuration Failed.  |" + stderr)
            sys.exit(RETURN_ERROR)
        self.ssh.run_command("mkdir -p /cluster/storage/system/config/ss7caf-ana90137/etc/sctp/", fail_at_error=False)
        self.ssh.run_command(
            "cp -f /cluster/storage/system/config/ss7caf-ana90137/etc/* "
            "/cluster/storage/system/config/ss7caf-ana90137/etc/sctp/", fail_at_error=False)

        self.update_state_file("SS7")
        logger.debug("Apply SS7 delta configuration done")
        print(" Apply SS7 delta configuration done  |")
        sys.exit(REPEAT)

    def cai3g_max_sessions_cofigure(self):
        if self.perform_config_step("CAI3G"):
            return
        logger.debug("Configuring CAI3G Maximum Sessions value")
        print(" Configuring CAI3G Maximum Sessions value  |")
        if self.input_data.cai3g_vip4 != "none" or self.input_data.cai3g_vip6 != "none":
           try:
               stdout, stderr, retcode = self.ssh.run_command("cat /proc/cpuinfo | grep \'processor\' | wc -l")
           except:
               logger.debug("CAI3G Maximum Sessions vlalue configuration failed!")
               print(" CAI3G Maximum Sessions value configuraion failed!  |")
               sys.exit(RETURN_ERROR)

           command = ""
           command += "ManagedElement=1,MtasFunction=MtasFunction,MtasXdms=0,mtasXdmsCai3gMaximumSessions=" + str(
               (int(stdout) * 16))
           command += "\ncommit"
           self.run_com_cli_command(command)

        self.update_state_file("CAI3G")
        logger.debug("CAI3G Maximum Sessions value is configured, exit with REPEAT")
        print(" CAI3G Maximum Sessions value is configured  |")
        sys.exit(REPEAT)

    def managedElement_update(self, value):
        if self.perform_config_step("ManagedElement_update"):
            return
        logger.debug("updating ManagedElement value to " + value)
        print("updating ManagedElement value to " + value + " |")
        cmdStr = "ManagedElement=1,networkManagedElementId=" + value
        cmdStr += "\ncommit"
        self.run_com_cli_command(cmdStr)
        self.update_state_file("ManagedElement_update")
        logger.debug("ManagedElement value updated to " + value)
        print("ManagedElement value updated to " + value + " |")

    def enable_scaling(self):
        if self.perform_config_step("ENABLED_SCALING"):
            return
        logger.debug("Enabling scaling")
        print(" Enabling scaling  |")

        try:
            self.ssh.run_command("cmw-configuration --enable SCALING")
        except Exception, e:
            logger.error("Failed to enable scaling")
            print(" Failed to enable scaling  |" + str(e))
            return False 
        self.update_state_file("ENABLED_SCALING")
        logger.debug("Enabling scaling done")
        print(" Enabling scaling done  |")

    def apply_pdb(self):
        if self.perform_config_step("PDB"):
            return True
        pdb_files = subprocess.Popen(['find', self.input_data.config_dir, '-iname', '*.zip' ],stdout=subprocess.PIPE).communicate()[0].strip()
        pdb_file=pdb_files.split("\n")[0].strip()
        if  pdb_file !="":
            logger.debug("Apply application configuration")
            print(" Apply application configuration  |")
            pdbexec = PdbConfigExecutor.PdbConfigExecutor(['-f',pdb_file])
            rtnCode = pdbexec.execute()
            if rtnCode == 0:
                self.update_state_file("PDB")
                logger.debug("Application configuration is done, exit with REPEAT")
                print(" Application configuration is done  |")
                sys.exit(REPEAT)
            else:
                pdblogdir = os.getcwd()
                pdb_log = subprocess.Popen(['find', pdblogdir, '-iname', 'out.*' ],stdout=subprocess.PIPE).communicate()[0].strip()
                logger.debug("Application configuration with pdb failed!")
                print(" Application configuration failed!  |")
                print(" Check PDB log file: " + pdb_log + "  |")
                sys.exit(RETURN_ERROR)
        else:
            self.update_state_file("PDB")
            logger.debug("No PDB file found skipping application configuration, exit with REPEAT")
            print(" No PDB file found skipping application configuration  |")
            sys.exit(REPEAT)

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(description='post_instance hook for workflow')
        parser.add_argument('-f', '--vnf-instance-details-file', metavar='<FILE>',
                            help='Path to the file containing the response of stack show details command in json format.',
                            type=str, required=True)
        parser.add_argument('-c', '--config-dir', metavar='<CONFIG_DIR>',
                            help='Configuration directory', type=str, required=True)
        parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                            help='Path to the file containing the private key for login', type=str, required=False)
        parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                            help='Username to login into the VNF instance', type=str, required=False)
        parser.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                            help='Path to the file containing the password to login into \
                            the VNF instance.', type=str, required=False)

        args = parser.parse_args()

        logger = logging.getLogger('vMtasLcmPostInstantiation.argparsing')
        logger.debug("vnf_file = " + args.vnf_instance_details_file)

        if args.vnf_instance_details_file.endswith('.xml'):
            return PostInstantiation.parseVCDXmlFile(args)
        else:
            return PostInstantiation.parseOpenStackJsonFile(args)

    @staticmethod
    def parseOpenStackJsonFile(args):
	global logger
        with open(args.vnf_instance_details_file) as json_file:
            jsonfile = json.load(json_file)
        config_dir = args.config_dir

        logger = logging.getLogger('vMtasLcmPostInstantiation.' + jsonfile["stack"]["stack_name"])
        logger.debug("Parsing Openstack JSON file...")
        logger.debug('json file [%s] loaded', args.vnf_instance_details_file)
        logger.debug('Config dir [%s] loaded', config_dir)
        key_file = args.key_file
        mip = None

        if jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip() == "none":
            mip = jsonfile["stack"]["parameters"]["OM_IPv6_address"].strip()
        else:
            mip = jsonfile["stack"]["parameters"]["OM_IPv4_address"].strip()

        if jsonfile["stack"]["parameters"]["SC-1_IPv4_address"].strip() == "none":
            sc1_ip = jsonfile["stack"]["parameters"]["SC-1_IPv6_address"].strip()
        else:
            sc1_ip = jsonfile["stack"]["parameters"]["SC-1_IPv4_address"].strip()

        if jsonfile["stack"]["parameters"]["SC-2_IPv4_address"].strip() == "none":
            sc2_ip = jsonfile["stack"]["parameters"]["SC-2_IPv6_address"].strip()
        else:
            sc2_ip = jsonfile["stack"]["parameters"]["SC-2_IPv4_address"].strip()

        platform_vip = jsonfile["stack"]["parameters"]["platform-vip"].strip()
        platform_vip6 = jsonfile["stack"]["parameters"]["platform-vip6"].strip()
        tasvip4 = jsonfile["stack"]["parameters"]["tasvip4"].strip()
        tasvip6 = jsonfile["stack"]["parameters"]["tasvip6"].strip()
        ut_vip4 = jsonfile["stack"]["parameters"]["ut-vip4"].strip()
        ut_vip6 = jsonfile["stack"]["parameters"]["ut-vip6"].strip()
        cai3g_vip4 = jsonfile["stack"]["parameters"]["cai3g-vip4"].strip()
        cai3g_vip6 = jsonfile["stack"]["parameters"]["cai3g-vip6"].strip()
        sigtran1_vip4 = jsonfile["stack"]["parameters"]["sigtran1-vip4"].strip()
        sigtran1_vip6 = jsonfile["stack"]["parameters"]["sigtran1-vip6"].strip()
        sigtran2_vip4 = jsonfile["stack"]["parameters"]["sigtran2-vip4"].strip()
        sigtran2_vip6 = jsonfile["stack"]["parameters"]["sigtran2-vip6"].strip()
        emergency_username = jsonfile["stack"]["parameters"]["emergency_username"].strip()
        emergency_password_hash = jsonfile["stack"]["parameters"]["emergency_password_hash"].strip()
        secla_password_hash = jsonfile["stack"]["parameters"]["secla_password_hash"].strip()
        root_password_hash = jsonfile["stack"]["parameters"]["root_password_hash"].strip()
        oss_pm_password_hash = jsonfile["stack"]["parameters"]["oss_pm_password_hash"].strip()
        stack_name = jsonfile["stack"]["stack_name"]
        stack_outputs = jsonfile["stack"]["outputs"]

        logger.debug("The parameters parsed from json are: %s" %
                    ((mip, args.config_dir, key_file, sc1_ip, sc2_ip, platform_vip, platform_vip6, tasvip4, tasvip6, ut_vip4,
                      ut_vip6, cai3g_vip4, cai3g_vip6, sigtran1_vip4, sigtran1_vip6,
                      sigtran2_vip4, sigtran2_vip6, emergency_username,
                      emergency_password_hash, secla_password_hash,
                      root_password_hash, oss_pm_password_hash, stack_name),))

        return PostInstantiation.InputData(mip, config_dir, key_file, sc1_ip, sc2_ip, platform_vip, platform_vip6, tasvip4,
                                           tasvip6, ut_vip4, ut_vip6, cai3g_vip4,
                                           cai3g_vip6, sigtran1_vip4, sigtran1_vip6,
                                           sigtran2_vip4, sigtran2_vip6, emergency_username,
                                           emergency_password_hash, secla_password_hash,
                                           root_password_hash, oss_pm_password_hash, stack_name)


    @staticmethod
    def parseVCDXmlFile(args):
       global logger
       vcdParser = VCDXmlParser(args.vnf_instance_details_file)
       vApp = vcdParser.vnf_status_file
       vAppName = vApp.attrib.get("name")
       if vAppName == None:
           sys.exit(ERROR)

       logger = logging.getLogger('vMtasLcmPostInstantiation.' + vAppName)
       logger.debug("Parsing VCD XML file...")

       logger.debug('VCD xml file [%s] loaded', args.vnf_instance_details_file)

       mip = None
       vnf_file = os.path.basename(args.vnf_instance_details_file)

       id = vnf_file.split('.')[0]
       emergency_user = vcdParser.get_property('emergency_username')
       OM_IPv4_address = vcdParser.get_property('OM_IPv4_address').strip()
       if OM_IPv4_address == "none":
           mip = vcdParser.get_property('OM_IPv6_address').strip()
       else:
           mip = OM_IPv4_address

       if vcdParser.get_property('SC-1_IPv4_address').strip() == "none":
           sc1_ip = vcdParser.get_property('SC-1_IPv6_address').strip()
       else:
           sc1_ip = vcdParser.get_property('SC-1_IPv4_address').strip()

       if vcdParser.get_property('SC-2_IPv4_address').strip() == "none":
           sc2_ip = vcdParser.get_property('SC-2_IPv6_address').strip()
       else:
           sc2_ip = vcdParser.get_property('SC-2_IPv4_address').strip()

       platform_vip = vcdParser.get_property("platform-vip").strip()
       platform_vip6 = vcdParser.get_property("platform-vip6").strip()
       tasvip4 = vcdParser.get_property("tasvip4").strip()
       tasvip6 = vcdParser.get_property("tasvip6").strip()
       ut_vip4 = vcdParser.get_property("ut-vip4").strip()
       ut_vip6 = vcdParser.get_property("ut-vip6").strip()
       cai3g_vip4 = vcdParser.get_property("cai3g-vip4").strip()
       cai3g_vip6 = vcdParser.get_property("cai3g-vip6").strip()
       sigtran1_vip4 = vcdParser.get_property("sigtran1-vip4").strip()
       sigtran1_vip6 = vcdParser.get_property("sigtran1-vip6").strip()
       sigtran2_vip4 = vcdParser.get_property("sigtran2-vip4").strip()
       sigtran2_vip6 = vcdParser.get_property("sigtran2-vip6").strip()
       emergency_username = vcdParser.get_property("emergency_username").strip()
       emergency_password_hash = vcdParser.get_property("emergency_password_hash").strip()
       secla_password_hash = vcdParser.get_property("secla_password_hash").strip()
       root_password_hash = vcdParser.get_property("root_password_hash").strip()
       oss_pm_password_hash = vcdParser.get_property("oss_pm_password_hash").strip()
       stack_name = ""# vcdParser.get_property("stack_name")
       stack_outputs = ""# vcdParser.get_property("outputs")
       key_file = args.key_file

       logger.debug("The parameters parsed from json are: %s" %
                    ((mip, args.config_dir, key_file, sc1_ip, sc2_ip, platform_vip, platform_vip6, tasvip4, tasvip6, ut_vip4,
                      ut_vip6, cai3g_vip4, cai3g_vip6, sigtran1_vip4, sigtran1_vip6,
                      sigtran2_vip4, sigtran2_vip6, emergency_username,
                      emergency_password_hash, secla_password_hash,
                      root_password_hash, oss_pm_password_hash, stack_name),))

       return PostInstantiation.InputData(mip, args.config_dir, key_file, sc1_ip, sc2_ip, platform_vip, platform_vip6, tasvip4,
                                           tasvip6, ut_vip4, ut_vip6, cai3g_vip4,
                                           cai3g_vip6, sigtran1_vip4, sigtran1_vip6,
                                           sigtran2_vip4, sigtran2_vip6, emergency_username,
                                           emergency_password_hash, secla_password_hash,
                                           root_password_hash, oss_pm_password_hash, stack_name)

def main():
#    with open("/tmp/workflows_test/"+os.path.basename(__file__), "w+") as f:
#        f.write('** Command Line **\n"'+'" "'.join(sys.argv)+'"\n\n')
#        f.write("** Environment **\n")
#        for a in os.environ.keys():
#            f.write(a+"="+os.environ[a]+'\n')
#        f.write("\n\n")
#        f.write("** Content of /proc/self/ **\n"+subprocess.Popen(['ls','-lh','/proc/self/'],stdout=subprocess.PIPE).stdout.read())
    postinstantiation = PostInstantiation()


if __name__ == '__main__':
   # logging.basicConfig(level=logging.WARNING,
   #                     format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
   # logger = logging.getLogger("postinstantiation")
    setup_default_logging()
    main()

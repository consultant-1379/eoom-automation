#!/bin/sh
#
# SGSN-MME initial configuration template
#

# INPUT PARAMETERS
#
node_id="<node_id>"
node_type="<node_type>"
tmo="<tmo>"
ss7="<ss7>"
time_zone="<time_zone>"
# Network - OM_CN
OM_CN_vlan_id="0"
OM_CN_service_ip_1="<OM_CN_service_ip_1>"
OM_CN_ips=(<OM_CN_ips>)
OM_CN_prefix_length="<OM_CN_prefix_length>"
OM_CN_gateway_ip_1="<OM_CN_gateway_ip_1>"


# TAG PARAMETERS
#
# Tags commented out with a single hash mark are enabled.
# Tags commented out with double hash marks are disabled.

# Public SSH key to use as authorized key for the system defined accounts.
# Typically found in ~/.ssh/id_rsa.pub.
# Multiple tags are allowed.
# ssh_authorized_key: <ssh_public_key>
# ssh_authorized_key: <ssh_public_key_2>

# IP MTU size [bytes] on the internal network.
# Recommendation is to set the maximum value that the cloud system supports.
# Value range: 1280-9000
# Default value: 1500
# internal_mtu: <internal_mtu>

# Generic injection of OS Configuration Framework (cf) commands.
# cf_config: cf set console.extra_console <extra_console>
# cf_config: cf set storage.drbd.sync_rate <storage_drbd_sync_rate>
# cf_config: cf set fsb.external_network.fsb1_ip <fsb_admin_ip_1>
# cf_config: cf set fsb.external_network.fsb2_ip <fsb_admin_ip_2>
# cf_config: cf set fsb.external_network.netmask <fsb_admin_prefix_length>
# cf_config: cf set fsb.external_network.gateway <fsb_admin_gateway_ip_1>
# cf_config: cf set fsb.external_network.fsb2_gateway <fsb_admin_gateway_ip_2>
# cf_config: cf append fsb.external_network.dns_servers <fsb_admin_dns_server_ip_1>
# cf_config: cf append fsb.external_network.dns_servers <fsb_admin_dns_server_ip_2>


# FUNCTIONS
#
# Convert CIDR to netmask, for example 24 -> 255.255.255.0
cidr2mask ()
{
  # Number of args to shift, 255..255, first non-255 byte, zeroes
  set -- $(( 5 - ($1 / 8) )) 255 255 255 255 $(( (255 << (8 - ($1 % 8))) & 255 )) 0 0 0
  [ $1 -gt 1 ] && shift $1 || shift
  echo ${1-0}.${2-0}.${3-0}.${4-0}
}


# CONFIGURATION
#
# Change the software deployment.
# Note that this must be executed before any other configuration is applied.
sau="36001" # Integrated vLC deployment
gsh deploy_sc { -type $node_type -sau $sau -tmo $tmo -ss7 $ss7 }

# Configure Node Id.
gsh modify_ne -ni $node_id

# Configure SGSN-MME Time Zone.
# Note that checkpoint and node restart are required to activate the change.
gsh modify_date_and_time -tz $time_zone

# -----------------------------------------------------------------------------
# Configure network OM_CN
# -----------------------------------------------------------------------------

gsh create_ip_network -nw OM_CN

gsh create_ip_service -sn NTP -nw OM_CN
gsh create_ip_service -sn OAM -nw OM_CN

gsh create_ip_service_address -sn OAM -ip $OM_CN_service_ip_1
gsh create_ip_service_address -sn NTP -ip $OM_CN_service_ip_1

gsh create_bfd -nw OM_CN
gsh create_bfd_neighbor -nw OM_CN -ip $OM_CN_gateway_ip_1

i=0
# Configure maximum number of vLCs (as many as the supplied IPs),
# to prepare for future scale out.
for eqp in 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 2.10 2.11 2.12 2.13 2.14 2.15 2.16 2.17 2.18 2.19 2.20 2.21 2.22 2.23 2.24 2.25 2.26 2.27 2.28 2.29 2.30 2.31 2.32 2.33 2.34 2.35 2.36 2.37 2.38 2.39 2.40 2.41 2.42 2.43 2.44 2.45 2.46 2.47 2.48 2.49 2.50 2.51 2.52 2.53 2.54 2.55 2.56 2.57 2.58 2.59 2.60 2.61 2.62 2.63 2.64 ; do

  # Break if no more IPs are available.
  if [ -z "${OM_CN_ips[$i]}" ] ; then
    break
  fi

  vid=$OM_CN_vlan_id
  gsh create_eth_port -eqp $eqp -ep 1
  gsh create_eth_vlan -eqp $eqp -ep 1 -vid $vid

  dhcpv4=" "
  dhcpv6=" "
  ippart=${OM_CN_ips[$i]}
  ipv4addr=" -ip $ippart -mask $(cidr2mask $OM_CN_prefix_length)"
  gsh create_ip_interface -ifn "ETH_${eqp/./_}_1_${vid}_OM_CN" $ipv4addr $dhcpv4 $dhcpv6 -eqp $eqp -ep 1 -vid $vid -nw OM_CN

  gsh create_router_instance -eqp $eqp -nw OM_CN
  gsh create_static_route -eqp $eqp -nw OM_CN -dip 0.0.0.0 -mask 0.0.0.0 -gip $OM_CN_gateway_ip_1

  i=$(($i+1))
done


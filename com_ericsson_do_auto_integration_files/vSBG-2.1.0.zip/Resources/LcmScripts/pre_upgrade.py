#!/usr/bin/env python2

import argparse
import json
import logging
import os
import re
import sys
import shutil
import yaml
from imscommon import SSHUtility


DEFAULT_ADMIN = 'vsbg-admin'


class ReturnCode:
    SUCCESS = 0
    PARSE_ERROR = 1
    MO_INSTANCE_ERROR = 2
    ADMIN_STATE_ERROR = 3
    RETURN_ERROR = 4
    RETURN_NOR_STD_ERROR = 5
    STD_ERROR = 6
    REPEAT = 100


def mkcmd(*parts):
    """ Create an escaped command line from its parts """
    return ' '.join("'{0}'".format(p) for p in parts)


class Exit(Exception):
    def __init__(self, return_code):
        self.return_code = return_code


class PreUpgrade:
    class InputData:
        def __init__(self,
                     sc_ip,
                     instaceid,
                     environment,
                     stack_details,
                     admin_username,
                     admin_password_hash):
            self.sc_ip = sc_ip
            self.config_dir = os.path.dirname(environment)
            self.instaceid = instaceid
            self.environment = environment
            self.stack_details = stack_details
            self.admin_username = admin_username
            self.admin_password_hash = admin_password_hash

    def __init__(self):
        self.input_data = PreUpgrade.argument_parsing()
        self.ssh = None
        self.state = None
        self.conf_up_path = None
        self.conf_roll_path = None

    def __call__(self):
        self.ssh = self.connect_to_host(ip=self.input_data.sc_ip,
                                        username=self.input_data.admin_username,
                                        port=22)
        logger.debug('Checking if NBI is available')
        if not self.check_connection():
            raise Exit(ReturnCode.REPEAT)

        self.create_vnflcm_dir()
        self.generate_loopback_key()
        self.export_configuration()
        self.ssh.close()
        print self.generate_upgrade_environments()

    def connect_to_host(self, ip, username, port=22):
        return SSHUtility.SSHUtility(
            ip=ip,
            username=username,
            port=port,
            keep_alive=True)

    def check_connection(self):
        try:
            self.ssh.run_command('w')
        except:
            logger.exception('Failed to execute remote command')
            return False
        else:
            return True

    def create_vnflcm_dir(self):
        try:
            self.ssh.run_command(
                str.format(
                    "if [ ! -d '{0}' ]; then "
                    "  mkdir -m 777 '{0}'; "
                    "fi",
                    self.path('VNFLCM_DIR')))
        except:
            logger.exception('Failed to create dir %r', self.path('VNFLCM_DIR'))
            raise Exit(ReturnCode.RETURN_ERROR)

    def generate_loopback_key(self):
        """
        Generate key-pair on SBG SC, so we can log back in through NETCONF.
        """
        mkkey_cmd = str.format(
            ("if [ ! -s '{0}' ]; then "
             "    ssh-keygen -b 2048 -N '' -f '{0}'; "
             "    cat '{1}' >> ~/.ssh/authorized_keys; "
             "fi"),
            self.path('LOOPBACK_KEY_PATH'),
            self.path('LOOPBACK_PUBKEY_PATH'))
        try:
            self.ssh.run_command(mkkey_cmd)
        except:
            logger.exception('Failed to create loopback key')
            raise Exit(ReturnCode.RETURN_ERROR)

    def export_configuration(self):
        if not os.path.exists(self.input_data.config_dir):
            logger.error('The output configuration directory is not existed.')
            raise Exit(ReturnCode.RETURN_ERROR)

        conf_up_dir = os.path.join(self.input_data.config_dir, '.upgrade_config')
        conf_roll_dir = os.path.join(self.input_data.config_dir, '.rollback_config')

        if not os.path.exists(conf_up_dir):
            os.mkdir(conf_up_dir)

        if not os.path.exists(conf_roll_dir):
            os.mkdir(conf_roll_dir)

        conf_file = 'sbg_config'
        extense = '.tar.gz'

        conf_up_path = os.path.join(conf_up_dir, conf_file + extense)
        conf_roll_path = os.path.join(conf_roll_dir, conf_file + extense)
        remote_path = os.path.join(self.path('VNFLCM_DIR'), conf_file + extense)
        remote_target = os.path.join(self.path('VNFLCM_DIR'), conf_file)

        self.update_state()
        if self.state is None:
            logger.error('Start to export the configration.')
            self._perform_configuration_export(remote_target)
            raise Exit(ReturnCode.REPEAT)
        elif self.state == 'Running':
            logger.error('Exporting the configuration.')
            raise Exit(ReturnCode.REPEAT)
        elif self.state == 'Error':
            logger.error('Failed to export the configration.')
            raise Exit(ReturnCode.RETURN_ERROR)
        else:
            logger.error('The configuration is exported.')
            self.rm_remote_file(self.path('START_FILE'))
            self.rm_remote_file(self.path('RET_FILE'))
            self.ssh.get_file(remote_path, conf_up_path)
            """
            In SBG the converting action is combined to importing action
            So just copy the config file for both upgrade and rollback
            """
            shutil.copy2(conf_up_path, conf_roll_path)
            self.conf_up_path = conf_up_path
            self.conf_roll_path = conf_roll_path

    def generate_upgrade_environments(self):
        """ TODO: report a TR to common workflows """
        scheme_conf_up_path = "file://" + self.conf_up_path
        scheme_conf_roll_path = "file://" + self.conf_roll_path

        jsons = {}
        jsons['upgradeEnvironment'] = self._load_environment_file()
        jsons['rollbackEnvironment'] = self._create_rollback_environment_file()
        jsons['upgradeAdditionalFiles'] = [scheme_conf_up_path]
        jsons['rollbackAdditionalFiles'] = [scheme_conf_roll_path]

        return json.dumps(jsons)

    def _perform_configuration_export(self, remote_target):
        try:
            """ There is a TR for imex sbc_export_conf.py """
            """ 1. Not support abs path, so split it """
            """ 2. Not accept the filename with extense """
            (filepath, filename) = os.path.split(remote_target)
            self.ssh.run_command(
                str.format(
                    'nohup bash -c '
                    '\'cd {2}; '
                    'IMEX_SFTP_USER={1} '
                    'IMEX_SFTP_HOST={0} '
                    '/opt/imex/sbc_export_conf.py --timeout 600 --user {1} {3}; '
                    'echo $? > {4}\' '
                    '> {5} 2>{6} </dev/null &',
                    self.input_data.sc_ip,
                    self.input_data.admin_username,
                    filepath,
                    filename,
                    self.path('RET_FILE'),
                    self.path('OUT_FILE'),
                    self.path('ERR_FILE')))
            self.ssh.run_command(mkcmd('touch', self.path('START_FILE')))

        except:
            logger.error('Failed to export configuration.')
            raise Exit(ReturnCode.RETURN_ERROR)

    def _load_environment_file(self):
        with open(self.input_data.environment) as yamlfile:
            env = yaml.load(yamlfile)
        return env

    def _create_rollback_environment_file(self):
        env = {}
        env['parameter_defaults'] = {}
        parameters = self.input_data.stack_details['parameters']
        regex = re.compile('[:]')

        for attr, val in parameters.iteritems():
            if regex.search(attr) is None:
                """
                json load can not parse the netsted unicode str
                from stack file
                e.g.
                In env(yaml), sig_vlans: ['1001', '1002']
                In stack(json), , "sig_vlans": "[u'1001', u'1002]",
                After json load, Dict< u'sig_vlans':u"[u'1001', u'1002]" >
                So excute additional parse, after _nested_escape_unicode:
                str u"[u'1001', u'1002]" => list ['1001', '1002']
                """
                r_attr = self._nested_escape_unicode(attr)
                r_val = self._nested_escape_unicode(val)
                env['parameter_defaults'][r_attr] = r_val

        return env

    def _nested_escape_unicode(self, item):
        if isinstance(item, unicode) is True:
            real_item = item.encode('unicode_escape')
        else:
            real_item = item

        if isinstance(real_item, str) is True:
            return self._nested_escape_unicode_for_str(real_item)
        else:
            return real_item

    def _nested_escape_unicode_for_str(self, origin_str):
        relay_str = origin_str.strip()
        str_len = len(relay_str)
        if str_len < 3:
            return relay_str
        elif relay_str[0] == '[' and relay_str[str_len - 1] == ']':
            """
            From str [,,,] to list [,,,]
            """
            outlist = []
            for i in re.split(',', relay_str[2:str_len - 1]):
                outlist.append(self._nested_escape_unicode_for_str(i))
            return outlist
        elif (relay_str[0] == 'u' and
              relay_str[1] == '\'' and
              relay_str[str_len - 1] == '\''):
            """
            From str: u'string' to str: 'string'
            """
            return relay_str[2:str_len - 1]
        elif (relay_str[0] == 'u' and
              relay_str[1] == '\"' and
              relay_str[str_len - 1] == '\"'):
            """
            From str u"a'bc'de" to str a'bc'de OR
                 str u"[u'a', u'b']" to list of str ['a', 'b']
            """
            return self._nested_escape_unicode_for_str(relay_str[2:str_len - 1])
        else:
            return relay_str

    def rm_remote_file(self, file_):
        self.ssh.run_command(mkcmd('rm', '-f', file_),
                             fail_at_error=False)

    def path(self, name):
        if self.input_data.instaceid is None:
            conf_dir = 'vnflcm_upgrade'
        else:
            conf_dir = 'vnflcm_upgrade_' + self.input_data.instaceid

        home_dir = os.path.join('/home', self.input_data.admin_username)
        vnflcm_dir = os.path.join(home_dir, conf_dir)
        return {
            'VNFLCM_DIR':
                vnflcm_dir,
            'RET_FILE':
                os.path.join(vnflcm_dir, 'job.ret'),
            'OUT_FILE':
                os.path.join(vnflcm_dir, 'job.out'),
            'ERR_FILE':
                os.path.join(vnflcm_dir, 'job.err'),
            'START_FILE':
                os.path.join(vnflcm_dir, 'job.started'),
            'LOOPBACK_KEY_PATH':
                os.path.join(home_dir, '.ssh', 'netconf-loopback'),
            'LOOPBACK_PUBKEY_PATH':
                os.path.join(home_dir, '.ssh', 'netconf-loopback') + '.pub'}[name]

    def update_state(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f', self.path('START_FILE')),
                                 fail_at_error=False)

        if retcode > 0:
            self.state = None
            return

        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat', self.path('RET_FILE')),
                                 fail_at_error=False)
        if retcode > 0:
            self.state = 'Running'
        elif stdout.strip() == '0':
            self.state = 'Done'
        else:
            self.state = 'Error'

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(
            description='pre_upgrade hook for workflow')
        arg = parser.add_argument
        arg('-e', '--environment', metavar='<ENVIRONMENT>',
            help='Path to environment file', type=str, required=True)
        arg('-f', '--stack-details-file', metavar='<FILE>',
            help='Path to the file containing the response of stack show '
                 'details command in json format.',
            type=str, required=True)
        arg('-k', '--key-file', metavar='<KEY_FILE>',
            help='SSH public key', type=str, required=False)
        arg('-u', '--user-name', metavar='<USERNAME>',
            help='user name', type=str, required=False)
        arg('-s', '--sourceversion',
            help='Source version', required=False)
        arg('-t', '--targetversion',
            help='Target version', required=False)
        arg('-i', '--instaceid',
            help='Workflow session instance id', required=False)
        args = parser.parse_args()

        logger.debug('Loading json file %r', args.stack_details_file)
        with open(args.stack_details_file) as jsonfile:
            stack_details = json.load(jsonfile)['stack']

        parameters = dict(
            (k, v.strip())
            for k, v in stack_details['parameters'].iteritems()
        )
        stack_outputs = dict(
            (output['output_key'], output['output_value'])
            for output in stack_details['outputs']
        )

        sc_ip = stack_outputs.get('Output-IP')
        admin_username = parameters.get('admin_username', DEFAULT_ADMIN)
        admin_password_hash = parameters.get('admin_password_hash')

        data = PreUpgrade.InputData(sc_ip,
                                    args.instaceid,
                                    args.environment,
                                    stack_details,
                                    admin_username,
                                    admin_password_hash)
        logger.info('Input data: %r', data)
        return data


def main():
    pre_upgrade = PreUpgrade()
    try:
        pre_upgrade()
    except Exit as e:
        if e.return_code == ReturnCode.SUCCESS:
            logger.error('Exiting with SUCCESS (0)')
        elif e.return_code == ReturnCode.REPEAT:
            logger.error('Exiting with REPEAT (100)')
        else:
            logger.error('Exiting with ERROR (%d)', e.return_code)

        sys.exit(e.return_code)


if __name__ == '__main__':
    """ sys.stdout is used for printing envrionments and config files """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    logger = logging.getLogger('preupgrade')
    main()

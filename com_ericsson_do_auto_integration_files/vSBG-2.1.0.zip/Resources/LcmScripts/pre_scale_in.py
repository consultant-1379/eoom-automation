#!/usr/bin/env python

# import vmrscommon.pre_scale_in_common as prescalein
# from vmrscommon.lcm_common import Exit
import sys


# class VSBGPrescaleIn(prescalein.PrescaleIn):
#     def generate_get_mo_instance_id_script(self, uuid):
#         return 'uuid=' + uuid + '''
#         computeResource=$({ echo 'show -r -m ComputeResource  -c uuid=='${uuid}'  -p '; echo 'exit';} |\
#                         /opt/com/bin/cliss -sb )
#         Instance=$({ echo 'show -r -m BgfInstance -c computeResourceMoRef=='${computeResource}' -p '; echo 'exit';}|\
#                     /opt/com/bin/cliss -sb )
#         echo -n $Instance
#         '''


# def main():
#     try:
#         print VSBGPrescaleIn(sys.argv[1:]).pre_scale_in_hook()
#     except Exit as e:
#         sys.exit(e.return_code)


if __name__ == '__main__':
    err_msg = "pre_scale_in is not implemented in vSBG"
    print >> sys.stderr, err_msg
    raise NotImplementedError(err_msg)

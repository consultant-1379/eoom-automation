#!/usr/bin/env python

# import vmrscommon.post_scale_out_common as postscaleout
# from vmrscommon.lcm_common import Exit
# import sys


# class VSBGPostScaleOut(postscaleout.PostScaleOut):
#     def generate_get_mo_instance_id_script(self, uuid):
#         return 'uuid=' + uuid + '''
#         computeResource=$({ echo 'show -r -m ComputeResource  -c uuid=='${uuid}'  -p '; echo 'exit';} |\
#                         /opt/com/bin/cliss -sb )
#         Instance=$({ echo 'show -r -m SbgInstance -c computeResourceMoRef=='${computeResource}' -p '; echo 'exit';}|\
#                     /opt/com/bin/cliss -sb )
#         echo -n $Instance
#         '''


# def main():
#     try:
#         print VSBGPostScaleOut(sys.argv[1:]).post_scale_out_hook()
#     except Exit as e:
#         sys.exit(e.return_code)


if __name__ == '__main__':
    pass

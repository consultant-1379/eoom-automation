#!/usr/bin/env python

# import vmrscommon.pre_scale_out_common as prescaleout
# from vmrscommon.lcm_common import Exit
import sys


# class VSBGPrescaleOut(prescaleout.PrescaleOut):
#     pass


# def main():
#     try:
#         print VSBGPrescaleOut(sys.argv[1:]).pre_scale_out_hook()
#     except Exit as e:
#         sys.exit(e.return_code)


if __name__ == '__main__':
    err_msg = "pre_scale_out is not implemented in vSBG"
    print >> sys.stderr, err_msg
    raise NotImplementedError(err_msg)

#!/usr/bin/env python2

import os
import argparse
import json
import logging
import sys
from imscommon import SSHUtility


DEFAULT_ADMIN = 'vsbg-admin'


class ReturnCode:
    SUCCESS = 0
    PARSE_ERROR = 1
    MO_INSTANCE_ERROR = 2
    ADMIN_STATE_ERROR = 3
    RETURN_ERROR = 4
    RETURN_NOR_STD_ERROR = 5
    STD_ERROR = 6
    CLISS_ERROR = 7
    INVALID_JSON = 8
    MISSING_JSON_PARAMETER = 9
    INVALID_PAYLOAD_INSTANCE_COUNT = 10
    INVALID_STEP_NUMBER = 11
    RESOURCE_CARDINALITY_MISMATCH = 12
    INVALID_SHUTDOWN_TYPE = 13
    REPEAT = 100


class Exit(Exception):
    def __init__(self, return_code):
        self.return_code = return_code


class PreTermination:
    class InputData:
        def __init__(self, sc_ip, termination_type, admin_username):
            self.sc_ip = sc_ip
            self.termination_type = termination_type
            self.admin_username = admin_username

    def __init__(self):
        self.input_data = PreTermination.argument_parsing()

        if self.input_data.termination_type == 'FORCEFUL':
            logger.info('FORCEFUL TERMINATION')
            raise Exit(ReturnCode.SUCCESS)

        self.ssh = self.connect_to_host(ip=self.input_data.sc_ip,
                                        username=self.input_data.admin_username,
                                        port=22)
        logger.debug('Checking if NBI is available')
        if not self.check_connection():
            raise Exit(ReturnCode.REPEAT)

        logger.info('Prepare for graceful lock')
        self.generate_loopback_key()
        self.graceful_lock_mated_pair(self.input_data.admin_username)
        logger.info('Graceful lock is in progress')

        admin_status = self.read_adm_status(self.input_data.admin_username)
        if admin_status == 'LOCKED':
            logger.info('adminStatus is LOCKED')
            raise Exit(ReturnCode.SUCCESS)

    def connect_to_host(self, ip, username, port=22):
        return SSHUtility.SSHUtility(
            ip=ip,
            username=username,
            port=port,
            keep_alive=True)

    def check_connection(self):
        try:
            self.ssh.run_command('w')
        except:
            logger.exception('Failed to execute remote command')
            return False
        else:
            return True

    def generate_loopback_key(self):
        """
        Generate key-pair on SBG SC, so we can log back in through NETCONF.
        """
        mkkey_cmd = str.format(
            ("if [ ! -s '{0}' ]; then "
             "    ssh-keygen -b 2048 -N '' -f '{0}'; "
             "    cat '{1}' >> ~/.ssh/authorized_keys; "
             "fi"),
            self.path('LOOPBACK_KEY_PATH'),
            self.path('LOOPBACK_PUBKEY_PATH'))
        try:
            self.ssh.run_command(mkkey_cmd)
        except:
            logger.exception('Failed to create loopback key')
            raise Exit(ReturnCode.RETURN_ERROR)

    def read_adm_status(self, username):
        return self.ssh.run_command(
            str.format(
                "/opt/imex/mated_pair_util.py "
                "--user '{0}' "
                "--getadmstat",
                username))

    def graceful_lock_mated_pair(self, username):
        try:
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--gracefullock",
                    username))
        except ValueError:
            logger.error('Graceful lock is unsuccessful')
            raise Exit(ReturnCode.REPEAT)
        return True

    def path(self, name):
        home_dir = os.path.join('/home', self.input_data.admin_username)
        vnflcm_dir = os.path.join(home_dir, 'vnflcm')
        return {
            'VNFLCM_DIR':
                vnflcm_dir,
            'LOOPBACK_KEY_PATH':
                os.path.join(home_dir, '.ssh', 'netconf-loopback'),
            'LOOPBACK_PUBKEY_PATH':
                os.path.join(home_dir, '.ssh', 'netconf-loopback') + '.pub'}[name]

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(
            description='pre_termination hook for workflow')
        arg = parser.add_argument
        arg('-f', '--stack-details-file', metavar='<FILE>',
            help='Path to the file containing the response of stack show '
                 'details command in json format.',
            type=str, required=True)
        arg('-t', '--termination-type', metavar='<TERMINATION_TYPE>',
            choices=['GRACEFUL', 'FORCEFUL'],
            help='Termination type',
            type=str, required=True)
        arg('-s', '--graceful-timeout', metavar='<TIME>',
            help='Graceful lock timeout, not supported by vSBG',
            type=str, required=False)

        args = parser.parse_args()

        logger.debug('Loading json file %r', args.stack_details_file)
        with open(args.stack_details_file) as json_file:
            stack_details = json.load(json_file)['stack']

        termination_type = args.termination_type

        parameters = dict(
            (k, v.strip())
            for k, v in stack_details['parameters'].iteritems()
        )
        stack_outputs = dict(
            (output['output_key'], output['output_value'])
            for output in stack_details['outputs']
        )

        sc_ip = stack_outputs.get('Output-IP')
        admin_username = parameters.get('admin_username', DEFAULT_ADMIN)

        data = PreTermination.InputData(sc_ip, termination_type, admin_username)
        logger.info('Input data: %r', data)
        return data

def main():
    try:
        PreTermination()
    except Exit as e:
        logger.error('Exiting (%d)', e.return_code)
        sys.exit(e.return_code)

if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s')
    logger = logging.getLogger('pretermination')
    main()

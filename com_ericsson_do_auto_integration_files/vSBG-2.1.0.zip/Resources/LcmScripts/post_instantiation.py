#!/usr/bin/env python2

import os
import argparse
import json
import logging
import time
import sys
from imscommon import SSHUtility


DEFAULT_ADMIN = 'vsbg-admin'
# ChangeThisPassword!
DEFAULT_UNSECURE_PASSWORD_HASH = '$6$PaCtwW8P$mEbYmfM3uZrtWihX6C/IuU.DKkkfWCm0.zTgKYqAL1LtVwz7Z76BWYZjeo.0XQwv2brjmwDFtdRbiu5y9NvLL.'  # noqa: E501


class JobType(object):
    FG = 0
    BG = 1


class ReturnCode(object):
    SUCCESS = 0
    PARSE_ERROR = 1
    MO_INSTANCE_ERROR = 2
    ADMIN_STATE_ERROR = 3
    RETURN_ERROR = 4
    RETURN_NOR_STD_ERROR = 5
    STD_ERROR = 6
    REPEAT = 100


def mkcmd(*parts):
    """ Create an escaped command line from its parts """
    return ' '.join("'{0}'".format(p) for p in parts)


class Exit(Exception):
    def __init__(self, return_code):
        self.return_code = return_code


class PostInstantiation(object):
    job_list = [('wait_for_cmw_status_ok', JobType.FG),
                ('check_cmw_status_node_su_sg', JobType.FG),
                ('generate_loopback_key', JobType.FG),
                ('import_configuration', JobType.BG),
                ('change_secla_password', JobType.FG)]

    class InputData:
        def __init__(self,
                     sc_ip,
                     config_dir,
                     key_file,
                     admin_username,
                     admin_password_hash,
                     secla_password_hash):
            self.sc_ip = sc_ip
            self.config_dir = config_dir
            self.key_file = key_file
            self.admin_username = admin_username
            self.admin_password_hash = admin_password_hash
            self.secla_password_hash = secla_password_hash

        def __repr__(self):
            return repr(self.__dict__)

    def __init__(self):
        self.input_data = PostInstantiation.argument_parsing()
        self.ssh = None
        self.state = None
        self.to_run = None

    def __call__(self):
        self.ssh = self.connect_to_host(ip=self.input_data.sc_ip,
                                        username=self.input_data.admin_username,
                                        port=22)
        logger.debug('Checking if NBI is available')
        if not self.check_connection():
            raise Exit(ReturnCode.REPEAT)
        self.create_vnflcm_dir()
        self.read_state_file()
        self.check_state()
        self.execute_jobs()
        self.rm_file(self.path('STATE_FILE'))
        self.rm_file(self.path('RET_FILE'))
        self.ssh.close()

    def connect_to_host(self, ip, username, port=22):
        return SSHUtility.SSHUtility(
            ip=ip,
            username=username,
            port=port,
            keep_alive=True)

    def check_connection(self):
        try:
            self.ssh.run_command('w')
        except:
            logger.exception('Failed to execute remote command')
            return False
        else:
            return True

    def create_vnflcm_dir(self):
        try:
            self.ssh.run_command(
                str.format(
                    "if [ ! -d '{0}' ]; then "
                    "  mkdir -m 777 '{0}'; "
                    "fi",
                    self.path('VNFLCM_DIR')))
        except:
            logger.exception('Failed to create dir %r', self.path('VNFLCM_DIR'))
            raise Exit(ReturnCode.RETURN_ERROR)

    def read_state_file(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat', self.path('STATE_FILE')),
                                 fail_at_error=False)
        self.state = stdout.strip() if retcode == 0 else ''

    def check_state(self):
        if self.state == '':
            logger.debug('State is clean, will run all the jobs')
            self.to_run = PostInstantiation.job_list
        else:
            logger.debug('Intermediate state detected: %s', self.state)
            self._check_bg_job()

    def _check_bg_job(self):
        if self._is_job_started():
            self._read_job_ret()

        # bg job is done or not started if reaches here
        # re-organize the job list
        self.to_run = []
        found = False
        for jobname, jobtype in PostInstantiation.job_list:
            if jobname == self.state.strip():
                found = True
                continue
            if found:
                self.to_run.append((jobname, jobtype))
        self.rm_file(self.path('STATE_FILE'))
        self.rm_file(self.path('RET_FILE'))
        self.rm_file(self.path('START_FILE'))

    def _is_job_started(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f', self.path('START_FILE')),
                                 fail_at_error=False)
        return retcode == 0

    def _read_job_ret(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat', self.path('RET_FILE')),
                                 fail_at_error=False)
        if retcode > 0:
            logger.warning('Background job %s is still running', self.state)
            raise Exit(ReturnCode.REPEAT)
        else:
            ret = int(stdout.strip())
            logger.debug('Background job %r exits with %r', self.state, ret)
            if ret > 0:
                logger.exception('Background job exited with error')
                raise Exit(ReturnCode.RETURN_ERROR)

    def execute_jobs(self):
        logger.debug('Jobs to run %r', self.to_run)
        for jobname, jobtype in self.to_run:
            func = getattr(self, jobname)
            if callable(func):
                func()
            else:
                logger.exception('Wrong job name %r', jobname)
                raise Exit(ReturnCode.RETURN_ERROR)

            if jobtype == JobType.BG:
                logger.debug('Interrupted by job %r', jobname)
                self._save_state(jobname)
                raise Exit(ReturnCode.REPEAT)

    def _save_state(self, jobname):
        logger.debug('Saving state %r to file', jobname)
        try:
            self.ssh.run_command(
                str.format(
                    "echo '{0}' > '{1}'",
                    jobname,
                    self.path('STATE_FILE')))
        except:
            logger.exception('Failed to save state file')
            raise Exit(ReturnCode.RETURN_ERROR)

    def rm_file(self, file_):
        self.ssh.run_command(mkcmd('rm', '-f', file_),
                             fail_at_error=False)

    def wait_for_cmw_status_ok(self):
        logger.info('Waiting for CoreMW')
        if not self._wait_for_cmd_status_ok('cmw-status node'):
            logger.info('CoreMW is NOT OK')
            raise Exit(ReturnCode.REPEAT)
        logger.info('CoreMW is OK')

    def check_cmw_status_node_su_sg(self):
        logger.info('Waiting for cmw-status node su sg')
        if not self._wait_for_cmd_status_ok('cmw-status node su sg'):
            logger.info('cmw-status node su sg is NOT OK')
            raise Exit(ReturnCode.REPEAT)
        logger.info('cmw-status node su sg is OK')

    def _wait_for_cmd_status_ok(self, p_cmd, p_retry_loop=10, p_sleep=5):
        logger.debug('Waiting for %r status ...', p_cmd)
        for l_attempt in range(p_retry_loop):
            try:
                self.ssh.run_command(p_cmd)
            except Exception as e:
                logger.debug(repr(e))
                logger.info('Status is NOT OK, retry... (%d/%d)',
                            l_attempt + 1, p_retry_loop)
                time.sleep(p_sleep)
            else:
                logger.debug('Status is OK')
                return True
        logger.error('Status is NOT OK (%r)', p_cmd)
        return False

    def generate_loopback_key(self):
        """
        Generate key-pair on SBG SC, so we can log back in through NETCONF.
        """
        try:
            self.ssh.run_command(
                str.format(
                    "if [ ! -s '{0}' ]; then "
                    "    ssh-keygen -b 2048 -N '' -f '{0}'; "
                    "    cat '{1}' >> '{2}'; "
                    "fi",
                    self.path('LOOPBACK_KEY_PATH'),
                    self.path('LOOPBACK_PUBKEY_PATH'),
                    self.path('AUTHORIZED_KEYS_PATH')))
        except:
            logger.exception('Failed to create loopback key')
            raise Exit(ReturnCode.RETURN_ERROR)
        logger.info('Generated loopback key')

    def import_configuration(self):
        possible_names = (
            'config.xml',
            'sbg_config.tar.gz',
        )
        possible_paths = (
            os.path.join(self.input_data.config_dir, fname)
            for fname in possible_names
        )

        try:
            src_path = next(
                pth for pth in possible_paths if os.path.exists(pth))
        except StopIteration:
            logger.warning('No config files found in %r; expected any of:%r',
                           self.input_data.config_dir, possible_names)
            logger.info('The vSBG instance will not be configured.')
            return
        self._perform_configuration_import(src_path)

    def _perform_configuration_import(self, src_path):
        dst_path = os.path.join(self.path('VNFLCM_DIR'), os.path.basename(src_path))
        logger.info('Importing configuration from %r, through VNF:%r',
                    src_path, dst_path)
        try:
            self.ssh.send_file(src_path, dst_path)
            self.ssh.run_command(
                str.format(
                    'nohup bash -c '
                    '\'IMEX_SFTP_USER={1} '
                    'IMEX_SFTP_HOST={0} '
                    '/opt/imex/sbc_import_conf.py --timeout 1800 --user {1} {2}; '
                    'echo $? > {3}\' '
                    '> {4} 2>{5} </dev/null &',
                    self.input_data.sc_ip,
                    self.input_data.admin_username,
                    dst_path,
                    self.path('RET_FILE'),
                    self.path('OUT_FILE'),
                    self.path('ERR_FILE')))
            self.ssh.run_command(mkcmd('touch', self.path('START_FILE')))
        except:
            logger.error('Failed to import configuration')
            raise Exit(ReturnCode.RETURN_ERROR)

    def change_secla_password(self):
        logger.info('Changing secla password')
        pwhash = self.input_data.secla_password_hash
        try:
            stdout, stderr, retcode = self.ssh.run_command(
                'ps -ef | grep slapd | fgrep -v grep',
                fail_at_error=False)
            logger.info('slapd found on active SC, will change the sec-la-passwd')
            self.ssh.run_command(
                "sudo /opt/eric/sec-la-cxp9026994/bin/sec-la-passwd la-admin -h '" +
                pwhash + "'")
        except:
            logger.exception('Changing secla password failed:')
            raise Exit(ReturnCode.RETURN_ERROR)
        logger.info('Changed secla password')

    def path(self, name):
        home_dir = os.path.join('/home', self.input_data.admin_username)
        vnflcm_dir = os.path.join(home_dir, 'vnflcm')
        return {
            'VNFLCM_DIR':
                vnflcm_dir,
            'STATE_FILE':
                os.path.join(vnflcm_dir, 'post_install_wf_state'),
            'RET_FILE':
                os.path.join(vnflcm_dir, 'job.ret'),
            'OUT_FILE':
                os.path.join(vnflcm_dir, 'job.out'),
            'ERR_FILE':
                os.path.join(vnflcm_dir, 'job.err'),
            'START_FILE':
                os.path.join(vnflcm_dir, 'job.started'),
            'AUTHORIZED_KEYS_PATH':
                os.path.join(home_dir, '.ssh', 'authorized_keys'),
            'LOOPBACK_KEY_PATH':
                os.path.join(home_dir, '.ssh', 'netconf-loopback'),
            'LOOPBACK_PUBKEY_PATH':
                os.path.join(home_dir, '.ssh', 'netconf-loopback') + '.pub'}[name]

    @staticmethod
    def argument_parsing():
        parser = argparse.ArgumentParser(
            description='post_instantiation hook for workflow')
        arg = parser.add_argument
        arg('-f', '--stack-details-file', metavar='<FILE>',
            help=('Path to the file containing the response of stack show '
                  'details command in json format.'),
            type=str, required=True)
        arg('-c', '--config-dir', metavar='<CONFIG_DIR>',
            help='Configuration directory', type=str, required=True)
        arg('-k', '--key-file', metavar='<KEY_FILE>',
            help='SSH public key', type=str, required=False)
        arg('-u', '--user-name', metavar='<USERNAME>',
            help='user name', type=str, required=False)
        arg('-p', '--password-file', metavar='<PASSWORD_FILE>',
            help='password file', type=str, required=False)

        args = parser.parse_args()

        logger.debug('Loading json file %r', args.stack_details_file)
        with open(args.stack_details_file) as json_file:
            stack_details = json.load(json_file)['stack']

        config_dir = args.config_dir
        key_file = args.key_file

        parameters = dict(
            (k, v.strip())
            for k, v in stack_details['parameters'].iteritems()
        )
        stack_outputs = dict(
            (output['output_key'], output['output_value'])
            for output in stack_details['outputs']
        )

        sc_ip = stack_outputs.get('Output-IP')
        admin_username = parameters.get('admin_username', DEFAULT_ADMIN)
        admin_password_hash = parameters.get('admin_password_hash')
        secla_password_hash = parameters.get('secla_password_hash')

        if admin_password_hash is None:
            logger.warning(
                'Admin password hash not specified in parameters, '
                'USING DEFAULT PASSWORD')
            admin_password_hash = DEFAULT_UNSECURE_PASSWORD_HASH

        if secla_password_hash is None:
            logger.warning(
                'Secla password hash not specified in parameters, '
                'USING DEFAULT PASSWORD')
            secla_password_hash = DEFAULT_UNSECURE_PASSWORD_HASH

        data = PostInstantiation.InputData(
            sc_ip, config_dir, key_file,
            admin_username, admin_password_hash,
            secla_password_hash)
        logger.info('Input data: %r', data)
        return data


def main():
    post_instantiation = PostInstantiation()
    try:
        post_instantiation()
    except Exit as e:
        logger.error('Exiting (%d)', e.return_code)
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stdout)
    logger = logging.getLogger('postinstantiation')
    main()

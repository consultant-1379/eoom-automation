#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

from vmrscommon.lcm_common import setup_default_logging
from vmrscommon.pre_termination_common import PreTermination, Exit
import sys


class VBGFPreTermination(PreTermination):
    def get_instances_script(self):
        return ['show -r -m BgfInstance -p']

    def generate_shutdown_timer_script(self, shutdown_min):
        cliss_cmd_fmt = (
            'ManagedElement=1,'
            'BorderGatewayFunction=1,'
            'shuttingDownTimer="{0}"'
        )
        return [
            'configure',
            cliss_cmd_fmt.format(shutdown_min),
            'commit',
        ]


def main():
    try:
        VBGFPreTermination(sys.argv[1:]).pre_termination_hook()
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    setup_default_logging()
    main()

#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import print_function
import logging
import socket

import paramiko
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode


class NoReturnCodeError(Exception):
    pass


class RemoteError(Exception):
    def __init__(self, error_message):
        super(RemoteError, self).__init__()
        self.error_message = error_message

    def __str__(self):
        return self.error_message


class CliExecutor:
    def __init__(self, ssh):
        self.ssh = ssh
        self.exit_on_error = True
        self.__logger = logging.getLogger('CliExecutor')

    def set_exit_on_error(self, exit_on_error):
        '''
        By default this is True. If set to True, then an 'Exit' object
        will be raised in case of errors. If set to False, then a RemoteError
        object will be raised instead.
        '''
        self.exit_on_error = exit_on_error

    def _run_ssh_command(self, script, fail_at_error):
        try:
            return self.ssh.run_command(script, fail_at_error=fail_at_error)
        except paramiko.SSHException as paramiko_ex:
            self.__logger.error("SSH connection failed!")
            if not self.exit_on_error:
                raise RemoteError(
                    "cannot connect to host - "
                    + paramiko_ex.__class__.__name__)

            print('SSH connection failed ({extype})! IP: {ip} User: {user}'.format(
                ip=self.ssh.ip,
                user=self.ssh.username,
                extype=paramiko_ex.__class__.__name__,
            ))
            print(' -- Waiting for O&M connection setup.')
            raise Exit(ReturnCode.REPEAT)
        except socket.error as socket_error:
            self.__logger.error("Socket error on SSH connection!")
            if not self.exit_on_error:
                raise RemoteError(
                    getattr(socket_error, 'strerror', None)
                    or 'network socket error')

            print("Socket error on SSH connection ({msg})! IP: {ip} User: {user}".format(
                ip=self.ssh.ip,
                user=self.ssh.username,
                msg=getattr(socket_error, 'strerror', 'unknown error'),
            ))
            print(' -- Waiting for O&M connection setup.')
            raise Exit(ReturnCode.REPEAT)

    def run_cli_remote(self, script):
        stdout, stderr, ret = self._run_ssh_command(script, False)

        if ret != 0:
            self.__logger.warning(
                ("Got %d return code running command '%s'. "
                 "Output: %s Stderr: %s"),
                ret, script, stdout, stderr)
            if not self.exit_on_error:
                raise RemoteError('remote command failed')
            print('Remote command failed, retrying.')
            raise Exit(ReturnCode.REPEAT)

        return stdout

    @staticmethod
    def build_cliss_script(cliss_commands):
        script = '{ '
        for command in cliss_commands:
            script += "echo '" + command + "'; "
        script += "echo 'exit'; } | /opt/com/bin/cliss -sb"

        return script

    def bg_job_state(self, job_name):
        '''
        Reports
            - 'active' if the job is running,
            - 'failed' if it exited with non-zero code,
            - 'inactive' if it exited with code 0 or does not exist.
        Because of the above, it should always be check if the service/job
        exists before calling this.
        '''
        stdout, _, _ = self._run_ssh_command(
            "sudo systemctl is-active {}".format(job_name), False)
        return (stdout or '').strip()

    def bg_job_summary(self, job_name):
        '''Gets the summary of the service's status.'''
        stdout, _, _ = self._run_ssh_command(
            "sudo systemctl status {} |cat".format(job_name), False)
        return (stdout or '').strip()

    def bg_job_exists(self, job_name):
        '''
        A systemd run command has been started,
        if the systemd status for it has more than 3 lines.
        Can't use systemctl list-units because that doesn't include transient
        services which were once active but are now inactive.
        '''
        return self.bg_job_summary(job_name).count('\n') > 3

    def start_bg_job(self, script, job_name):
        '''
        Run set of commands in background.
            - Stdout/err and rc won't be available directly.
            - Will run as root.
            - CWD will be '/' so script should use abspath.
        Returns an ID which can be queried with systemctl.
        '''
        # escape bash commands and characters so they get interpreted only
        # in the inner shell:
        chars_to_escape = ['\\', '$', '"', '`', ]  # backslash first
        for c in chars_to_escape:
            script = script.replace(c, "\\" + c)

        cmd = 'sudo systemd-run --unit={} bash -c "{}"'.format(
            job_name, script)
        out, _, _ = self._run_ssh_command(cmd, True)
        return out.strip()

    def run_cliss_remote(self, cliss_commands):
        script = self.build_cliss_script(cliss_commands)
        stdout, stderr, rc = self._run_ssh_command(script, False)

        if rc == -1:
            raise NoReturnCodeError(cliss_commands)

        if "ERROR" in stdout:
            self.__logger.error(
                ("Cliss output had an error when running command '%s'. "
                 "Output: %s"),
                script, stdout)
            if not self.exit_on_error:
                raise RemoteError('cliss command returned error')

            raise Exit(ReturnCode.CLISS_ERROR)

        if stderr != "":
            self.__logger.error(
                ("Cliss printed to stderr while running command '%s'. "
                 "Output: %s Stderr: %s"),
                script, stdout, stderr)
            if not self.exit_on_error:
                raise RemoteError('cliss command returned error')

            raise Exit(ReturnCode.CLISS_ERROR)

        return stdout.strip()

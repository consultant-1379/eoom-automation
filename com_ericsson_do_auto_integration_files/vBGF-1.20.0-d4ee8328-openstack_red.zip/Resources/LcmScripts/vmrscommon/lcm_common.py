#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import argparse
import json
import logging
import math
import time
import os
import sys
import re
import functools

from imscommon import SSHUtility
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode, VmAdminState
from imscommon.parsers import OpenstackJsonParser, VCDXmlParser
from vmrscommon.lcm_data import VnfInstanceData
from vmrscommon.utils import CliExecutor, RemoteError, NoReturnCodeError

logger = logging.getLogger('lcm_common')


class LcmHook(object):
    def __init__(self):
        pass

    ME_CLISS_PATTERN = re.compile(
        '^'
        'ManagedElement=(?P<me>[^ ]+),'
        'Equipment=(?P<equipment>[^ ]+),'
        'ComputeResource=(?P<name>[^ ]+)'
        ' *$'
    )

    OK_STATUSES = ['OK', 'CONFIGURATION_NEEDED']

    def get_logger(self):
        return logging.getLogger(self.__class__.__name__)

    def check_oam_connection(self):
        try:
            self.cli.set_exit_on_error(False)
            self.cli.run_cli_remote('true')
            return True
        except RemoteError:
            return False
        finally:
            self.cli.set_exit_on_error(True)

    def get_vm_health_error(self, vm_uuid):
        try:
            self.cli.set_exit_on_error(False)
            return self._get_vm_health_error(vm_uuid)
        finally:
            self.cli.set_exit_on_error(True)

    def _get_vm_health_error(self, vm_uuid):
        '''
        Return None if the VM in the cluster is found healthy.
        Otherwise, return a string describing the cause of the error.
        Assumes the CliExecutor won't raise Exit due to settings.
        '''
        try:
            cluster_data = self.cli.run_cli_remote('cluster list --json')
        except RemoteError as e:
            return e
        try:
            cluster_vms = json.loads(cluster_data)
            target_vm = [vm for vm in cluster_vms if vm.get('uuid') == vm_uuid]
        except Exception:
            return 'failed to parse cluster list output'

        if not target_vm:
            return "VM with uuid '{}' missing from cluster".format(vm_uuid)
        target_vm = target_vm[0]

        if target_vm['operationalstate'] not in self.OK_STATUSES:
            return "VM's operational state is '{}'".format(
                target_vm['operationalstate'])

        if target_vm['role'] not in ['STANDBY', 'ACTIVE', 'QUIESCED']:
            return "VM has unknown role '{}'".format(target_vm['role'])

        return None

    def get_mo_admin_state(self, mo_instance):
        try:
            commands = ['show ' + mo_instance + ',administrativeState']
            admin_state = self.cli.run_cliss_remote(commands)
            if admin_state:
                admin_state = admin_state.split('=')[1]
        except Exit:
            self.get_logger().error("Can't get adminstate for mo_instance: %s",
                                    mo_instance)
            admin_state = VmAdminState.UNBOUND

        if not admin_state:
            self.get_logger().error("Can't get adminstate for mo_instance: %s",
                                    mo_instance)
            return VmAdminState.UNBOUND
        else:
            self.get_logger().info("The mo_instance: %s has adminstate: %s",
                                   mo_instance, admin_state)
            return admin_state

    def get_compute_resource(self, uuid):
        commands = [
            str.format(
                "show -r -m ComputeResource  -c uuid=='{0}' -p",
                uuid,
            ),
        ]
        return self.cli.run_cliss_remote(commands)

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def get_mo_instance_of_uuid(self, uuid):
        try:
            compute_resource = self.get_compute_resource(uuid)
            mo_instance = self.cli.run_cliss_remote(
                self.generate_get_mo_instance_id_script(compute_resource))
        except (Exit, NoReturnCodeError):
            self.get_logger().error("cant get mo_instance for uuid: %s", uuid)
            return VmAdminState.UNBOUND

        if not mo_instance:
            self.get_logger().error("cant get mo_instance for uuid: %s", uuid)
            return VmAdminState.UNBOUND
        else:
            return mo_instance

    def read_password_from_file(self):
        if not self.parsed_args.password_file:
            return None

        with open(self.parsed_args.password_file, 'r') as pf:
            password = pf.read()

        os.remove(self.parsed_args.password_file)
        return password

    def add_common_arguments(self, description):
        self.parser = argparse.ArgumentParser(description=description)

        self.mandatory = self.parser.add_argument_group('mandatory arguments')
        self.mandatory.add_argument(
            '-f', '--vnf-instance-details-file', metavar='<FILE>',
            help=('Path to the file containing the response of '
                  'stack show details (OpenStack) or vAPP details (vCloud Director) '
                  'command in json (OpenStack) or xml (vCloud Director) format.'),
            required=True)

        arg = self.parser.add_argument
        arg('-i', '--workflow-instance-identifier', metavar='<ID>',
            help='Workflow instance identifier.',
            required=False)
        arg('-k', '--key-file', metavar='<KEY_FILE>',
            help='Path to the file containing the private key for login.')
        arg('-p', '--password-file', metavar='<PASSWORD_FILE>',
            help=('Path to the file containing the password '
                  'to login into the VNF instance.'))
        arg('-u', '--user-name', metavar='<USERNAME>',
            help='Username to login into the VNF instance')
        arg('--no-package', action='store_true',
            help=('Do not try to access other package files. '
                  'Skips some sanity checks'))
        arg('-q', '--quit-operation', metavar='cancel',
            help='Gracefully cancels LCM script hook.',
            choices=['cancel'], required=False)

    def get_active_user_name(self):
        user_name = self.parsed_args.user_name
        if not user_name:
            user_name = self.vnf_instance_data.user_name

        return user_name

    def get_parser(self):
        if self.parsed_args.vnf_instance_details_file.endswith('.xml'):
            return VCDXmlParser(self.parsed_args.vnf_instance_details_file)
        else:
            return OpenstackJsonParser(self.parsed_args.vnf_instance_details_file)

    def _get_managed_element_data(self):
        command = 'show -r -m ComputeResource'
        op = self.cli.run_cliss_remote([command])
        self.get_logger().info(
            'Command: %s, cliss response: %s', command, op
        )
        lines = op.strip().splitlines()
        me_indexes = [
            idx for idx in range(len(lines))
            if re.match(self.ME_CLISS_PATTERN, lines[idx])
        ]
        self.get_logger().debug("me_indexes: %s", me_indexes)
        if not me_indexes:
            self.get_logger().error(
                'No managed element entries found in cliss response!',
            )
            raise Exit(ReturnCode.PARSE_ERROR)

        managed_elements = []
        for idx in range(len(me_indexes)):  # pylint: disable=C0200
            me_start = me_indexes[idx]
            me_end = (
                me_indexes[idx + 1] if idx < len(me_indexes) - 1
                else len(lines)
            )
            self.get_logger().debug("me_start: %s, me_end: %s", me_start, me_end)
            managed_elements.append(lines[me_start:me_end])
        self.get_logger().debug(
            "managed_elements:\n%s",
            '\n++++++++++++\n'.join('\n'.join(l) for l in managed_elements)
        )
        return managed_elements

    def _get_me_values(self, me_lines):
        macs = []
        uuid = None
        entry_regexp = re.compile(
            '^ *"(?P<mac>'
            '[A-Fa-f0-9]{2}(:[A-Fa-f0-9]{2}){5}'
            ')" *$'
            '|'
            '^ *uuid="(?P<uuid>'
            '[0-9A-Fa-f]{8}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{12}'
            ')" *$'
        )
        # this is assumed to always match because
        # the input is generated by _get_managed_element_data:
        me_name = re.match(self.ME_CLISS_PATTERN, me_lines[0]).group('name')
        for line in me_lines[1:]:
            entry_match = re.match(entry_regexp, line)
            if not entry_match:
                self.get_logger().debug(
                    ("Line in me_data did not match anything "
                     "being looked for: '%s'"), line
                )
            elif entry_match.group('mac'):
                macs.append(entry_match.group('mac'))
            elif entry_match.group('uuid'):
                uuid = entry_match.group('uuid')

        return me_name, uuid, macs

    def get_compute_resources(self):
        retcrs = {}
        for me_data in self._get_managed_element_data():
            name, uuid, macs = self._get_me_values(me_data)
            self.get_logger().info(
                'Managed element (%s) data - uuid: %s, macs: %s',
                name, uuid, macs
            )
            if not all([name, macs, uuid]):
                self.get_logger().error(
                    'Managed element missing macs or uuid or name!',
                )
                raise Exit(ReturnCode.PARSE_ERROR)
            retcrs[name] = {'uuid': uuid, 'macs': macs}

        return retcrs


def with_coremw_cleanup(fun):
    @functools.wraps(fun)
    def f(self, *args, **kwargs):
        # this should be unique to this workflow, with the help of uuid
        coremw_marker_name = "wf_coremw_cleanup_{}".format(
            self.parsed_args.workflow_instance_identifier)
        self.cleanup_coremw(coremw_marker_name)

        result = fun(self, *args, **kwargs)

        # delete service only at the very end when no more REPEATs can occur,
        #   until then the service has to stay there to indicate the state
        #   of the coremw step during REPEATs
        self.delete_coremw_marker(coremw_marker_name)
        return result

    return f


class PostHook(LcmHook):

    missing_uuids = []

    def get_expected_coremw_uuid_count(self):
        raise NotImplementedError()

    def find_coremw_uuids(self):
        final_number_of_vms = len(json.loads(self.cli.run_cli_remote("cluster list --json")))
        cmw_node_output = self.cli.run_cli_remote('( /opt/coremw/bin/cmw-status node -v ; exit 0 )')
        cmw_all_uuids, cmw_disabled_uuids = self.get_cmw_uuids(cmw_node_output.split('\n'))

        if (len(cmw_all_uuids) - len(cmw_disabled_uuids)) != final_number_of_vms:
            print("Not all existing UUID found in CoreMW. Waiting.")
            raise Exit(ReturnCode.REPEAT)

        cmw_removable_uuids = [uuid for uuid in cmw_disabled_uuids
                               if uuid not in self.get_vim_uuids()]
        cmw_missing_vm_uuids = [uuid for uuid in cmw_disabled_uuids
                                if uuid not in cmw_removable_uuids]
        logger.info("CMW UUIDs that are not found in stack details, "
                    "CoreMW workaround will be applied: %s", cmw_removable_uuids)
        logger.info("CMW UUIDs that are missing from the cluster, but "
                    "present in the stack details, administrative removal "
                    "should be considered: %s", cmw_missing_vm_uuids)
        return cmw_removable_uuids, cmw_missing_vm_uuids

    def get_vim_uuids(self):
        return self.vnf_instance_data.uuids

    def get_cmw_uuids(self, node_output):
        nodes = []
        disablednodes = []
        uuid_regex = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'

        # Node information consists three lines (UUID, adminstate, operstate)
        for node_index in range(len(node_output) / 3):
            uuid = re.findall(uuid_regex, node_output[3 * node_index])[0]
            nodes.append(uuid)
            if (re.findall('DISABLED', node_output[3 * node_index + 2])):
                disablednodes.append(uuid)

        logger.info("The following CMW UUIDs are not found in cluster: %s", disablednodes)
        return nodes, disablednodes

    def cleanup_coremw(self, coremw_marker_name):
        '''
        This step of the hook starts an ad-hoc service via systemd on the
        node being managed, so REPEATs are handled correctly.
          - no service means the step hasn't started
          - inactive service means the step is done
          - failed service means the step failed
          - running service means it's in progress
        '''

        def is_bg_job_done():
            state = self.cli.bg_job_state(coremw_marker_name)
            if state == 'inactive':
                logger.info(
                    'Coremw background job (already) finished successfully. '
                    'Proceeding to next step.')
                return True
            elif state == 'failed':
                logger.error('Coremw cleanup failed!')
                summary = self.cli.bg_job_summary(coremw_marker_name)
                logger.error('Coremw cleanup status was:\n%s', summary)
                raise Exit(ReturnCode.STD_ERROR)
            elif state == 'active':
                logger.info('Coremw background job is still running')
                return False
            else:
                logger.error('Unexpected background job state: %r', state)
                raise Exit(ReturnCode.RETURN_ERROR)

        # if the job does not exist yet, start it
        if not self.cli.bg_job_exists(coremw_marker_name):
            uuids, self.missing_uuids = self.find_coremw_uuids()
            # assuming the getter of cmw_uuids is idempotent, REPEATs caused
            #   by other parts of the script will cause it to jump over this
            #   again correctly:
            if not uuids:
                logger.info('No uuids to run coremw workaround for')
                return
            cleanup_script = str.format(
                ('exec 2>&1; set -xeu; '
                 'for u in {}; '
                 'do /usr/bin/scale_in_node.sh $u; '
                 'done;'), ' '.join(uuids))
            self.cli.start_bg_job(
                cleanup_script, coremw_marker_name)
            logger.info(
                'Coremw cleanup job started. '
                'Waiting a short period to see if it finishes '
                'without repeating...')
            time.sleep(7)

        if not is_bg_job_done():
            print('Coremw cleanup is running ({}.service)'.format(
                coremw_marker_name))
            raise Exit(ReturnCode.REPEAT)

    def delete_coremw_marker(self, coremw_marker_file):
        pass  # nothing to clean up(?)

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def get_vm_states(self, vms):
        states = []
        for vm in vms:
            states.append(vm['operationalstate'])
        return states

    def verify_cluster_status(self):
        vms = json.loads(self.cli.run_cli_remote("cluster list --json"))

        expected_number_of_vms = len(self.vnf_instance_data.uuids) - len(self.missing_uuids)

        if len(vms) != expected_number_of_vms:
            logger.error("Cluster list VM count does not match "
                         "the expected number of VMs")
            print('Waiting for cluster to be ready.')
            raise Exit(ReturnCode.REPEAT)

        imex_status_file = '/var/log/imex-status/import_status.log'
        if os.path.isfile(imex_status_file):
            with open(imex_status_file) as fd:
                content = fd.read()
                if content.strip() != 'OK':
                    logger.error("Failed to import configuration!")
                    raise Exit(ReturnCode.IMEX_FAILED)

        vm_states = self.get_vm_states(vms)
        for state in vm_states:
            if state not in self.OK_STATUSES:
                logger.error("Not every VM's operational state is OK")
                print('Waiting for cluster to be ready.')
                raise Exit(ReturnCode.REPEAT)

        self.get_logger().info("Every VM's operational state is OK")

        if len(self.missing_uuids) > 0:
            error_string = ("Following VMs are missing from the cluster "
                            "and are probably unhealthy, please consider "
                            "healing them: {}".format(self.missing_uuids))
            print(error_string)
            logger.error(error_string)
            raise Exit(ReturnCode.REJECT)
        return 'Cluster OK'


class PostScaleHook(PostHook):
    class InputData:
        def __init__(self, user_name, ip, uuids,
                     key_filename=None, password=None, port=22):
            self.user_name = user_name
            self.ip = ip
            self.uuids = uuids
            self.port = port
            self.key_filename = key_filename
            self.password = password

    def __init__(self, args):
        super(PostScaleHook, self).__init__()
        self.__logger = logging.getLogger('PostScaleHook')
        self.input_data = self.argument_parsing(args)
        ssh = SSHUtility.SSHUtility(
            ip=self.input_data.ip,
            username=self.input_data.user_name,
            password=self.input_data.password,
            key_filename=self.input_data.key_filename,
            port=self.input_data.port,
            keep_alive=True)
        self.cli = CliExecutor(ssh)

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def add_additional_arguments(self):
        pass

    def argument_parsing(self, args):
        self.add_common_arguments('post_scale hook for workflow')
        self.add_additional_arguments()
        self.parsed_args = self.parser.parse_args(args)

        self.password = self.read_password_from_file()

        self.vnf_instance_file_parser = self.get_parser()

        self.vnf_instance_data = VnfInstanceData(*self.vnf_instance_file_parser.get_all_params())

        logger.debug('json file [%s] loaded',
                     self.parsed_args.vnf_instance_details_file)

        self.active_user_name = self.get_active_user_name()

        return PostScaleHook.InputData(
            self.active_user_name, self.vnf_instance_data.ip,
            self.vnf_instance_data.uuids, self.parsed_args.key_file, self.password)

    def check_unbound_vms(self):
        unbound_vms = []

        for uuid in self.input_data.uuids:
            logger.info("Current UUID: %s", uuid)
            mo_instance = self.get_mo_instance_of_uuid(uuid)
            if mo_instance == VmAdminState.UNBOUND:
                unbound_vms.append(uuid)

        return unbound_vms

    def post_scale_hook(self):
        unbound_vms = self.check_unbound_vms()
        if unbound_vms:
            logger.error("Unbound VMs were found: %s", str(unbound_vms))
            print('Waiting for VMs to be bound.')
            raise Exit(ReturnCode.REPEAT)

        return self.verify_cluster_status()


class LockingLcmHook(LcmHook):
    SHUTDOWN_TYPES = ['FORCEFUL', 'GRACEFUL']

    class ShutdownType:
        GRACEFUL = 'GRACEFUL'
        FORCEFUL = 'FORCEFUL'

    def __init__(self):
        super(LockingLcmHook, self).__init__()
        self.shutdown_type = None
        self.shutting_down_timeout = None

    @staticmethod
    def check_shutdown_type(shutdown_type):
        if not shutdown_type:
            return

        if shutdown_type not in LockingLcmHook.SHUTDOWN_TYPES:
            logger.error("Invalid shutdown type additional parameter: %s",
                         shutdown_type)
            raise Exit(ReturnCode.INVALID_SHUTDOWN_TYPE)

    def convert_shutdown_seconds_to_minutes(self):
        if not self.shutting_down_timeout or self.shutting_down_timeout < 0:
            return 0

        return int(math.ceil(self.shutting_down_timeout / 60.0))

    def generate_shutdown_timer_script(self, shutdown_min):
        raise NotImplementedError()

    def set_shutting_down_timeout(self):
        shutdown_min = self.convert_shutdown_seconds_to_minutes()
        logger.debug("Shutting down timer to be set to: %d", shutdown_min)
        script = self.generate_shutdown_timer_script(shutdown_min)
        self.cli.run_cliss_remote(script)

    def graceful_lock(self):
        self.set_shutting_down_timeout()
        for vm in self.vm_descriptor_list:
            if vm.admin_state == VmAdminState.UNLOCKED:
                commands = ['configure',
                            vm.instance + ',administrativeState=SHUTTINGDOWN',
                            'commit']
                self.cli.run_cliss_remote(commands)

    def immediate_lock(self):
        for vm in self.vm_descriptor_list:
            commands = ['configure',
                        vm.instance + ',administrativeState=LOCKED',
                        'commit']
            self.cli.run_cliss_remote(commands)

    def unlock_vms(self):
        for vm in self.vm_descriptor_list:
            if vm.admin_state in (VmAdminState.LOCKED,
                                  VmAdminState.SHUTTINGDOWN):
                commands = ['configure',
                            vm.instance + ',administrativeState=UNLOCKED',
                            'commit']
                self.cli.run_cliss_remote(commands)

    def immediate_lock_requested(self):
        return self.shutting_down_timeout == 0

    def forceful_lock_requested(self):
        return self.shutdown_type == LockingLcmHook.ShutdownType.FORCEFUL

    def lock_instances(self):
        if self.immediate_lock_requested():
            self.immediate_lock()
        else:
            self.graceful_lock()


def setup_default_logging(level=logging.INFO, stream=sys.stderr):
    logging.basicConfig(
        level=level,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s ; ',
        stream=stream,
    )  # pragma: no cover

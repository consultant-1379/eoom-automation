#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode

import logging
from imscommon import SSHUtility
from imscommon.parsers import OpenstackJsonParser, VCDXmlParser

from vmrscommon.lcm_data import VnfInstanceData
from .lcm_common import (
    CliExecutor,
    PostHook,
)

logger = logging.getLogger('post_instantiation')


# https://github.com/PyCQA/pylint/issues/179
# Pylint can't detect if a class is less abstract but still not concrete.
# pylint: disable=W0223
class PostInstantiation(PostHook):

    def __init__(self, args):
        super(PostInstantiation, self).__init__()
        self.argument_parsing(args)
        ssh = SSHUtility.SSHUtility(
            ip=self.vnf_instance_data.ip,
            username=self.active_user_name,
            key_filename=self.parsed_args.key_file,
            password=self.password,
            keep_alive=True)

        self.cli = CliExecutor(ssh)

    def get_parser(self):
        if self.parsed_args.vnf_instance_details_file.endswith('.xml'):
            return VCDXmlParser(self.parsed_args.vnf_instance_details_file)
        else:
            return OpenstackJsonParser(self.parsed_args.vnf_instance_details_file)

    def argument_parsing(self, args):
        self.add_common_arguments('post_instance hook for workflow')
        self.parser.add_argument(
            '-c', '--config-dir', metavar='<CONFIG_DIR>',
            help='Configuration directory',
            required=False)
        self.parsed_args = self.parser.parse_args(args)

        self.password = self.read_password_from_file()

        self.vnf_instance_file_parser = self.get_parser()

        self.vnf_instance_data = VnfInstanceData(*self.vnf_instance_file_parser.get_all_params())

        self.active_user_name = self.get_active_user_name()

        logger.debug("ip = [%s], username = [%s]",
                     self.vnf_instance_data.ip, self.active_user_name)

    def set_managed_element_id(self):
        set_managed_element_id_script = [
            'configure',
            'ManagedElement=1,networkManagedElementId="{}"'.format(
                self.vnf_instance_file_parser.get_vnf_name()),
            'commit'
        ]
        self.cli.run_cliss_remote(set_managed_element_id_script)

    def post_instantiation_hook(self):
        if self.parsed_args.quit_operation:
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        self.set_managed_element_id()
        return self.verify_cluster_status()

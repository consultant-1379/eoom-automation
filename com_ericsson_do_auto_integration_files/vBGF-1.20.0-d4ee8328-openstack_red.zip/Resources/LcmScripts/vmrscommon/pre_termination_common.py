#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import logging

from imscommon import SSHUtility
from imscommon.consts import ReturnCode, VmAdminState
from imscommon.parsers import OpenstackJsonParser, VCDXmlParser
from imscommon.exceptions import Exit
from .lcm_common import LockingLcmHook
from .lcm_data import VmDescriptor, VnfInstanceData
from .utils import CliExecutor

logger = logging.getLogger('pre_termination')


class PreTermination(LockingLcmHook):

    class PreTerminationJsonParser(OpenstackJsonParser):
        pass

    def __init__(self, args):
        super(PreTermination, self).__init__()
        self.argument_parsing(args)

        if self.forceful_lock_requested():
            return

        self.cli = CliExecutor(
            SSHUtility.SSHUtility(
                ip=self.vnf_instance_data.ip,
                username=self.active_user_name,
                key_filename=self.parsed_args.key_file,
                password=self.password,
                keep_alive=True
            ),
        )

    def get_parser(self):
        if self.parsed_args.vnf_instance_details_file.endswith('.xml'):
            return VCDXmlParser(self.parsed_args.vnf_instance_details_file)
        else:
            return OpenstackJsonParser(self.parsed_args.vnf_instance_details_file)

    def argument_parsing(self, args):
        self.add_common_arguments('pre_termination hook for workflow')
        self.mandatory.add_argument(
            '-t', '--termination-type', metavar='<TERMINATION_TYPE>',
            help='GRACEFUL or FORCEFUL termination',
            choices=['GRACEFUL', 'FORCEFUL'],
            required=True)
        self.parser.add_argument(
            '-s', '--shutting-down-timer', metavar='<TIMER>',
            help='Timeout given for graceful shutdown in seconds',
            type=int,
            required=False)
        self.parsed_args = self.parser.parse_args(args)
        self.shutdown_type = self.parsed_args.termination_type
        self.shutting_down_timeout = self.parsed_args.shutting_down_timer

        if self.forceful_lock_requested():
            return

        self.vnf_instance_file_parser = self.get_parser()

        self.vnf_instance_data = VnfInstanceData(*self.vnf_instance_file_parser.get_all_params())

        self.password = self.read_password_from_file()

        self.active_user_name = self.get_active_user_name()

        logger.debug("ip = [%s], username = [%s], termination_type = [%s]",
                     self.vnf_instance_data.ip,
                     self.active_user_name,
                     self.parsed_args.termination_type)

    def get_instances_script(self):
        raise NotImplementedError()

    def get_instances(self):
        stdout = self.cli.run_cliss_remote(self.get_instances_script())
        if not stdout:
            logger.error("cant get mo_instances")
            raise Exit(ReturnCode.MO_INSTANCE_ERROR)

        logger.debug("Application instances: %s", stdout)

        # avoid empty string
        return filter(bool, stdout.split("\n"))

    def init_vm_descriptors(self):
        instances = self.get_instances()
        vm_descriptor_list = []
        for instance in instances:
            vm_descriptor_list.append(
                VmDescriptor(instance, self.get_mo_admin_state(instance)))

        return vm_descriptor_list

    def check_administrative_states(self):
        for vm in self.vm_descriptor_list:
            admin_state = self.get_mo_admin_state(vm.instance)
            if admin_state in (VmAdminState.UNLOCKED,
                               VmAdminState.SHUTTINGDOWN):
                if self.immediate_lock_requested():
                    logger.error("Not all vm's are locked!")
                    raise Exit(ReturnCode.ADMIN_STATE_ERROR)
                else:
                    logger.debug("Not all vm's are locked yet")
                    print("Waiting for LOCKED state.")
                    raise Exit(ReturnCode.REPEAT)

    def check_if_vms_unlocked(self):
        for vm in self.vm_descriptor_list:
            admin_state = self.get_mo_admin_state(vm.instance)
            if admin_state in (VmAdminState.LOCKED,
                               VmAdminState.SHUTTINGDOWN):
                logger.debug("Not all VMs are unlocked yet")
                print("Waiting for UNLOCKED state.")
                raise Exit(ReturnCode.REPEAT)

    def pre_termination_hook(self):
        if self.forceful_lock_requested():
            return

        self.vm_descriptor_list = self.init_vm_descriptors()

        if self.parsed_args.quit_operation:
            self.unlock_vms()
            self.check_if_vms_unlocked()
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        self.lock_instances()
        self.check_administrative_states()

#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import os
import re
import time
import json
import logging

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from imscommon import SSHUtility

from vmrscommon.utils import CliExecutor
from vmrscommon.lcm_data import VnfInstanceData


from .lcm_common import (
    OpenstackJsonParser,
    LcmHook,
)

logger = logging.getLogger('pre_heal')


class PreHeal(LcmHook):

    NO_ACTION_NEEDED = 101
    MIN_GRACE_PERIOD = 0  # TODO what is a realistic minimum time for the SC to do a failover?
    DEFAULT_GRACE_PERIOD_TIME_SEC = 4 * 60
    MAX_GRACE_PERIOD = 15 * 60

    class PreHealJsonParser(OpenstackJsonParser):
        pass

    def __init__(self, args):
        super(PreHeal, self).__init__()
        self.uuid_to_be_healed, self.payload_instance_count \
            = self.argument_parsing(args)

    def generate_get_mo_instance_id_script(self, uuid):
        raise NotImplementedError()

    def get_supported_alarm_types(self):
        raise NotImplementedError()

    def get_uuid_to_autoheal(self):
        raise NotImplementedError()

    def parse_auto_healing_info_params(self):
        if not self.parsed_args.auto_healing_info_file:
            return None
        return self.json_parser.parse_vnf_status_file(
            self.parsed_args.auto_healing_info_file)

    def parse_additional_params(self):
        if not self.parsed_args.additional_param_file:
            logger.error('Additional parameters missing!')
            raise Exit(ReturnCode.INVALID_JSON)

        return self.json_parser.parse_vnf_status_file(
            self.parsed_args.additional_param_file
        )

    def get_healing_info(self):
        if not self.auto_healing_info_params:
            resource_id = self.additional_params.get('resourceId')
            if not resource_id:
                logger.error('Parameter resourceId is missing from input!')
                raise Exit(ReturnCode.INVALID_JSON)

            return resource_id

        alarm_type = self.auto_healing_info_params.get('specificProblem')
        if str(alarm_type) not in self.get_supported_alarm_types():
            logger.error(
                'Auto-healing is not supported for this alarm type: %r !',
                alarm_type)
            raise Exit(ReturnCode.REJECT)

        return self.get_uuid_to_autoheal()

    def argument_parsing(self, args):
        self.add_common_arguments('pre_auto_healing hook for workflow')
        self.parser.add_argument(
            '-l', '--auto-healing-info-file',
            metavar='<AUTO_HEALING_INFO_FILE>',
            help='Auto Healing information parameters.')
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.')

        self.parsed_args = self.parser.parse_args(args)
        self.json_parser = PreHeal.PreHealJsonParser(
            self.parsed_args.vnf_instance_details_file)

        payload_instance_count = self.json_parser.get_payload_instance_count()
        self.auto_healing_info_params = self.parse_auto_healing_info_params()
        self.additional_params = self.parse_additional_params()
        uuid_to_be_healed = self.get_healing_info()

        self.password = self.read_password_from_file()
        self.vnf_instance_data = VnfInstanceData(*self.json_parser.get_all_params())

        ssh = SSHUtility.SSHUtility(
            ip=self.vnf_instance_data.ip,
            username=self.vnf_instance_data.user_name,
            password=self.password, key_filename=self.parsed_args.key_file,
            port=22, keep_alive=True)

        self.cli = CliExecutor(ssh)
        return uuid_to_be_healed, payload_instance_count

    def get_time_elapsed_since_start(self):
        '''
        Obtain the time by comparing current time to file creation time
        of input parameter files.
        '''
        ctime = os.path.getctime(self.parsed_args.vnf_instance_details_file)
        return time.time() - ctime

    def get_grace_period(self):
        timeout = self.auto_healing_info_params.get('gracePeriodBeforeHeal')
        if timeout is None:
            return self.DEFAULT_GRACE_PERIOD_TIME_SEC
        try:
            timeout = int(timeout)
        except ValueError:
            logger.error(
                "Invalid/missing value for 'gracePeriodBeforeHeal' value: %r",
                timeout)
            return self.DEFAULT_GRACE_PERIOD_TIME_SEC
        if not (self.MIN_GRACE_PERIOD <= timeout <= self.MAX_GRACE_PERIOD):
            logger.warning(
                "Invalid range for 'graceTimeoutForHeal', setting default")
            return self.DEFAULT_GRACE_PERIOD_TIME_SEC
        return timeout

    def find_uuid_in_text(self, text):
        uuid_re = (
            '.*(?P<uuid>'
            '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
            ').*'
        )
        match = re.search(uuid_re, text)
        if not match:
            self.get_logger().error("Couldn't find uuid in text: '%s'", text)
            return None
        return match.group('uuid')

    def check_if_vm_was_removed_from_cluster(self, bios_uuid):
        '''
        Raise NO_ACTION_NEEDED if the VM has been
        completely removed from the cluster. In that case we can assume
        someone or something has called scale_in_node.sh, which permanently
        removes the VM from the cluster.
        In the normal case, it may be missing from cluster list, but it
        will still exist in core-mw records as a 'DISABLED' node.
        '''
        cmw_node_output = self.cli.run_cli_remote(
            '( /opt/coremw/bin/cmw-status node -v ; exit 0 )').strip()

        if cmw_node_output.count('\n') < 2:  # at least 3 lines for one node
            logger.error('Unexpected data in cmw-status!')
            raise Exit(ReturnCode.RETURN_ERROR)

        if bios_uuid in cmw_node_output:
            logger.info('VM being checked is still in cmw-status')
            return

        logger.info(
            'VM was removed from cluster explicitly, no need to heal')
        raise Exit(self.NO_ACTION_NEEDED)

    def check_action_needed(self, uuid_to_be_healed):
        '''
        Try entering the VNF through the O&M interface. There is a
        permitted waiting period before the script gives up on doing so.
          - If the O&M still cannot be accessed by the end of this period,
            then this script should fail. Normally the roaming SC feature
            makes sure this does not happen for long, so in case it does,
            there are bigger issues that we cannot solve here.
        If the O&M becomes accessible, then the cluster list command should
        be used to check if the VM with the uuid is up and running. The same
        grace period concept applies to this as the previous point.
          - If the cluster node is still not up and okay, then pre_heal should
            proceed and pass on the VM UUID to common workflows.
          - otherwise, if the cluster list reports the VM is healthy,
            cancel the healing workflow by exiting with code 101.
        '''
        health_check_error = self.get_vm_health_error(uuid_to_be_healed)

        if health_check_error is None:
            logger.info(
                "VM's health with UUID %s is ok. Healing not needed.",
                uuid_to_be_healed)
            raise Exit(self.NO_ACTION_NEEDED)
        if 'missing from cluster' in str(health_check_error):
            self.check_if_vm_was_removed_from_cluster(uuid_to_be_healed)

        time_elapsed = self.get_time_elapsed_since_start()
        grace_period = self.get_grace_period()
        if time_elapsed < grace_period:
            logger.info('Still within grace period')
            user_message = str.format(
                ("VM health not ok: {}. \nMaximum grace period left before "
                 "forcing healing: ~{}s. \nWaiting to see if the VM recovers."),
                health_check_error, int(grace_period - time_elapsed))
            print(user_message)
            raise Exit(ReturnCode.REPEAT)

        if not self.check_oam_connection():
            logger.error(
                'Grace period expired, connection to roaming SC VM is '
                'still unavailable. Critical clustering failure?')
            # TODO throw error here or proceed?

        logger.info('Grace period time exceeded')
        logger.info('VM health is still not ok, forcing healing')

    def pre_heal_hook(self):
        if self.parsed_args.quit_operation:
            logger.info('Quit-operation parameter received. Exiting LCM hook.')
            raise Exit(ReturnCode.REJECT)

        if self.auto_healing_info_params:
            self.check_action_needed(self.uuid_to_be_healed)

        output = {"UUIDToBeHealed": self.uuid_to_be_healed}

        return json.dumps(output)

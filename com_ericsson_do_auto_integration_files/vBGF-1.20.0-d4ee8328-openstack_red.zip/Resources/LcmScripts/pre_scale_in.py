#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

import vmrscommon.pre_scale_in_common as prescalein
from vmrscommon.lcm_common import Exit, setup_default_logging
import sys


class VBGFPrescaleIn(prescalein.PrescaleIn):
    def generate_get_mo_instance_id_script(self, compute_resource):
        return [
            str.format(
                'show -r -m BgfInstance -c computeResourceMoRef=="{0}" -p',
                compute_resource,
            ),
        ]

    def generate_shutdown_timer_script(self, shutdown_min):
        cliss_cmd_fmt = (
            'ManagedElement=1,'
            'BorderGatewayFunction=1,'
            'shuttingDownTimer="{0}"'
        )
        return [
            'configure',
            cliss_cmd_fmt.format(shutdown_min),
            'commit',
        ]


def main():
    try:
        print VBGFPrescaleIn(sys.argv[1:]).pre_scale_in_hook()
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    setup_default_logging()
    main()

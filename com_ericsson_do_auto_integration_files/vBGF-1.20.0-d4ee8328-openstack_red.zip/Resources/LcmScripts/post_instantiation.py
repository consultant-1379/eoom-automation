#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import

import vmrscommon.post_instantiation_common as postinstantiation
from vmrscommon.lcm_common import Exit, setup_default_logging
import sys


class VBGFPostInstantiation(postinstantiation.PostInstantiation):
    pass


def main():
    try:
        print VBGFPostInstantiation(sys.argv[1:]).post_instantiation_hook()
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    setup_default_logging()
    main()

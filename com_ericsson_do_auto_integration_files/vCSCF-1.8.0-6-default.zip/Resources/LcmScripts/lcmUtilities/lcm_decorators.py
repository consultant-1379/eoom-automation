import functools
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------



def deprecated_task(fun):
    """
    Mark a function as deprecated, logging any invocation
    """
    @functools.wraps(fun)
    def wrapper(self, *args, **kwargs):
        self.log.debug("Function [%s] is DEPRECATED" % fun.__name__)
        return fun(self, *args, **kwargs)
    return wrapper


def skippable(fun):
    """
    Mark a function as skippable, if function calls self.update_state_file()
    with its name as a string parameter, the function will be skipped
    on future re-invocation of the hook
    """
    @functools.wraps(fun)
    def wrapper(self, *args, **kwargs):
        if not self.is_config_step_done(fun.__name__):
            return fun(self, *args, **kwargs)
        return None
    return wrapper


def workaround(info_str, debug_str=None):
    """
    Mark function as workaround, showing the info message,
    and an optional debug message in the debug logs
    """
    def _outer_wrapper(wrapped_function):
        @functools.wraps(wrapped_function)
        def _wrapper(self, *args, **kwargs):
            self.log.info("Running workaround: %s" % info_str)
            if debug_str:
                self.log.debug("Workaround: [%s]" % debug_str)
            return wrapped_function(self, *args, **kwargs)
        return _wrapper
    return _outer_wrapper

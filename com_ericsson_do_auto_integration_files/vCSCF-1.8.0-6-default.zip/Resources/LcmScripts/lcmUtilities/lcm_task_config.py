class LcmTaskConfig(object):
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

    """
    Lcm task configuration magic container.
    It can hold any configuration parameter, and returns undefined parameters as None
    """
    def __init__(self, **kwargs):
        if kwargs is not None:
            for key, value in kwargs.items():
                self.__dict__[key] = value

    def __setattr__(self, key, value):
        self.__dict__[key] = value

    def __setitem__(self, key, value):
        self.__dict__[key] = value

    def __getattr__(self, item):
        return None

    def __str__(self):
        return str(self.__dict__)

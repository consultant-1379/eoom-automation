from __future__ import (absolute_import, division, print_function, unicode_literals)
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------


import functools
import logging
from sys import stdout, stderr


def with_output(log_tag, fun):
    @functools.wraps(fun)
    def wrapper(self, *args, **kwargs):
        self.logger = logging.getLogger(log_tag)
        return fun(self, *args, **kwargs)
    return wrapper


class LcmOutputManager(object):
    def __init__(self, tag):
        self.output_started = False
        self.tag = tag

    def syslog(self, message, level=logging.INFO):
        logger = logging.getLogger(self.tag)
        logger.log(level, message)

    def info(self, message, with_feedback=True):
        self.syslog(message, logging.INFO)
        if with_feedback:
            self.stdout(message)

    def debug(self, message, with_feedback=False):
        self.syslog(message, logging.DEBUG)
        if with_feedback:
            self.stdout(message)

    def warning(self, message, with_feedback=True):
        self.syslog(message, logging.WARNING)
        if with_feedback:
            self._stderr(message)

    def error(self, message, with_feedback=True):
        self.syslog(message, logging.ERROR)
        if with_feedback:
            self._stderr(message)

    def stdout(self, message):
        """
        Write message to output using pipe as separator if it is not the first message
        :param message:
        :return:
        """
        if self.output_started:
            message = " | %s" % message
        else:
            self.output_started = True
        stdout.write(message)

    @staticmethod
    def _stderr(message):
        """
        Write message to stderr so it appears in the error message log of the webapp
        :param message:
        :return:
        """
        stderr.write(message)

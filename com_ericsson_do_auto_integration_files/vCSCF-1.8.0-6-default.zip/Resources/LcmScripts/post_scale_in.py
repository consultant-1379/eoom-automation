#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import re
from heapq import nsmallest

from common import setup_default_logging
from imscommon.consts import ReturnCode
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig
from parsers import VCDXmlParser
from scale_base import ScaleLcmBaseTask


# noinspection PyBroadException
class PostScaleIn(ScaleLcmBaseTask):

    def __init__(self):
        super(PostScaleIn, self).__init__()
        self.log = LcmOutputManager(tag="vCSCF-PostScaleIn")
        self.config = self.argument_parsing()
        if self.config.stack_name:
            self.log.tag = "vCSCF-PostScaleIn.%s" % self.config.stack_name

        if self.config.scale_type == "GRACEFUL":
            self.log.debug("GRACEFUL Post-Scale-in done")
            self.quit_with_code(ReturnCode.SUCCESS)

        if self.config.scale_type != "FORCEFUL":
            self.log.error("Invalid scale-in type. Valid scale-in types: GRACEFUL, FORCEFUL")
            self.quit_with_code(ReturnCode.REJECT)

        self.create_vnflcm_dir()
        self.read_state_file("post_scale_in")
        self.ssh = self.connect_with_config()

        if not self.config.is_openstack:
            self.vcd_workaround(self.config.parser)

    def do_post_scale_in(self):
        self.scale_in_keeping(keep_uuids=self.config.uuids)
        self.check_scale_in_complete(keep_uuids=self.config.uuids)
        self.rm_work_dir()
        self.log.debug("PostScaleIn done")
        self.quit_with_code(ReturnCode.SUCCESS)

    def vcd_workaround(self, parser):
        vm_list = parser.get_vm_name_list()

        filtered_vm_list = {}
        vm_number_pattern = re.compile("^.*-(?P<vm_num>\\d+)$")
        for vm_name in vm_list:
            if self.is_scalable_node(vm_name):
                match = vm_number_pattern.search(vm_name)
                if not match:
                    self.log.error("Can not extract VM number from [%s]" % vm_name)
                    self.quit_with_code(ReturnCode.VM_NR_ERROR)
                vm_num = self.string_to_int(match.group('vm_num'))
                filtered_vm_list[vm_name] = vm_num

        self.config.number_of_scaled_out_vms = len(filtered_vm_list)
        self.config.vm_names = nsmallest(len(filtered_vm_list), filtered_vm_list, key=filtered_vm_list.get)

        vm_to_mac = parser.get_vm_name_to_mac_dict()
        int_mac_to_vm = self.get_mac_to_sc_or_pl_name_dict()
        pl_to_uuid = self.get_pl_name_to_uuid_dict(self.get_equipment_data())

        for scaled_out_vm_name in self.config.vm_names:
            if scaled_out_vm_name not in vm_to_mac:
                self.log.error("Data fault, can not find VM")
                self.log.debug(
                    "Can not find VM name [%s] in VM-name-to-MAC list [%s] - exiting" % (scaled_out_vm_name, vm_to_mac))
                self.quit_with_code(ReturnCode.DATA_ERROR)

            mac = vm_to_mac[scaled_out_vm_name]
            if not mac[0] in int_mac_to_vm:
                continue

            node = int_mac_to_vm[mac[0]]
            if node not in pl_to_uuid:
                self.log.error("Data fault, can not find VM")
                self.log.debug("Can not find internal VM name [%s] in internal-PL-name-to-UUID list [%s] - exiting" % (
                    scaled_out_vm_name, pl_to_uuid))
                self.quit_with_code(ReturnCode.DATA_ERROR)

            self.config.uuids.append(pl_to_uuid[node])

    def argument_parsing(self):
        parser = self.argmunet_parsing_base(description='post_scale_in hook for workflow')
        parser.add_argument('-x', '--aspect-id', metavar='<ASPECT_ID>',
                            help='The aspect ID of the scaling domain to scale.', type=str, required=False)
        parser.add_argument('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
                            help='All additional parameters in json format.', type=str, required=False)
        parser.add_argument('-n', '--number-of-steps', metavar='<STEPS>',
                            help='Provides how many VMs will be scaled in.', type=int, required=False)
        parser.add_argument('-l', '--auto-scale-info-file', metavar='<AUTO_SCALE_INFO_FILE>',
                            help='Auto Scale information parameters.', type=str, required=False)
        args = parser.parse_args()
        if args.stack_details_file.endswith('.xml'):
            self.log.debug("Parsing XML config file: %s" % args.stack_details_file)
            config = self.parse_vcd_xml_file(args.stack_details_file)
        else:
            self.log.debug("Parsing JSON config file: %s" % args.stack_details_file)
            config = self.parse_open_stack_json_file(args.stack_details_file)

        if args.additional_param_file:
            self.log.debug("Additional param file: %s" % args.additional_param_file)
            with open(args.additional_param_file) as additional_json_file:
                additional_config_data = json.load(additional_json_file)
            config.scale_type = additional_config_data.get("scaleInType", "GRACEFUL").upper()
        else:
            config.scale_type = "GRACEFUL"

        config.emergency_username = self.get_value_or_fallback_on_none(args.user_name, config.emergency_username)
        config.key_file = args.key_file
        config.password_file = args.password_file
        config.workflow_instance_identifier = args.workflow_instance_identifier
        self.log.debug("Parameters parsed from config: %s" % config)
        self.config = config
        self.check_if_canceled(args)
        return config

    def parse_open_stack_json_file(self, config_file):
        with open(config_file) as json_file:
            config_data = json.load(json_file)

        config = LcmTaskConfig(scale_type=None, is_openstack=True)
        try:
            stack_params = config_data["stack"]["parameters"]
            config.stack_name = config_data["stack"]["stack_name"]
            config.emergency_username = stack_params["emergency_username"]
            config.mip = self.get_value_or_fallback_on_match(
                stack_params["OM_IPv4_address"].strip(),
                stack_params["OM_IPv6_address"].strip(), "none")

            stack_outputs = config_data["stack"]["outputs"]
            config.uuids = [uuid for uuid_lists in
                            [stack_output['output_value'].strip().split() for stack_output in stack_outputs if
                             stack_output['output_key'] == "scaled_VMs_UUID"]
                            for uuid in uuid_lists]
            config.number_of_scaled_out_vms = int(stack_params[self.SCALED_NUMBER_VAR_NAME].strip())
        except KeyError as ex:
            self.log.error("A field is missing from the JSON file: %s" % ex)
            self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)
        return config

    def parse_vcd_xml_file(self, config_file):
        parser = VCDXmlParser(config_file)
        v_app = parser.vnf_status_file
        v_app_name = v_app.attrib.get("name")
        if v_app_name is None:
            self.log.error("Could not fetch 'name' parameter while parsing input data")
            self.handle_config_file_error(config_file)

        config = LcmTaskConfig(scale_type=None, is_openstack=False, parser=parser)
        config.stack_name = v_app_name
        config.uuids = []
        config.number_of_scaled_out_vms = 0
        config.emergency_username = parser.get_property("emergency_username").strip()
        config.mip = self.get_value_or_fallback_on_match(
            parser.get_property('OM_IPv4_address').strip(),
            parser.get_property('OM_IPv6_address').strip(), "none")
        return config


if __name__ == '__main__':
    setup_default_logging()
    post_scale_in = PostScaleIn()
    post_scale_in.do_post_scale_in()

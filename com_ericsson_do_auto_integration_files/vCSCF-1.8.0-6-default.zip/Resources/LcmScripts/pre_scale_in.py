#!/usr/bin/env python
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------

# C0111(missing-docstring)
# pylint: disable=C0111

# Continue refactoring these:
# R1702(too-many-nested-blocks), R0904(too-many-public-methods), W0141(use-builtin-function filter,map)
# pylint: disable=R0904, W0141

# Workaround:
# F0401/E0401(import-error), W0622(redefined-builtin), W0311(bad-indentation), C0330(bad-continuation)
# pylint: disable=F0401, W0622, W0311

from __future__ import (absolute_import, division, print_function, unicode_literals)

import json
import re
import time
from heapq import nsmallest

from common import setup_default_logging
from imscommon.consts import ReturnCode
from imscommon.parsers import VCDXmlParser
from lcmUtilities.lcm_decorators import skippable
from lcmUtilities.lcm_output_manager import LcmOutputManager
from lcmUtilities.lcm_task_config import LcmTaskConfig
from scale_base import ScaleLcmBaseTask


# noinspection PyBroadException
class PreScaleIn(ScaleLcmBaseTask):
    SCALE_IN_PARAMETER_NAME = 'PL_to_be_scaled_in'

    def __init__(self):
        super(PreScaleIn, self).__init__()
        self.log = LcmOutputManager(tag="vCSCF-PreScaleIn")
        self.argument_parsing()

        if self.config.scale_type not in ("GRACEFUL", "FORCEFUL"):
            self.log.error("Invalid scale-in type. Valid scale-in types: GRACEFUL, FORCEFUL")
            self.quit_with_code(ReturnCode.REJECT)

    def do_pre_scale_in(self):
        self.check_pre_condition_step(self.config.specified_uuids)

        if not self.config.specified_uuids:
            self.config.specified_uuids = self.config.uuids[-self.config.scale_in_num:]

        control_data = {}
        if self.config.is_openstack:
            scale_in_vm_index_list = self.get_scale_in_vm_index_list(self.config.specified_uuids)
            remaining_scaled_vm_count = self.config.number_of_scaled_out_vms - self.config.scale_in_num
            self.log.debug("Scaling in VMs: %s" % scale_in_vm_index_list)
            self.log.debug("Number of scaled out VMs after scale-in: %d"
                           % remaining_scaled_vm_count)
            control_data[self.SCALE_IN_PARAMETER_NAME] = scale_in_vm_index_list
            control_data[self.SCALED_NUMBER_VAR_NAME] = remaining_scaled_vm_count
        else:
            vm_uuids = []
            for uuid in self.config.specified_uuids:
                if uuid not in self.config.vmware_internal_uuid_to_external_uuid_dict:
                    self.log.error("Data fault, can not find VM: %s" % uuid)
                    self.quit_with_code(ReturnCode.DATA_ERROR)
                vm_uuids.append(self.config.vmware_internal_uuid_to_external_uuid_dict[uuid])
            self.log.debug("VM UUIDs to remove: %s" % vm_uuids)
            control_data['vmuuids_to_remove'] = vm_uuids

        if self.config.scale_type == "FORCEFUL":
            self.log.info(json.dumps(control_data))
            self.log.debug("FORCEFUL Pre-Scale-in done")
            self.rm_file(self.scale_in_cache_file())
            self.quit_with_code(ReturnCode.SUCCESS)

        keep_uuids = [x for x in self.config.uuids if x not in self.config.specified_uuids]
        self.log.debug("Scale-in keeping UUIDs: %s" % keep_uuids)
        self.scale_in_keeping(keep_uuids=keep_uuids)
        self.check_scale_in_complete(keep_uuids=keep_uuids)
        self.vmware_extra_delay_step()
        self.rm_state_file()

        # This INFO printout is mandatory and must be the only one during the SUCCESS execution loop
        self.log.info(json.dumps(control_data))
        self.log.debug("GRACEFUL Pre-Scale-in done")
        self.rm_file(self.scale_in_cache_file())
        self.quit_with_code(ReturnCode.SUCCESS)

    def graceful_cancel(self):
        self.rm_file(self.scale_in_cache_file())
        super(PreScaleIn, self).graceful_cancel()

    def vcd_workaround(self, parser):
        # R0914(too-many-locals)
        # pylint: disable=R0914
        if self.read_cached_data():
            return

        vm_list = parser.get_vm_name_list()
        ext_name_to_ext_uuid_dict = parser.get_vm_name_to_id_dict()

        filtered_vm_list = {}
        vm_number_pattern = re.compile("^.*-(?P<vm_num>\\d+)$")
        for vm_name in vm_list:
            if self.is_scalable_node(vm_name):
                match = vm_number_pattern.search(vm_name)
                if not match:
                    self.log.error("Can not extract VM number from [%s]" % vm_name)
                    self.quit_with_code(ReturnCode.VM_NR_ERROR)
                vm_num = self.string_to_int(match.group('vm_num'))
                filtered_vm_list[vm_name] = vm_num
        self.log.debug("Filtered vm list: %s" % filtered_vm_list)

        self.config.number_of_scaled_out_vms = len(filtered_vm_list)
        self.config.vm_names = nsmallest(len(filtered_vm_list), filtered_vm_list, key=filtered_vm_list.get)

        vm_to_mac = parser.get_vm_name_to_mac_dict()
        int_mac_to_vm = self.get_mac_to_sc_or_pl_name_dict()
        pl_to_uuid = self.get_pl_name_to_uuid_dict(self.get_equipment_data())

        for scaled_out_vm_name in self.config.vm_names:
            if scaled_out_vm_name not in vm_to_mac:
                self.log.error("Data fault, can not find VM")
                self.log.debug(
                    "Can not find VM name [%s] in VM-name-to-MAC list [%s] - exiting" % (scaled_out_vm_name, vm_to_mac))
                self.quit_with_code(ReturnCode.DATA_ERROR)

            mac = vm_to_mac[scaled_out_vm_name]
            if not mac[0] in int_mac_to_vm:
                continue

            node = int_mac_to_vm[mac[0]]
            if node not in pl_to_uuid:
                self.log.info("Data fault, can not find VM")
                self.log.debug("Can not find internal VM name [%s] in internal-PL-name-to-UUID list [%s] - exiting" % (
                    scaled_out_vm_name, pl_to_uuid))
                self.quit_with_code(ReturnCode.DATA_ERROR)

            uuid = pl_to_uuid[node]
            self.config.uuids.append(uuid)

            if scaled_out_vm_name not in ext_name_to_ext_uuid_dict:
                self.log.info("Data fault, can not find VM")
                self.log.debug("VCDWorkaround: VM name [%s] is can not be found in VMware VM list [%s] - exiting" % (
                    scaled_out_vm_name, ext_name_to_ext_uuid_dict))
                self.quit_with_code(ReturnCode.DATA_ERROR)

            self.config.vmware_internal_uuid_to_external_uuid_dict[uuid] = ext_name_to_ext_uuid_dict[scaled_out_vm_name]

        result = {"uuids": self.config.uuids,
                  "vm_names": self.config.vm_names,
                  "number_of_scaled_out_vms": self.config.number_of_scaled_out_vms,
                  "vmware_internal_uuid_to_external_uuid_dict": self.config.vmware_internal_uuid_to_external_uuid_dict}
        self.write_vnflcm_file(json.dumps(result), self.scale_in_cache_file())

    def get_scale_in_vm_index_list(self, scale_in_uuids):
        """
        This method will return a list of VM numbers for the VM(s) that
        should be removed during the stack-update.
        """
        return [int(self.config.vm_names[self.config.uuids.index(u)].split('-')[-1]) for u in scale_in_uuids]

    @skippable
    def vmware_extra_delay_step(self):
        if not self.config.is_openstack:
            time.sleep(30)
        self.update_state_file("vmware_extra_delay_step")

    @skippable
    def check_pre_condition_step(self, specified_uuids):
        if self.config.scale_in_num <= 0:
            self.log.error("Number of scaled in VMs are less or equal than 0")
            self.quit_with_code(ReturnCode.REJECT)

        if not self.has_enough_scaled_vm():
            self.log.error("Only %s VM(s) can be scaled in" % self.config.number_of_scaled_out_vms)
            self.quit_with_code(ReturnCode.REJECT)

        if not self.check_uuids(specified_uuids):
            self.quit_with_code(ReturnCode.REJECT)

        if self.config.scale_type == "GRACEFUL":
            if self.check_out_of_memory():
                self.log.error(
                    "Scaling in is not possible because of Insufficient Memory Capabilities of Target Sized Cluster"
                    " (DBS, Memory Limit Reached alarm is active). Hint: 1) If multiple VMs were tried to be scaled"
                    " in parallel, it is recommended to scale in the VMs one by one."
                    " 2) Check the CSCF troubleshooting guide")
                self.quit_with_code(ReturnCode.REJECT)

            if not self.check_crm_status():
                self.log.error("Scaling in is not possible because the internal CrM node state is not ok. "
                               "Hint: 1) Check the CSCF troubleshooting guide")
                self.quit_with_code(ReturnCode.REJECT)

            if not self.check_vdicos_status():
                self.log.error("Scaling in is not possible because the internal vDicos state is not ok. "
                               "Hint: 1) Check the CSCF troubleshooting guide")
                self.quit_with_code(ReturnCode.REJECT)

        self.update_state_file("check_pre_condition_step")

    def has_enough_scaled_vm(self):
        return self.config.scale_in_num <= self.config.number_of_scaled_out_vms

    def check_uuids(self, specified_uuids):
        if specified_uuids:
            if len(specified_uuids) != self.config.scale_in_num:
                self.log.error("Number of slaced in VMs does not match the number of specified UUIDs")
                return False

            for uuid in specified_uuids:
                if uuid not in self.config.uuids:
                    self.log.error("The specified UUID %s is not a valid UUID." % uuid)
                    return False
        return True

    def check_out_of_memory(self):
        command = 'show ManagedElement=1,SystemFunctions=1,Fm=1 -m FmAlarm -c' \
                  ' majorType=193 && minorType=917505 && probableCause=162 &&' \
                  ' specificProblem="DBS, Memory Limit Reached"'
        com_result = self.run_com_cli_command(command, False)
        if com_result is None:
            self.quit_with_code(ReturnCode.CLISS_ERROR)
        if com_result.strip() != "":
            return True
        return False

    def read_param_status(self, command):
        com_result = self.run_com_cli_command(command, False)
        if com_result is None:
            self.log.info("The requested attribute is not yet available, retrying...")
            self.quit_with_code(ReturnCode.REPEAT)

        for line in com_result.split("\n"):
            state = line.split("=")[1]
            return state

        self.log.debug("Failed to read command: %s" % command)
        self.quit_with_code(ReturnCode.ADMIN_STATE_ERROR)

    def read_cached_data(self):
        data = self.read_vnflcm_file(self.scale_in_cache_file())
        if data is None:
            return False

        result = json.loads(data.split("\n")[0])
        self.config.uuids = result["uuids"]
        self.config.vm_names = result["vm_names"]
        self.config.number_of_scaled_out_vms = result["number_of_scaled_out_vms"]
        self.config.vmware_internal_uuid_to_external_uuid_dict = result["vmware_internal_uuid_to_external_uuid_dict"]
        return True

    def argument_parsing(self):
        parser = self.argmunet_parsing_base(description='pre_scale_in hook for workflow')
        parser.add_argument('-n', '--number-of-steps', metavar='<STEPS>',
                            help='Number of scaling steps', type=int, required=True)
        parser.add_argument('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
                            help='All additional parameters in json format.', type=str, required=False)
        parser.add_argument('-x', '--aspect-id', metavar='<ASPECT_ID>',
                            help='The aspect ID of the scaling domain to scale.', type=str, required=False)
        parser.add_argument('-l', '--auto-scale-info-file', metavar='<AUTO_SCALE_INFO_FILE>',
                            help='Auto Scale information parameters.', type=str, required=False)
        args = parser.parse_args()
        if args.stack_details_file.endswith('.xml'):
            self.log.debug("Parsing XML config file: %s" % args.stack_details_file)
            vcd_parser = self.parse_vcd_xml_file(args.stack_details_file)
        else:
            self.log.debug("Parsing JSON config file: %s" % args.stack_details_file)
            self.parse_openstack_json_file(args.stack_details_file)

        if args.additional_param_file:
            self.log.debug("Additional param file: %s" % args.additional_param_file)
            with open(args.additional_param_file) as additional_json_file:
                additional_config_data = json.load(additional_json_file)
            uuid_list = additional_config_data.get("listOfUUIDsToBeDeleted", [])
            self.config.scale_type = additional_config_data.get("scaleInType", "GRACEFUL").upper()
            self.config.specified_uuids = [uuid.strip() for uuid in uuid_list]
        else:
            self.config.scale_type = "GRACEFUL"
            self.config.specified_uuids = []

        self.config.workflow_instance_identifier = args.workflow_instance_identifier
        self.config.emergency_username = self.get_value_or_fallback_on_none(args.user_name,
                                                                            self.config.emergency_username)
        self.config.key_file = args.key_file
        self.config.password_file = args.password_file
        self.config.scale_in_num = args.number_of_steps
        self.config.vmware_internal_uuid_to_external_uuid_dict = {}

        """
         VCD workaround needs these in an early phase
         and auto_scale_info needs VCD workaround...
        """
        self.log.tag = "vCSCF-PreScaleIn.%s" % self.config.stack_name
        self.create_vnflcm_dir()
        self.read_state_file("pre_scale_in")
        self.ssh = self.connect_with_config()
        if not self.config.is_openstack:
            self.vcd_workaround(vcd_parser)

        if args.auto_scale_info_file:
            self.log.debug("Auto scale file: %s" % args.auto_scale_info_file)
            with open(args.auto_scale_info_file) as auto_scale_info_json_file:
                auto_scale_info_params = json.load(auto_scale_info_json_file)
                additional_info = auto_scale_info_params.get('additionalInformation', '')
                self.log.debug("argument_parsing: additional_info: '%s'" % additional_info)
                pattern = re.compile('.*CSCF Time Based Scale In: (?P<num>\\d*).*')
                match = pattern.search(additional_info)
                if match is None:
                    self.log.error("Autoscale alarm cannot be parsed")
                    self.quit_with_code(ReturnCode.REJECT)
                wanted_cluster_size = int(match.group('num'))
                cluster_size = self.config.number_of_scaled_out_vms + 2
                if cluster_size <= wanted_cluster_size:
                    self.log.error("Autoscale request to scale in to %s PLs but there are already %s PLs" %
                                   (wanted_cluster_size, cluster_size))
                    self.quit_with_code(ReturnCode.REJECT)
                self.config.scale_in_num = cluster_size - wanted_cluster_size

        self.log.debug("Parameters parsed from config: %s" % self.config)
        self.check_if_canceled(args)

    def parse_openstack_json_file(self, config_file):
        with open(config_file) as json_file:
            config_data = json.load(json_file)

        self.config = LcmTaskConfig(scale_type="GRACEFUL", specified_uuids=[], is_openstack=True)
        try:
            stack_params = config_data["stack"]["parameters"]
            self.config.stack_name = config_data["stack"]["stack_name"]
            self.config.emergency_username = stack_params["emergency_username"].strip()
            self.config.number_of_scaled_out_vms = int(stack_params[self.SCALED_NUMBER_VAR_NAME].strip())
            self.config.mip = self.get_value_or_fallback_on_match(
                stack_params["OM_IPv4_address"].strip(),
                stack_params["OM_IPv6_address"].strip(), "none")

            stack_outputs = config_data["stack"]["outputs"]
            self.config.uuids = [uuid for uuid_lists in
                                 [stack_output['output_value'].strip().split() for stack_output in stack_outputs if
                                  stack_output['output_key'] == "scaled_VMs_UUID"]
                                 for uuid in uuid_lists]
            self.config.vm_names = [name for name_lists in
                                    [stack_output['output_value'].strip().split() for stack_output in stack_outputs if
                                     stack_output['output_key'] == "scaled_VMs_name"]
                                    for name in name_lists]

        except KeyError as ex:
            self.log.error("A field is missing from the JSON file: %s" % ex)
            self.quit_with_code(ReturnCode.MISSING_JSON_PARAMETER)

    def parse_vcd_xml_file(self, config_file):
        parser = VCDXmlParser(config_file)
        v_app = parser.vnf_status_file
        v_app_name = v_app.attrib.get("name")
        if v_app_name is None:
            self.log.error("Could not fetch 'name' parameter while parsing input data")
            self.handle_config_file_error(config_file)

        self.config = LcmTaskConfig(scale_type="GRACEFUL", specified_uuids=[], is_openstack=False, parser=parser)
        self.config.stack_name = v_app_name
        self.config.emergency_username = parser.get_property("emergency_username").strip()
        self.config.mip = self.get_value_or_fallback_on_match(
            parser.get_property('OM_IPv4_address').strip(),
            parser.get_property('OM_IPv6_address').strip(), "none")
        self.config.uuids = []
        self.config.vm_names = []
        self.config.number_of_scaled_out_vms = 0
        return parser


if __name__ == '__main__':
    # C0103(invalid-name)
    # pylint: disable=C0103
    setup_default_logging()
    pre_scale_in = PreScaleIn()
    pre_scale_in.do_pre_scale_in()

from __future__ import (absolute_import, division, print_function, unicode_literals)
# ----------------------------------------------------------------------
# Package ID: CXP9034662/1
# Package Revision: R10A03
# Package Date: 2019-06-11
# ----------------------------------------------------------------------
# Copyright (C) 2019 by Ericsson Telecom AB
# S - 126 25 STOCKHOLM
# SWEDEN, tel int + 46 8 719 0000
#
# This program may be used and/or copied only with the written permission
# from Ericsson AB, or in accordance with the terms and
# conditions stipulated in the agreement/contract under which the program
# has been supplied.
#
# All rights reserved.
#
# ----------------------------------------------------------------------


import re

from common import CommonLcmTask
from imscommon.consts import ReturnCode
from lcmUtilities.lcm_decorators import skippable


class ScaleLcmBaseTask(CommonLcmTask):
    SCALED_NUMBER_VAR_NAME = "number_of_scaled_out_PL_VMs"

    def scale_in_cache_file(self):
        return "%s/scale-in_cache" % self.lcm_work_dir()

    @skippable
    def scale_in_keeping(self, keep_uuids):
        """
        This method will execute CMW scale-in commands in order to remove
        cluster members from the cluster.
        """
        pl_to_uuid = self.get_pl_name_to_uuid_dict(self.get_equipment_data())
        cmd = []
        for key in pl_to_uuid:
            if self.is_scalable_node(key) and pl_to_uuid.get(key) not in keep_uuids:
                self.log.debug("Removing PL: %s by UUID: %s" % (key, pl_to_uuid[key]))
                cmd.append("no ManagedElement=1,SystemFunctions=1,SysM=1,CrM=1,ComputeResourceRole=%s,provides" % key)

        if not cmd:
            self.log.warning("Nothing to scale in.")
            self.update_state_file("scale_in_keeping")
            return

        com_result = self.run_com_cli_command("\n".join(cmd), True)
        self.log.debug("CMW scale-in result [%s]" % com_result)

        self.update_state_file("scale_in_keeping")
        self.log.info("Executed scale-in command - waiting for VM to leave the cluster")
        self.quit_with_code(ReturnCode.REPEAT)

    @skippable
    def check_scale_in_complete(self, keep_uuids):
        """
        This method will check if CMW scale-in operation has been
        completed or not. If the scale-in PL(s) has not disappeared
        from COM CLI, it is assumed that scale-in still is ongoing.
        If scale-in is still ongoing, REPEAT exit code will be
        used.
        If the scale-in operation hasn't completed after 100 checks,
        scale-in operation is considered as failed.
        """
        pl_to_uuid = self.get_pl_name_to_uuid_dict(self.get_equipment_data())
        scaling_is_done = True
        for key in pl_to_uuid:
            if self.is_scalable_node(key) and pl_to_uuid.get(key) not in keep_uuids:
                self.log.debug("Wait scale-in complete Node [%s] is still active, must wait" % key)
                scaling_is_done = False

        if scaling_is_done:
            self.log.debug("ScaleIn hook finished")
            self.update_state_file("check_scale_in_complete")
            return

        if not self.can_iterate_step("scale_in_wait", 100):
            self.log.error("Timer expired! Scale-in failed")
            self.rm_work_dir()
            self.quit_with_code(ReturnCode.RETURN_ERROR)

        self.log.info("Scale-in VMs are still active - waiting")
        self.quit_with_code(ReturnCode.REPEAT)

    def check_crm_status(self):
        """
        This method will check if any ComputeResourceRole is in wrong status.
        If this is the case, scaling will be rejected.
        """
        crm_status = self.get_all_crm_status()
        for node, value in crm_status.items():
            if self.is_scalable_node(node):
                if value['instantiationState'] in ["INSTANTIATING", "INSTANTIATION_FAILED", "UNINSTANTIATION_FAILED"]:
                    return False
        return True

    def get_all_crm_status(self):
        """
        This method returns a hashmap/dict with node name as key (e.g. PL-3)
        and the value is a dict with adminState,instantiationState and operationalState.
        """
        cmd = "show -r -m ComputeResourceRole -p adminState,instantiationState,operationalState "
        try:
            com_result = self.run_com_cli_command(cmd, configure_mode=False)
            if com_result is None:
                self.log.error("Getting crm status failed")
                self.quit_with_code(ReturnCode.CLISS_ERROR)

            matches = re.findall(
                '^[\\w,=]+(\\w{2}-\\d+)$\\s+adminState=([\\w]+)$'
                '\\s+instantiationState=([\\w]+)$\\s+operationalState=([\\w]+)$',
                com_result,
                re.MULTILINE)
            crm_status = {}
            for match in matches:
                status = {'adminState': match[1], 'instantiationState': match[2], 'operationalState': match[3]}
                crm_status[match[0]] = status

            self.log.debug("get_all_CrM_status: CrM status [%s]" % crm_status)
            return crm_status
        except Exception as ex:
            self.log.error("get_all_CrM_status: Failed to get compute resource data: %s" % ex)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

    def check_vdicos_status(self):
        """
        This method will check if 'cdsv-get-user-state' indicates that a
        reconfiguration in DBS is ongoing.
        If this is the case, scaling will be rejected.
        """
        try:
            stdout, _, _ = self.ssh.run_command("cdsv-get-user-state", fail_at_error=False)
            m = re.findall("cluster state: Idle", stdout, re.IGNORECASE)
            return len(m) >= 2
        except Exception as ex:
            self.log.error("Failed to check VNF status")
            self.log.debug("checkVdicosStatus: Failed to get vDicos status: %s" % ex)
            self.quit_with_code(ReturnCode.RETURN_ERROR)

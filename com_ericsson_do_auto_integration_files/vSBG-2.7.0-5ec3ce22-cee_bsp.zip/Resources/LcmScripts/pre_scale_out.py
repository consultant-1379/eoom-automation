#!/usr/bin/env python

"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""
from __future__ import absolute_import, print_function
import json
import logging
import sys
import argparse
# pylint: disable=import-error
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from imscommon.parsers import OpenstackJsonParser
from scale_common import ScaleParser


# pylint: disable=missing-docstring
class VSBGPrescaleOut(object):
    def __init__(self, args):
        self.parser = argparse.ArgumentParser(description='scaling hook for workflow')
        self.mandatory = self.parser.add_argument_group('mandatory arguments')
        self.argument_parsing(args)

    def __call__(self):
        count = int(self.scaleout_num) + self.payload_instance_count
        if (count % 2) == 0 and count < 20:
            if self.is_vcd():
                output = {"number_of_vms_to_be_added": self.scaleout_num}
            else:
                output = {"payload_instance_count": str(count)}
            print(json.dumps(output))
        else:
            LOGGER.error("Invalid number of steps parameter: %r",
                         self.scaleout_num)
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)

    def is_vcd(self):
        return self.parsed_args.vnf_instance_details_file.endswith('.xml')

    def get_parser(self):
        if self.is_vcd():
            return ScaleParser.PreScaleXMLParser(self.parsed_args.vnf_instance_details_file)
        return OpenstackJsonParser(self.parsed_args.vnf_instance_details_file)

    def add_common_arguments(self):
        self.mandatory.add_argument(
            '-f', '--vnf-instance-details-file', metavar='<FILE>',
            help=('Path to the file containing the response of '
                  'stack show details (OpenStack) or vAPP details (vCloud Director) '
                  'command in json (OpenStack) or xml (vCloud Director) format.'),
            required=True)

        arg = self.parser.add_argument
        arg('-k', '--key-file', metavar='<KEY_FILE>',
            help='Path to the file containing the private key for login.')
        arg('-p', '--password-file', metavar='<PASSWORD_FILE>',
            help=('Path to the file containing the password '
                  'to login into the VNF instance.'))
        arg('-u', '--user-name', metavar='<USERNAME>',
            help='Username to login into the VNF instance')

    def argument_parsing(self, args):
        self.add_common_arguments()
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.')
        self.parser.add_argument(
            '-i', '--workflow-instance-identifier', metavar='<ID>',
            help='Workflow instance identifier.',
            required=False)
        self.parser.add_argument(
            '-x', '--aspect-id', metavar='<ASPECT_ID>',
            help='The aspect id of the scaling domain to scale.',
            required=False)
        self.parser.add_argument(
            '-l', '--auto-scale-info-file', metavar='<AUTO_SCALE_INFO_FILE>',
            help='Auto Scale information parameters.',
            required=False)
        self.parser.add_argument(
            '-n', '--number-of-steps', metavar='<STEPS>',
            help='Number of scaling steps.',
            required=True)
        self.parser.add_argument(
            '-q', '--quit-operation', metavar='<QUIT_OPERATION>',
            help='Gracefully cancels LCM script hook.',
            required=False)
        self.parsed_args = self.parser.parse_args(args)
        self.scaleout_num = self.parsed_args.number_of_steps
        self.vnf_instance_file_parser = self.get_parser()
        self.payload_instance_count = self.vnf_instance_file_parser.get_payload_instance_count()


def main():
    try:
        prescaleout = VSBGPrescaleOut(sys.argv[1:])
        prescaleout()
    except Exit as ex:
        LOGGER.error('Exiting (%d)', ex.return_code)
        sys.exit(ex.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    LOGGER = logging.getLogger('pre_scale_out')
    main()

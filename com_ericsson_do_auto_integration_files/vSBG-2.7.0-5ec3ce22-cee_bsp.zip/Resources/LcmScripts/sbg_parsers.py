#!/usr/bin/env python2

from __future__ import absolute_import

from imscommon.consts import ReturnCode
from imscommon.exceptions import Exit
from imscommon.parsers import VCDXmlParser
from imscommon.parsers import OpenstackJsonParser
from imscommon.parsers import VCDXmlParserExtended


class SBGOpenstackJsonParser(OpenstackJsonParser):

    def __init__(self, filename):
        super(SBGOpenstackJsonParser, self).__init__(filename)

    def get_oam_public_ip(self):
        try:
            obj = self.vnf_status_file["stack"]["outputs"]
            for x in obj:
                if x["output_key"] == "Output-IP":
                    return x["output_value"].strip()
        except KeyError:
            self._logger.error("Badly formatted stack details json.")
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)
        self._logger.error("Missing oam_public_ip field!")
        raise Exit(ReturnCode.MISSING_JSON_PARAMETER)


class SBGVCDXmlParser(VCDXmlParser):

    def __init__(self, filename):
        super(SBGVCDXmlParser, self).__init__(filename)

        # Additional namespaces
        VCDXmlParser.NAMESPACES['VApp'] = '{http://www.vmware.com/vcloud/v1.5}'
        VCDXmlParser.NAMESPACES['ovf'] = '{http://schemas.dmtf.org/ovf/envelope/1}'
        VCDXmlParser.NAMESPACES['vssd'] = '{http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_VirtualSystemSettingData}'
        VCDXmlParser.NAMESPACES['rasd'] = '{http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_ResourceAllocationSettingData}'

    def get_oam_public_ip(self):
        """Parses from XML response file, the OAM MIP Address

        :returns: The OAM MIP Address
        :rtype: string
        """

        try:
            oam_mip = self.get_property('Public_OAM_MIP').strip()
            if not oam_mip:
                raise ValueError('Public_OAM_MIP is blank')
        except Exception:
            oam_mip = self.get_property('OAM_MIP')

        return oam_mip

    def get_admin_username(self):
        """Parses from XML response file, the admin user name. This is the
        user that is used for ssh connections on the COM-active SC VM of SBG node

        :returns: admin user name
        :rtype: string
        """
        return self.get_property('user_name')

    def get_all_params(self):
        """Returns all values parsed by the parser in a tuple

        :returns: All parameters parsed by this parser
        :rtype: tuple
        """
        return (self.get_oam_public_ip(), self.get_admin_username(),
                self.get_vnf_name())


class SBGVCDXmlParserExtended(SBGVCDXmlParser, VCDXmlParserExtended):

    def __init__(self, filename):
        super(SBGVCDXmlParserExtended, self).__init__(filename)

    def get_grouped_networks(self):
        """
        Return the org_networks and vapp_networks in a json-like structure
        that resembles how they appear in the env-vcd.yaml file.
        Eg.:
            {
                "org_networks": {
                    "nbi":"my_org_nbi_net",
                    "vnfSignalling":"my_org_signalling_net",
                }
                "vapp_networks": [
                    {
                        "network_name": "clusterInternal",
                        "start_address": "192.168.254.100",
                        "end_address": "192.168.254.199",
                        "subnet_mask": "255.255.255.0",
                        "default_gateway": "192.168.254.1"
                    },
                ]
            }
        """
        net_configs_vapp = self._get_network_configs(self.vnf_status_file)

        # Get vapp networks that have a <ParentNetwork> node
        # (these are presumed org_networks)
        org_networks_in_vapp = []
        xpath_parent = "./vcloud:Configuration/vcloud:ParentNetwork"
        for netconf in net_configs_vapp:
            if self._findx(netconf, xpath_parent) is not None:
                org_networks_in_vapp.append(netconf.attrib["networkName"])

        vms_net = self._get_all_network_conn(self.vnf_status_file)
        vms_net_templ = self._get_all_network_conn(self.vapp_template_node)

        if len(vms_net) != len(vms_net_templ):
            self._logger.error(
                "Netconnections entry numbers do not match between "
                "vAppTemplate and vApp! Has the vApp been altered?")
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)

        self._logger.info("Get the original name for presumed org networks")

        org_networks = {}
        for vapp_conn, templ_conn in zip(
                vms_net, vms_net_templ):
            # iterating over 2 collections at once
            net_name_in_templ = templ_conn.attrib['network']
            net_name_in_vapp = vapp_conn.attrib['network']
            if net_name_in_vapp in org_networks_in_vapp:
                org_networks[net_name_in_templ] = net_name_in_vapp

        self._logger.info("Found org_networks:\n%r", org_networks)
        self._logger.info("Generate info for non-org (vapp-level) networks")
        vapp_networks = [
            self._extract_netconf_info(netconf)
            for netconf in net_configs_vapp
            if netconf.attrib["networkName"] not in org_networks_in_vapp
        ]
        self._logger.info("Found vapp_networks:\n%r", vapp_networks)

        result = {
            "org_networks": org_networks,
            "vapp_networks": vapp_networks
        }
        self._logger.debug("Network data:\n%r", result)

        return result

    def _get_all_network_conn(self, node):
        vms = self._findallx(node, "./vcloud:Children/vcloud:Vm")
        vms_net_conn = []
        for vm in vms:
            net_conns = VCDXmlParserExtended._findallx(
                vm, "./vcloud:NetworkConnectionSection/vcloud:NetworkConnection")
            if len(net_conns) > len(vms_net_conn):
                vms_net_conn = net_conns

        def get_idx(node):
            return int(
                VCDXmlParserExtended._findx(
                    node, "./vcloud:NetworkConnectionIndex").text)
        vms_net_conn.sort(key=get_idx)

        return vms_net_conn

#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import sys
import json
import logging
import re
import datetime

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from scale_common import ScaleInHook, ME_CLISS_PATTERN


logger = logging.getLogger('prescalein')


def mkcmd(*parts):
    """ Create an escaped command line from its parts """
    return ' '.join("'{0}'".format(p) for p in parts)


class PreScaleIn(ScaleInHook):

    def __init__(self):
        super(PreScaleIn, self).__init__()
        self.vcd_vm_mapping = None
        PreScaleIn.validate_input(self.input_data)

    def __call__(self):
        if not self.check_connection():
            logger.info('SSH connection is not available yet.')
            print('Waiting for SSH connection')
            raise Exit(ReturnCode.REPEAT)
        self.create_vnflcm_dir_if_missing()
        self.pre_health_check()
        self.mps_to_be_scaled, self.names_to_be_scaled = self.get_scale_in_data()
        logger.info('mps_to_be_scaled: %s', self.mps_to_be_scaled)
        logger.info('names_to_be_scaled: %s', self.names_to_be_scaled)

        if len(self.mps_to_be_scaled) > 0:
            if self.shutdown_type == 'GRACEFUL':
                self.graceful_lock_mated_pair(self.admin_username)
                self.wait_for_matedpair_status()
            elif self.shutdown_type == 'FORCEFUL':
                self.forceful_lock_mated_pair(self.admin_username)
        return self.dump_scaling_list_output_json()

    def pre_health_check(self):
        logger.info("start to do pre health check")
        command = ['show -r -m FmAlarm']
        result = self.cli.run_cli_remote(self.cli.build_cliss_script(command))
        lines = result.strip().splitlines()

        for text in lines:
            if text.strip() == 'specificProblem="SBG, Charging Server Rejects Charging Data"':
                logger.error("There is a vSBG charging alarm, please cease the alarm first")
                raise Exit(ReturnCode.RETURN_ERROR)

    def save_scale_in_data(self):
        scale_in_data_file = self.path('SCALE_IN_DATA_FILE')
        scale_in_data = {
            'names_scaled': self.names_to_be_scaled,
            'mps_affected': self.mps_to_be_scaled,
        }
        cmd = str.format(
            '''cat > '{}' << 'EOF'\n{}\nEOF''',
            scale_in_data_file, json.dumps(scale_in_data),
        )
        logger.info('Saving scale-in data to %s', scale_in_data_file)
        self.ssh.run_command(cmd, fail_at_error=True)

    def dump_scaling_list_output_json(self):
        self.save_scale_in_data()
        if self.is_vcd():
            self.dump_scaling_list_output_json_vcd()
        else:
            self.dump_scaling_list_output_json_os()

    def dump_scaling_list_output_json_os(self):
        icount = len(self.uuids) - self.number_of_steps
        if self._get_pair_policy() == 'RANDOM_PAIR':
            index = [
                PreScaleIn.get_index(resource_name)
                for resource_name in self.names_to_be_scaled
            ]
            output = {
                "payload_instance_count": str(icount),
                "payload_scaling_in_list": ','.join(index),
            }
            print(json.dumps(output))
        if self._get_pair_policy() == 'FIXED_PMP_GROUP':
            output = {
                "payload_instance_count": str(icount),
            }
            print(json.dumps(output))

    def dump_scaling_list_output_json_vcd(self):
        # keep compatibility with older workflows
        # by adding the namespace prefix:
        def add_prefix(uuid):
            return 'urn:vcloud:vm:{}'.format(uuid)

        vcd_uuids = [self.get_vcd_uuid_for_cluster_name(i) for i in self.names_to_be_scaled]
        output = {
            "number_of_vms_to_be_removed": str(self.input_data.number_of_steps),
            "vmuuids_to_remove": [add_prefix(u) for u in vcd_uuids]
        }

        print(json.dumps(output))

    def wait_for_matedpair_status(self):
        logger.info('Waiting for scale in')
        admin_status = self.read_adm_status(self.admin_username)
        logger.info('admin_status: %s', admin_status)
        if self.check_matedpair_locked(list(admin_status)[0]):
            return True
        else:
            if self.shutting_down_timeout == -1:
                logger.info('Waiting for mated pair locked without time limitation.')
                print('Waiting for mated pair locked without time limitation.')
                raise Exit(ReturnCode.REPEAT)
            start = self._get_time()
            start_time = datetime.datetime.fromtimestamp(float(start))
            current, _, _ = self.ssh.run_command('date +%s')
            current_time = datetime.datetime.fromtimestamp(float(current.strip()))
            duration = (current_time - start_time).seconds
            if duration < self.shutting_down_timeout:
                print('Waiting for mated pair locked')
                raise Exit(ReturnCode.REPEAT)
            else:
                raise Exit(ReturnCode.RETURN_ERROR)

    def check_matedpair_locked(self, status):
        """
        check admin status returned from function read_adm_status,
        input status format: ("{1: 'LOCKED'}\n", '', 0)
        """
        if len(status) == 3 and status[2] == 0:
            regex = re.compile(r'\'[a-zA-Z]+\'', re.I)
            statuslist = regex.findall(status[0])
            if len(statuslist) == 0:
                logger.info("No Mated Pair!")
                raise Exit(ReturnCode.RETURN_ERROR)
            else:
                for item in statuslist:
                    if item != "'LOCKED'":
                        logger.error('Mated Pair is not LOCKED')
                        return False
                logger.info('All mated pair is LOCKED')
                return True
        else:
            logger.error('Status input error!')
            return False

    def read_adm_status(self, username):
        result = {self.ssh.run_command(
            str.format(
                "/opt/imex/mated_pair_util.py "
                "--user '{0}' "
                "--getadmstat {1}",
                username,
                int(id)))
            for id in self.mps_to_be_scaled}
        return result

    def _check_starttimefile(self):
        _, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f', self.path('START_TIME_FILE')),
                                 fail_at_error=False)
        if retcode == 0:
            return True
        else:
            logger.error('Get start time file error: %s', stderr)
        return None

    def _get_time(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat', self.path('START_TIME_FILE')),
                                 fail_at_error=False)
        if retcode == 0:
            ret = stdout.strip()
            return ret
        else:
            logger.error('Get start time error: %s', stderr)
        return None

    def graceful_lock_mated_pair(self, username):
        try:
            for _id in self.mps_to_be_scaled:
                self.ssh.run_command(
                    str.format(
                        "/opt/imex/mated_pair_util.py "
                        "--user '{0}' "
                        "--gracefullock {1}",
                        username,
                        int(_id)))
            if not self._check_starttimefile():
                start, _, _ = self.ssh.run_command('date +%s')
                self.ssh.run_command(
                    str.format(
                        "echo '{0}' > '{1}'",
                        start.strip(),
                        self.path('START_TIME_FILE')))
        except Exception:
            logger.error('Graceful lock is unsuccessful')
            print('Graceful lock is unsuccessful')
            raise Exit(ReturnCode.REPEAT)
        return True

    def forceful_lock_mated_pair(self, username):
        try:
            for _id in self.mps_to_be_scaled:
                self.ssh.run_command(
                    str.format(
                        "/opt/imex/mated_pair_util.py "
                        "--user '{0}' "
                        "--forcedlock {1}",
                        username,
                        int(_id)))
        except Exception:
            logger.error('Forceful lock is unsuccessful')
            print('Forceful lock is unsuccessful')
            raise Exit(ReturnCode.REPEAT)
        return True

    def create_vnflcm_dir_if_missing(self):
        """Check if the directory exists first.
        If not, create it and place the workflow id in it.
        Otherwise, check what instance_id it contains:
          - in case the instance_id matches the current one, this is a REPEAT,
            there is nothing to do
          - in case it does not match, delete the folder and remake a new one;
            it must be leftover junk from a previous scaling operation.
        """
        vnflcm_dir = self.path('VNFLCM_DIR')
        instance_id_filepath = self.path('INSTANCE_ID_FILE')
        try:
            _, _, dir_exists = self.ssh.run_command(
                "test ! -d '{}'".format(vnflcm_dir), fail_at_error=False)
            if dir_exists:
                stdout, _, _ = self.ssh.run_command(
                    "cat '{}' || :".format(instance_id_filepath))
                previous_instance_id = stdout.strip()
                if (previous_instance_id.lower() ==
                        self.workflow_instance_identifier.lower()):
                    # this is a REPEAT of the LCM hook that has been running
                    return
                logger.warning(
                    """Instance id in file %s does not match current one:
file: '%s' vs. current: '%s'""",
                    instance_id_filepath, previous_instance_id,
                    self.workflow_instance_identifier)
                logger.info("Cleaning up folder.")
                self.ssh.run_command("rm -rf '{}'".format(vnflcm_dir))

            self.ssh.run_command("mkdir '{}'".format(vnflcm_dir))
            self.ssh.run_command(str.format(
                "cat >> '{}' << 'EOF'\n{}\nEOF",
                instance_id_filepath, self.workflow_instance_identifier))
        except Exit:
            raise
        except Exception:
            logger.exception('Failed to create/check dir %r', self.path('VNFLCM_DIR'))
            raise Exit(ReturnCode.RETURN_ERROR)

    def _get_managed_element_data(self):
        command = ['show -r -m ComputeResource', 'show -r -m PayloadProcessor']
        op = self.cli.run_cliss_remote(command)
        logger.info(
            'Command: %s, cliss response: %s', command, op
        )
        lines = op.strip().splitlines()
        me_indexes = [
            idx for idx in range(len(lines))
            if re.match(ME_CLISS_PATTERN, lines[idx])
        ]
        logger.debug("me_indexes: %s", me_indexes)
        if not me_indexes:
            logger.error(
                'No managed element entries found in cliss response!',
            )
            raise Exit(ReturnCode.PARSE_ERROR)
        managed_elements = []
        for idx in range(len(me_indexes)):  # pylint: disable=C0200
            me_start = me_indexes[idx]
            me_end = (
                me_indexes[idx + 1] if idx < len(me_indexes) - 1
                else len(lines)
            )
            logger.debug("me_start: %s, me_end: %s", me_start, me_end)
            managed_elements.append(lines[me_start:me_end])
        logger.debug(
            "managed_elements:\n%s",
            '\n++++++++++++\n'.join('\n'.join(l) for l in managed_elements)
        )
        return managed_elements

    def _get_me_values(self, me_lines):
        macs = []
        uuid = None
        entry_regexp = re.compile(
            '^ *"(?P<mac>'
            '[A-Fa-f0-9]{2}(:[A-Fa-f0-9]{2}){5}'
            ')" *$'
            '|'
            '^ *uuid="(?P<uuid>'
            '[0-9A-Fa-f]{8}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{4}-?[0-9A-Fa-f]{12}'
            ')" *$'
        )
        # this is assumed to always match because
        # the input is generated by _get_managed_element_data:
        name_pl = re.match(ME_CLISS_PATTERN, me_lines[0]).group('name_pl')
        if name_pl:
            _id = re.match(ME_CLISS_PATTERN, me_lines[0]).group('id')
            return name_pl, _id

        me_name = re.match(ME_CLISS_PATTERN, me_lines[0]).group('name')
        for line in me_lines[1:]:
            entry_match = re.match(entry_regexp, line)
            if not entry_match:
                logger.debug(
                    ("Line in me_data did not match anything "
                     "being looked for: '%s'"), line
                )
            elif entry_match.group('mac'):
                macs.append(entry_match.group('mac'))
            elif entry_match.group('uuid'):
                uuid = entry_match.group('uuid')
        return me_name, uuid, macs

    def get_all_data(self):
        retcrs = {}
        for me_data in self._get_managed_element_data():
            res = self._get_me_values(me_data)
            if len(res) == 3:
                name, uuid, macs = res
                logger.info(
                    'Managed element (%s) data - uuid: %s, macs: %s',
                    name, uuid, macs
                )
                if not all([name, macs, uuid]):
                    logger.error(
                        'Managed element missing macs or uuid or name!',
                    )
                    raise Exit(ReturnCode.PARSE_ERROR)
                if retcrs.get(name) is not None:
                    retcrs[name]['uuid'] = uuid
                    retcrs[name]['macs'] = macs
                else:
                    retcrs[name] = {'uuid': uuid, 'macs': macs}
            if len(res) == 2:
                name, mpid = res
                logger.info(
                    'Managed element (%s) data - matedpair id: %s',
                    name, mpid
                )
                if not all([name, mpid]):
                    logger.error(
                        'Managed element missing matedpair id or name!',
                    )
                    raise Exit(ReturnCode.PARSE_ERROR)
                if retcrs.get(name) is not None:
                    retcrs[name]['mpid'] = mpid
                else:
                    retcrs[name] = {'mpid': mpid}

        entry_regexp = '.+PL-[0-9]+$'
        for name in list(retcrs.keys()):
            if retcrs[name].get('mpid') is None:
                retcrs[name]['mpid'] = 'none'
            pl_postfix = re.match(entry_regexp, name)
            if not pl_postfix:
                del retcrs[name]

        PreScaleIn.compare_preferred_uuids(retcrs, self.input_data.preferred_uuids)
        if self.is_vcd():
            PreScaleIn.compare_macs(
                retcrs, self.vnf_instance_file_parser.get_pl_mac_addresses())
            self.vcd_vm_mapping = self.map_vcd_data_to_cluster(retcrs)
        else:
            PreScaleIn.compare_uuids(retcrs, self.input_data.uuids)

        return retcrs

    def map_vcd_data_to_cluster(self, retcrs):
        '''
        Create a map structure from which vCD uuid can be obtained
        using BIOS uuids and vice versa. Do this via associating them
        with MAC addresses. All of these should be unique at least within
        the vApp.
        '''
        vcd_mac_dict = dict([
            # parser returns xml node objects, extract actual mac addr:
            (k.text.lower(), v)
            for (k, v)
            in self.vnf_instance_file_parser.get_mac_to_vm_name_dict().items()
            # only if the key is an actual mac addr:
            if re.match('[A-Fa-f0-9]{2}(:[A-Fa-f0-9]{2}){5}', k.text)
        ])

        vcd_name_id_dict = self.vnf_instance_file_parser.get_vm_name_to_id_dict()
        # strip namespace prefix from ids:
        for k in vcd_name_id_dict:
            vcd_name_id_dict[k] = vcd_name_id_dict[k].split(':')[-1]

        mapping = {}
        for vm_cluster_name in retcrs:
            vm = retcrs[vm_cluster_name]
            vm_mac1 = vm['macs'][0].lower()  # MAC addresses should be unique
            if vm_mac1 not in vcd_mac_dict:
                logger.error('Could not find VM in vCD data with mac %s', vm_mac1)
                raise Exit(ReturnCode.DATA_ERROR)

            vm_name_vcd = vcd_mac_dict[vm_mac1]
            vm_uuid_vcd = vcd_name_id_dict[vm_name_vcd]

            vm_dict = {}
            vm_dict['cluster_uuid'] = vm['uuid']
            vm_dict['vcd_uuid'] = vm_uuid_vcd
            vm_dict['cluster_name'] = vm_cluster_name
            vm_dict['cluster_macs'] = vm['macs']
            vm_dict['vcd_macs'] = [
                k for k in vcd_mac_dict if vcd_mac_dict[k] == vm_name_vcd
            ]

            mapping[vm_name_vcd] = vm_dict

        return mapping

    def get_vcd_uuid_for_cluster_name(self, cluster_name):
        for vm_name in self.vcd_vm_mapping:
            vm_data = self.vcd_vm_mapping[vm_name]
            if vm_data['cluster_name'] == cluster_name:
                return vm_data['vcd_uuid']

        logger.error(
            'Cluster (%s) could not be mapped to any vCD uuid!', cluster_name)
        raise Exit(ReturnCode.REJECT)

    def get_scale_in_data(self):
        retcrs = self.get_all_data()
        pair_policy = self._get_pair_policy()
        if pair_policy == 'RANDOM_PAIR':
            return self.scale_in_data_all_pls(retcrs)
        elif pair_policy == 'FIXED_PMP_GROUP':
            return self.scale_in_data_pmp(retcrs)

        logger.error("Unknown pair policy: %s", pair_policy)
        raise Exit(ReturnCode.DATA_ERROR)

    def scale_in_data_all_pls(self, retcrs):
        pmps = [i for i in retcrs.items() if i[1]['mpid'] != 'none']
        nonpmps = [i for i in retcrs.items() if i[1]['mpid'] == 'none']
        sort_pmps = sorted(pmps, key=lambda d: int(d[1]['mpid']), reverse=True)
        sort_nonpmps = sorted(nonpmps, key=lambda d: d[0], reverse=True)
        sort_retcrs = sort_nonpmps + sort_pmps
        if not self.input_data.preferred_uuids:
            return self.scale_data_all_pls_no_uuids(sort_retcrs)
        else:
            return self.scale_data_all_pls_with_uuids(sort_retcrs)

    def scale_data_all_pls_no_uuids(self, sort_retcrs):
        scale_in = sort_retcrs[:self.number_of_steps]
        names = [i[0] for i in scale_in]
        mpids = [i[1]['mpid'] for i in scale_in if i[1]['mpid'] != 'none']
        return mpids[::2], names

    def scale_data_all_pls_with_uuids(self, sort_retcrs):
        names = [i[0] for i in sort_retcrs]
        mpids = [i[1]['mpid'] for i in sort_retcrs]
        uuids = [i[1]['uuid'] for i in sort_retcrs]
        preferred_mpids = []
        preferred_names = []
        unpreferred_mpids = list(mpids)
        unpreferred_names = list(names)
        for puuid in self.input_data.preferred_uuids:
            idx = uuids.index(puuid)
            if mpids[idx] != 'none':
                while mpids[idx] in unpreferred_mpids:
                    _id = unpreferred_mpids.index(mpids[idx])
                    preferred_mpids.append(unpreferred_mpids[_id])
                    preferred_names.append(unpreferred_names[_id])
                    unpreferred_mpids.remove(unpreferred_mpids[_id])
                    unpreferred_names.remove(unpreferred_names[_id])
            else:
                _id = unpreferred_names.index(names[idx])
                preferred_mpids.append(unpreferred_mpids[_id])
                preferred_names.append(unpreferred_names[_id])
                unpreferred_mpids.remove(unpreferred_mpids[_id])
                unpreferred_names.remove(unpreferred_names[_id])
        if len(preferred_names) > self.number_of_steps:
            logger.error("Invalid preferred uuids: invalid for all payloads anti-affinity")
            raise Exit(ReturnCode.RETURN_ERROR)
        if len(preferred_names) == self.number_of_steps:
            scale_in_mpids = list(set(preferred_mpids))
            scale_in_mpids = [i for i in scale_in_mpids if i != 'none']
            return scale_in_mpids, preferred_names
        num = self.number_of_steps - len(preferred_names)
        scale_in_mpids = list(set(preferred_mpids + unpreferred_mpids[:num]))
        scale_in_mpids = [i for i in scale_in_mpids if i != 'none']
        scale_in_names = preferred_names + unpreferred_names[:num]
        return scale_in_mpids, scale_in_names

    def scale_in_data_pmp(self, retcrs):
        sort_retcrs = sorted(retcrs.items(), key=lambda d: d[0], reverse=True)
        scale_in = sort_retcrs[:self.number_of_steps]
        scale_in_uuids = [i[1]['uuid'] for i in scale_in]
        preferred_not_in_scale = list(self.input_data.preferred_uuids)
        for i in self.input_data.preferred_uuids:
            if i in scale_in_uuids:
                preferred_not_in_scale.remove(i)
        if len(preferred_not_in_scale) > 0:
            logger.error("Invalid preferred uuids: invalid for pmp anti-affinity")
            raise Exit(ReturnCode.RETURN_ERROR)
        names = [i[0] for i in scale_in]
        mpids = [i[1]['mpid'] for i in scale_in if i[1]['mpid'] != 'none']
        return mpids[::2], names

    @staticmethod
    def get_index(resource_name):
        regex = r".*-([0-9]+)$"
        matches = re.search(regex, resource_name)
        if matches is None:
            logger.error("Could not find index of VM with name '%s'", resource_name)
            raise Exit(ReturnCode.DATA_ERROR)
        logger.debug("Getting index of %s. Index is: %s", resource_name, matches.group(1))
        return matches.group(1)

    @staticmethod
    def compare_preferred_uuids(cluster, preferred_uuids):
        uuids = [cluster[vm_data]['uuid'] for vm_data in cluster]
        ids_not_in_preferred = [
            _id
            for _id in preferred_uuids
            if _id not in uuids
        ]

        if len(ids_not_in_preferred) > 0:
            logger.error("---> Don't know about preferred VMs %s", ids_not_in_preferred)
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    @staticmethod
    def compare_uuids(cluster, vim_uuids):
        ids_not_in_cluster = list(vim_uuids)
        ids_not_in_vim = []
        for name in cluster:
            uuid = cluster[name]['uuid']
            if uuid in ids_not_in_cluster:
                ids_not_in_cluster.remove(uuid)
            else:
                ids_not_in_vim.append(uuid)
        cardinality_mismatch = False
        if len(ids_not_in_cluster) > 0:
            logger.error("---> Cluster doesn't know about these VMs: %s", ids_not_in_cluster)
            cardinality_mismatch = True
        if len(ids_not_in_vim) > 0:
            logger.error("---> VIM doesn't know about VMs %s", ids_not_in_vim)
            cardinality_mismatch = True
        # raise separately to log all errors
        if cardinality_mismatch:
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    @staticmethod
    def compare_macs(cluster_vms, vim_pl_macs):
        def lower_macs(mac_list):
            return [m.lower() for m in mac_list]

        def remove_cluster_vm_macs_from_vim_macs(cl_vm_macs, vim_macs):
            for vim_vm_macs in vim_macs:
                if set(cl_vm_macs).issubset(set(lower_macs(vim_vm_macs))):
                    vim_macs.remove(vim_vm_macs)
                    return True

            return False

        vms_unknown_to_vim = []
        for vm_data in cluster_vms:
            logger.debug("vmdata: %s", vm_data)
            cluster_vm_macs = lower_macs(cluster_vms[vm_data]['macs'])
            found_current = remove_cluster_vm_macs_from_vim_macs(
                cluster_vm_macs, vim_pl_macs)
            if not found_current:
                vms_unknown_to_vim.append(vm_data)

        cardinality_mismatch = False
        if vms_unknown_to_vim:
            logger.error("---> VIM doesn't know about these VMs: %s",
                         vms_unknown_to_vim)
            cardinality_mismatch = True

        if len(vim_pl_macs) != 0:
            logger.error("---> Cluster doesn't know about these VMs: %s",
                         vim_pl_macs)
            cardinality_mismatch = True

        if cardinality_mismatch:
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    @staticmethod
    def validate_input(input_data):
        PreScaleIn.check_empty_data(input_data)
        PreScaleIn.check_number_of_steps(input_data)
        PreScaleIn.check_resource_cardinality(input_data)
        PreScaleIn.check_preferred_uuids(input_data)
        logger.info("the params parsed from json is: (%s)",
                    (input_data.admin_username,
                     input_data.sc_ip,
                     input_data.number_of_steps,
                     input_data.uuids,
                     input_data.resource_names))

    @staticmethod
    def check_empty_data(input_data):
        data = (input_data.admin_username,
                input_data.sc_ip,
                input_data.number_of_steps,
                input_data.uuids,
                input_data.resource_names)
        if any(x is None for x in data):
            logger.error('not all params parsed from json: %s', data)
            raise Exit(ReturnCode.PARSE_ERROR)

    @staticmethod
    def check_number_of_steps(input_data):
        if input_data.number_of_steps >= len(input_data.resource_names):
            logger.error(
                "Error: step number (%d) larger or equal than resource count (%d)",
                input_data.number_of_steps,
                len(input_data.resource_names),
            )
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)
        if (input_data.number_of_steps % 2) == 1:
            logger.error("Invalid odd step number: %d",
                         input_data.number_of_steps)
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)
        if input_data.number_of_steps < len(input_data.preferred_uuids):
            logger.error(
                "Error: step number (%d) smaller than preferred uuids count (%d)",
                input_data.number_of_steps,
                len(input_data.preferred_uuids),
            )
            raise Exit(ReturnCode.INVALID_STEP_NUMBER)

    @staticmethod
    def check_resource_cardinality(input_data):
        mismatch = (
            len(input_data.uuids) != len(input_data.resource_names)
        )
        if mismatch:
            logger.error(
                ("Resource name counts do not match! "
                 "Resource name count: %d "
                 "UUID count: %d "),
                len(input_data.resource_names),
                len(input_data.uuids)
            )
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)

    @staticmethod
    def check_preferred_uuids(input_data):
        if len(input_data.preferred_uuids) != len(set(input_data.preferred_uuids)):
            logger.error("---> preferred VMs have duplicates")
            raise Exit(ReturnCode.RESOURCE_CARDINALITY_MISMATCH)


def main():
    try:
        pre_scale_in = PreScaleIn()
        pre_scale_in()
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    main()

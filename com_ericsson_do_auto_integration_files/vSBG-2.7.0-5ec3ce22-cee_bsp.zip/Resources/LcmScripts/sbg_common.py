#!/usr/bin/env python

import logging
import os
import sys
import paramiko
import argparse
from imscommon import SSHUtility
from imscommon.consts import ReturnCode
from imscommon.exceptions import Exit

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
    stream=sys.stderr)
logger = logging.getLogger('CommonLcmTask')


def mkcmd(*parts):
    """ Create an escaped command line from its parts """
    return ' '.join("'{0}'".format(p) for p in parts)


class JobType(object):
    FG = 0
    BG = 1


_SSH_CONNECTION_TIMEOUT_SECONDS = 30
_SSH_SESSION_TIMEOUT_SECONDS = 85


class SBGSSHUtility(SSHUtility.SSHUtility):

    def connect(self, connection_timeout=_SSH_CONNECTION_TIMEOUT_SECONDS):
        self.logger.info(
            ("Connecting to IP: %s with username: %s at port: %s "
             "keep_alive: %u connection timeout %ss"),
            self.ip, self.username, self.port, self.keep_alive,
            connection_timeout
        )

        try:
            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect(self.ip,
                             timeout=connection_timeout,
                             username=self.username,
                             password=self.password,
                             key_filename=self.key_filename,
                             port=self.port,
                             )

            self.logger.info("Connected to SSH port of IP: %s.", self.ip)
        except paramiko.BadHostKeyException:
            self.logger.exception(
                "Could not connect to the SSH port of IP: %s:", self.ip)
            raise
        except paramiko.AuthenticationException:
            self.logger.exception(
                "Could not connect to the SSH port of IP: %s:", self.ip)
            raise
        except paramiko.SSHException:
            self.logger.exception(
                "Could not connect to the SSH port of IP: %s:", self.ip)
            raise
        except RuntimeError:
            self.logger.exception("SSH Connection failed:")
            raise

    @SSHUtility.with_ssh
    def run_command(self,
                    command,
                    fail_at_error=True,
                    timeout_seconds=_SSH_SESSION_TIMEOUT_SECONDS):
        """Note: exec_command will raise socket.timeout if a blocking
        read/write operationtakes longer than `timeout_seconds`."""
        self.logger.debug("'cmd: %s'", command)
        try:
            _stdin, stdout, stderr = self.ssh.exec_command(
                command, timeout=timeout_seconds
            )
            out = stdout.read()
            err = stderr.read()
            ret = stdout.channel.recv_exit_status()
            self.logger.debug("Return code: %d", ret)
            self.logger.debug('stdout: %s', out)

            if ret != 0 and fail_at_error:
                self.logger.error("Command failed with exit status %d (%s)",
                                  ret, command)
                self.logger.debug('stderr: %s', err)
                raise RuntimeError("Command failed ", ret, command, out, err)

            return out, err, ret
        except:
            self.logger.exception("SSH Connection failed:")
            raise


class CommonLcmTask(object):

    def __init__(self, workflow_name=None):
        self.ssh = None
        self.state = None
        self.workflow_name = workflow_name

    def add_common_arguments(self, description):
        self.parser = argparse.ArgumentParser(description=description)
        self.mandatory = self.parser.add_argument_group('mandatory arguments')
        self.mandatory.add_argument('-f', '--vnf-instance-details-file', metavar='<FILE>',
                                    help='Path to the file containing the response of stack show details command in json format.',
                                    type=str, required=True)
        self.parser.add_argument('-k', '--key-file', metavar='<KEY_FILE>',
                                 help='Path to the file containing the private key for login.',
                                 type=str)
        self.parser.add_argument('-p', '--password-file', metavar='<PASSWORD_FILE>',
                                 help=' Path to the file containing the password to login into the VNF instance.',
                                 type=str)
        self.parser.add_argument('-u', '--user-name', metavar='<USERNAME>',
                                 help='Username to login into the VNF instance',
                                 type=str)

    def connect_to_host(self, ip, username, password, key_filename, port=22):
        return SBGSSHUtility(
            ip=ip,
            username=username,
            port=port,
            password=password,
            key_filename=key_filename,
            keep_alive=True)

    def check_connection(self, ssh):
        try:
            ssh.run_command('w')
        except paramiko.AuthenticationException:
            logger.error('SSH Authentication failed')
            raise Exit(ReturnCode.RETURN_ERROR)
        except Exception:
            logger.error('Failed to execute remote command')
            return False
        else:
            return True

    def path(self, name, admin_username, instance_id):
        wf_dir = os.path.join('/storage', 'vnflcm_workflow')
        if instance_id is None:
            vnflcm_dir = wf_dir
        else:
            vnflcm_dir = os.path.join(wf_dir, instance_id)
        return {
            'VNFLCM_DIR':
                vnflcm_dir,
            'STATE_FILE':
                os.path.join(vnflcm_dir, 'wf_state'),
            'RET_FILE':
                os.path.join(vnflcm_dir, 'job.ret'),
            'OUT_FILE':
                os.path.join(vnflcm_dir, 'job.out'),
            'ERR_FILE':
                os.path.join(vnflcm_dir, 'job.err'),
            'START_FILE':
                os.path.join(vnflcm_dir, 'job.started'),
            'RESTART_NODE':
                os.path.join(vnflcm_dir, 'job.restart')}[name]

    def create_vnflcm_dir(self, admin_username, instance_id):
        try:
            self.ssh.run_command(
                str.format(
                    "if [ ! -d '{0}' ]; then "
                    "  sudo mkdir -p -m 777 '{0}' && sudo chmod -R 777 '{1}'; "
                    "fi",
                    self.path('VNFLCM_DIR', admin_username, instance_id), self.path('VNFLCM_DIR', admin_username, None)))
        except:
            logger.exception('Failed to create dir %r',
                             self.path('VNFLCM_DIR',
                                       admin_username,
                                       instance_id))
            raise Exit(ReturnCode.RETURN_ERROR)

    def read_state_file(self, admin_username, instance_id):
        stdout, _stderr, retcode = \
            self.ssh.run_command(mkcmd('cat',
                                       self.path('STATE_FILE',
                                                 admin_username,
                                                 instance_id)),
                                 fail_at_error=False)
        self.state = stdout.strip() if retcode == 0 else ''

    def read_adm_status(self, username):
        return self.ssh.run_command(
            str.format(
                "/opt/imex/mated_pair_util.py "
                "--user '{0}' "
                "--getadmstat",
                username))

    def rm_file(self, file_):
        self.ssh.run_command(mkcmd('rm', '-f', file_),
                             fail_at_error=False)

    def get_cloud_type(self, vnf_instance_details_file):
        if vnf_instance_details_file.endswith('.json'):
            return 'OPENSTACK'
        if vnf_instance_details_file.endswith('.xml'):
            return 'VMWARE'
        logger.error(
            'Instance details file is unknown type (%s).',
            vnf_instance_details_file)
        raise Exit(ReturnCode.PARSE_ERROR)

#!/usr/bin/env python
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import sys
import logging

import heal_common

from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode


logger = logging.getLogger('postheal')


class PostHeal(heal_common.HealHook):

    def __call__(self):
        '''
        In case of single SC healing, run the SC health checks.
        In other cases (dual SC, PL or manual heal),
        check VM operational state.
        '''
        self._parse_input_data_files()

        self.uuid_to_be_healed, self.name_to_be_healed = self.get_uuid_and_name_to_heal()
        self.vm_health_check()

    def vm_health_check(self):
        logger.info('Checking VM health after heal')

        health_check_error = self.get_health_error()

        if health_check_error is None:
            logger.info('VM is considered healthy')
            return

        print('VM health is not ok: {}. Waiting.'.format(
            health_check_error))
        raise Exit(ReturnCode.REPEAT)

    def check_health_in_cmw(self, cmw_status, name):
        try:
            for i in range(0, len(cmw_status), 3):
                if name in cmw_status[i] and 'OperState=ENABLED' in cmw_status[i + 2]:
                    logger.info('%s is ENABLED in CoreMW, therefore considered healthy', name)
                    return None
        except Exception:
            logger.error('Error in CoreMW output')
            raise Exit(ReturnCode.PARSE_ERROR)

        return '{} is either not found or DISABLED in CoreMW'.format(name)


def main():
    args = heal_common.argument_parsing()
    try:
        post_heal = PostHeal(args)
        post_heal()
    except Exit as e:
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    main()

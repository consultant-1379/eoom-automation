#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import os
import re
import json
import logging
import argparse
import socket

from imscommon.SSHUtility import SSHUtility
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode


logger = logging.getLogger('heal_common')


def argument_parsing():
    parser = argparse.ArgumentParser("pre_healing hook for workflow")
    arg = parser.add_argument
    arg('-f', '--vnf-instance-details-file', metavar='<FILE>',
        help='Path to the file containing the response of stack show '
             'details command in json format.',
        required=True)
    arg('-l', '--auto-healing-info-file',
        metavar='<AUTO_HEALING_INFO_FILE>',
        help='Auto Healing information parameters.')
    arg('-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
        help='All additional parameters.')
    arg('-p', '--password-file', metavar='<PASSWORD_FILE>',
        help=('Path to the file containing the password '
              'to login into the VNF instance.'),
        type=str, required=False)
    arg('-k', '--key-file', metavar='<KEY_FILE>',
        help='SSH public key', type=str, required=False)
    arg('-u', '--user-name', metavar='<USERNAME>',
        help='user name', type=str, required=False)
    arg('-i', '--workflow-instance-identifier', metavar='<ID>',
        help='Workflow instance identifier.',
        required=False)

    return parser.parse_args()


def load_json_file(path):
    if not os.path.isfile(path):
        logger.error('Input file %s missing!', path)
        raise Exit(ReturnCode.INVALID_JSON)
    try:
        with open(path) as json_file:
            return json.load(json_file)
    except ValueError:
        logger.error("Input JSON file is invalid: %s ", path)
        raise Exit(ReturnCode.PARSE_ERROR)


class SSHErrorResult:
    def __init__(self, exception):
        self.exception = exception

    def __str__(self):
        if isinstance(self.exception, RuntimeError):
            return 'failed to execute a command'
        if isinstance(self.exception, socket.error):
            return str.format(
                'socket error on connection ({msg})',
                msg=getattr(self.exception, 'strerror', 'unknown error'))
        return str.format(
            'ssh connection failed ({extype})',
            extype=self.exception.__class__.__name__)


class HealHook(object):
    SINGLE_SC_HEAL_SUPPORTED_ALARM_TYPES = ['heartbeat failure']
    # Dual SC and PL will use this alarm
    OTHER_HEAL_SUPPORTED_ALARM_TYPES = ['com sa, clm cluster node unavailable']

    OUTPUT_KEY_NOT_FOUND = object()
    MANAGED_ELEMENT_ID_PATTERN = r'^ManagedElement=(?P<mo_id>.*)$'
    CLISS_ERROR_PATTERN = r'^ERROR:(?P<error_text>.*)$'

    CLISS_SCRIPT_WRAPPER = """timeout 30s /opt/com/bin/cliss -sb << 'ENDOFCLISSCMD'
{cliss_script}
exit
ENDOFCLISSCMD
"""

    class Mode(object):
        MANUAL_HEAL = 0
        AUTO_HEAL_SINGLE_SC = 1
        AUTO_HEAL_DUAL_SC = 2
        AUTO_HEAL_PL = 3

    def __init__(self, args):
        self.args = args
        self.ssh = None
        self.vnf_instance_data = None
        self.additional_params = None
        self.auto_healing_info = None
        self.healing_type = None

    def _init_ssh_connection(self):
        sc_ip = self._get_stack_output('Output-IP', as_str=True)
        if sc_ip is self.OUTPUT_KEY_NOT_FOUND:
            logger.error('The O&M IP address is missing from stack details!')
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)
        om_username = self._get_stack_param("admin_username")
        self.ssh = SSHUtility(
            ip=sc_ip,
            username=om_username,
            password=self.args.password_file,
            key_filename=self.args.key_file,
            keep_alive=True,
        )

    def _parse_input_data_files(self):
        self.vnf_instance_data = load_json_file(
            self.args.vnf_instance_details_file)
        self.additional_params = load_json_file(
            self.args.additional_param_file)
        auto_healing_file = self.args.auto_healing_info_file
        if auto_healing_file:
            self.auto_healing_info = load_json_file(auto_healing_file)

    def get_uuid_and_name_to_heal(self):
        if not self.args.auto_healing_info_file:
            self.healing_type = self.Mode.MANUAL_HEAL
            return self.additional_params.get('resourceId'), self.additional_params.get('resourceName')

        logger.info('Healing was triggered by an alarm.')
        alarm_type = str(self.auto_healing_info['specificProblem'])
        if alarm_type.lower() in self.SINGLE_SC_HEAL_SUPPORTED_ALARM_TYPES:
            self.healing_type = self.Mode.AUTO_HEAL_SINGLE_SC
            return self.get_sc_uuid()
        elif alarm_type.lower() in self.OTHER_HEAL_SUPPORTED_ALARM_TYPES:
            return self.get_vm_uuid()
        logger.error(
            'Auto-healing is not supported for this alarm type: %r !',
            alarm_type)
        raise Exit(ReturnCode.REJECT)

    def get_sc_uuid(self):
        '''
        Return the SC uuid and name from the stack-show file - stack outputs.
        If uuid or name is missing from the stack details, throw an
        error, because the vSBG version cannot be autohealed without it.
        '''
        sc_uuid = self._get_stack_output('sc_uuids', as_str=True)
        if sc_uuid is self.OUTPUT_KEY_NOT_FOUND:
            logger.error(
                'SC uuid not found in stack details! '
                'Autohealing is not supported for this deployment!')
            raise Exit(ReturnCode.REJECT)
        sc_uuid = sc_uuid.strip()
        if len(sc_uuid.split(' ')) != 1:
            logger.error(
                'Expected Single SC deployment. This healing type'
                'is not supported for Dual SC deployments!')
            raise Exit(ReturnCode.REJECT)

        sc_name = self._get_stack_output('sc_names', as_str=True)
        if sc_name is self.OUTPUT_KEY_NOT_FOUND:
            logger.error('SC name not found in stack details!')
            sc_name = ''
        sc_name = sc_name.strip()

        return sc_uuid, sc_name

    def get_vm_uuid(self):
        '''
        Extract VM name from the managedObject field of auto-healing file,
        and try to match it with an SC or PL UUID.
        If UUID is missing from managedObject, throw an
        error, because the vSBG version cannot be autohealed without it.
        '''
        try:
            name = str(self.auto_healing_info['managedObject'].split('=')[-1])
        except Exception:
            logger.error('Cannot extract VM name from '
                         'managedObject field of alarm')
            raise Exit(ReturnCode.REJECT)

        sc_uuids = self._get_stack_output('sc_uuids', as_str=True)
        sc_names = self._get_stack_output('sc_names', as_str=True)
        pl_uuids = self._get_stack_output('pl_uuids', as_str=True)
        pl_names = self._get_stack_output('pl_names', as_str=True)

        try:
            if (sc_names is not self.OUTPUT_KEY_NOT_FOUND and
                    sc_uuids is not self.OUTPUT_KEY_NOT_FOUND):
                index = sc_names.split().index(name)
                self.healing_type = self.Mode.AUTO_HEAL_DUAL_SC

                # Remove error once dual SC heal is supported
                logger.error('Dual SC auto-healing is not '
                             'supported for this deployment!')
                raise Exit(ReturnCode.REJECT)
                # uuid = sc_uuids.split()[index]
                # return uuid, name
        except ValueError:
            pass

        try:
            index = pl_names.split().index(name)
            self.healing_type = self.Mode.AUTO_HEAL_PL
            uuid = pl_uuids.split()[index]
            return uuid, name
        except Exception:
            logger.error(
                'VM name or UUID not found in stack details!')
            raise Exit(ReturnCode.REJECT)

    def get_health_error(self):
        if self.healing_type == self.Mode.MANUAL_HEAL:
            return self.get_vm_health_error()
        if self.healing_type == self.Mode.AUTO_HEAL_SINGLE_SC:
            return self.get_sc_health_error()
        if self.healing_type == self.Mode.AUTO_HEAL_DUAL_SC:
            return self.get_vm_health_error()
        if self.healing_type == self.Mode.AUTO_HEAL_PL:
            return self.get_vm_health_error()
        logger.error("Unknown heal_type: %s", self.healing_type)
        raise Exit(ReturnCode.DATA_ERROR)

    def get_sc_health_error(self):
        '''
        Returns None if the SC O&M is accessible and the health checks
        on it internally are all green, otherwise return a string describing
        the issue. This is to provide information visible on the workflow UI.
        '''
        self._init_ssh_connection()
        return self._get_sc_mo_error_state()

    def get_vm_health_error(self):
        self._init_ssh_connection()
        return self._get_vm_health_error()

    def _get_vm_health_error(self):
        cluster_data, stderr, _ = self._try_run_cli_cmd('cluster list')
        if not cluster_data:
            return 'cluster list command failed: {}'.format(stderr)

        name = self.name_to_be_healed
        if name in cluster_data:
            logger.info('%s is found in cluster list', name)
        else:
            return '{} is not in cluster list'.format(name)

        stdout, stderr, _ = self._try_run_cli_cmd('cmw-status node -v || :')
        if not stdout:
            return 'cmw-status command failed.'

        cmw_status = stdout.splitlines()
        return self.check_health_in_cmw(cmw_status, name)

    def check_health_in_cmw(self, cmw_status, name):
        raise NotImplementedError()

    def _try_run_cliss_cmd(self, script):
        cli_cmd = self.CLISS_SCRIPT_WRAPPER.format(cliss_script=script)
        return self._try_run_cli_cmd(cli_cmd)

    def _try_run_cli_cmd(self, script):
        try:
            return self.ssh.run_command(script, fail_at_error=True)
        except Exception as e:
            logger.exception('Command run on node failed:\n%s', script)
            result = SSHErrorResult(e)
            return None, result, None  # compatible format with the run_command

    def find_cliss_error(self, stdout):
        for line in stdout.split('\n'):
            match = re.match(self.CLISS_ERROR_PATTERN, line)
            if match:
                return match.group('error_text')
        return None

    def _get_sc_mo_id(self):
        '''
        Return tuple <managed_element_id, error_message> where
        error_message is None if the expected value is found.
        '''
        stdout, stderr, _ = self._try_run_cliss_cmd('show')
        if stdout is None:
            return None, stderr

        error_text = self.find_cliss_error(stdout)
        if error_text:
            return None, 'Cliss error: {}'.format(error_text)

        mo_match = re.match(
            self.MANAGED_ELEMENT_ID_PATTERN, stdout.split('\n')[0])
        if not mo_match:
            logger.info('Unexpected cliss output:\n%r', stdout)
            return None, "Couldn't get SBG ManagedElement id, unexpected cliss output"
        return mo_match.group('mo_id'), None

    def _get_sc_mo_error_state(self):
        '''
        Return None if the SC MO seems healthy, otherwise return
        an error description of what is wrong.
        '''
        try:
            mo_id, error = self._get_sc_mo_id()
            if error:
                return error
            check_command = 'show ManagedElement={},SbgFunction=1'.format(mo_id)

            stdout, _, _ = self._try_run_cliss_cmd(check_command)
            if stdout is None:
                return "Cliss '{}' command non-zero exit".format(check_command)
            logger.info('Cliss output:\n%r', stdout)
            error = self.find_cliss_error(stdout)
            if error:
                return 'Cliss error: {}'.format(error)
        except Exception:
            logger.exception('Cliss check failed.')
            return 'Unexpected error while parsing cliss output'

        logger.info(
            "SbgFunction does not seem to be in error state, "
            "assuming it is healthy.")
        return None

    def _get_stack_param(self, param_name):
        stack_params = self.vnf_instance_data['stack']['parameters']
        if param_name not in stack_params:
            logger.error('Missing stack parameter: %s', param_name)
            raise Exit(ReturnCode.MISSING_JSON_PARAMETER)
        return self.vnf_instance_data['stack']['parameters'][param_name]

    def _get_stack_output(self, output_name, as_str=False):
        try:
            output = [
                output_obj for output_obj
                in self.vnf_instance_data['stack']['outputs']
                if output_obj['output_key'] == output_name
            ]
            if len(output) == 0:
                return self.OUTPUT_KEY_NOT_FOUND
            if len(output) > 1:
                logger.error(
                    'Unexpected amount of outputs found! For %r: %r',
                    output_name, output)
                raise RuntimeError()

            if as_str:
                return (
                    str(output[0]['output_value']).strip()
                    if output[0]['output_value'] is not None
                    else None
                )
            return output[0]['output_value']

        except Exception:
            logger.exception('Unexpected format in instance details!')
            raise Exit(ReturnCode.PARSE_ERROR)

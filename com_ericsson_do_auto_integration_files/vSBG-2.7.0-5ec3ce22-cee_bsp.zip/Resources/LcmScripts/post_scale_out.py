#!/usr/bin/env python2
"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2019.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import logging
import sys
# pylint: disable=import-error
from imscommon.exceptions import Exit
from imscommon.consts import ReturnCode
from sbg_parsers import SBGOpenstackJsonParser as OpenstackJsonParser
from sbg_common import CommonLcmTask
from scale_common import ScaleParser


# pylint: disable=missing-docstring
class PostScaleOut(CommonLcmTask):
    # pylint: disable=too-few-public-methods
    class InputData(object):
        # pylint: disable=too-many-arguments
        def __init__(self,
                     sc_ip,
                     key_filename,
                     admin_username,
                     password,
                     instance_id,
                     steps,
                     aspect_id):
            self.sc_ip = sc_ip
            self.key_filename = key_filename
            self.admin_username = admin_username
            self.password = password
            self.instance_id = instance_id
            self.steps = steps
            self.aspect_id = aspect_id

        def __repr__(self):
            return repr(self.__dict__)

    def __init__(self):
        super(PostScaleOut, self).__init__(workflow_name=self.__class__.__name__)

        self.input_data = self.argument_parsing()
        self.ssh = None

    def __call__(self):
        self.ssh = self.connect_to_host(
            ip=self.input_data.sc_ip,
            username=self.input_data.admin_username,
            password=self.input_data.password,
            key_filename=self.input_data.key_filename,
            port=22)

        LOGGER.info('Checking if SSH is available')
        if not self.check_connection(self.ssh):
            LOGGER.warning('SSH connection is not available yet.')
            print('SSH connection is not available yet.')
            raise Exit(ReturnCode.REPEAT)

        LOGGER.info('Checking if new PLs are available')
        if not self.check_new_payload_available():
            LOGGER.warning('New PLs are not available yet.')
            print('New PLs are not available yet.')
            raise Exit(ReturnCode.REPEAT)

        self.ssh.close()

    def check_new_payload_available(self):
        # check if new PLs are managed via SC => check current num PLs = expect num PLs
        (stdout, _, _) = self.ssh.run_command(
            str.format("cmw-status node -v | grep _PL- | wc -l"))
        current_num_pls = int(stdout.strip())

        expect_num_pls = self.vnf_instance_file_parser.get_payload_instance_count()
        if current_num_pls != expect_num_pls:
            print(str.format(
                "Fewer than expected PLs found (expected {} found {}).",
                expect_num_pls, current_num_pls))
            return False

        # check operateSate of new PLs
        (stdout, _, _) = self.ssh.run_command(
            str.format("cmw-status node -v | grep -Po '(?<=_PL-)[0-9]+' | sort -rn | head -1"))
        new_max_id_pl = int(stdout.strip())
        step = self.input_data.steps
        for checked_pl in range(new_max_id_pl, new_max_id_pl - step, -1):
            (stdout, _, _) = self.ssh.run_command(
                str.format("cmw-status node -v | grep PL-{} -A 2"
                           "| grep OperState=ENABLED ||:", checked_pl))
            if stdout.strip() == "":
                print("PL {} is not ENABLED. ".format(checked_pl))
                return False
        return True

    def argument_parsing(self):
        self.add_common_arguments('post_scaleout hook for workflow')
        self.add_additional_arguments()

        args = self.parser.parse_args()
        self.parsed_args = args

        self.cloud_type = self.get_cloud_type(args.vnf_instance_details_file)
        LOGGER.debug('Loading vnf_instance_details_file: %r',
                     args.vnf_instance_details_file)

        if self.cloud_type == 'OPENSTACK':
            self.vnf_instance_file_parser = OpenstackJsonParser(
                args.vnf_instance_details_file)
            (sc_ip, admin_username, _) = self.vnf_instance_file_parser.get_all_params()
        elif self.cloud_type == 'VMWARE':
            self.vnf_instance_file_parser = ScaleParser.PreScaleXMLParser(
                args.vnf_instance_details_file)
            (sc_ip, admin_username, _, _) = self.vnf_instance_file_parser.get_all_params()

        data = PostScaleOut.InputData(sc_ip,
                                      args.key_file,
                                      admin_username,
                                      args.password_file,
                                      args.workflow_instance_identifier,
                                      args.number_of_steps,
                                      args.aspect_id)

        return data

    def add_additional_arguments(self):
        self.parser.add_argument(
            '-n', '--number-of-steps', metavar='<STEPS>',
            help='Number of scaling steps.',
            type=int,
            required=False)
        self.parser.add_argument(
            '-x', '--aspect-id', metavar='<ASPECT_ID>',
            help='The aspect ID of the scaling group to scale.',
            required=False)
        self.parser.add_argument(
            '-i', '--workflow-instance-identifier', metavar='<ID>',
            help='Workflow instance identifier.',
            required=False)


def main():
    try:
        post_scale_out = PostScaleOut()
        post_scale_out()
    except Exit as ex:
        LOGGER.error('Exiting (%d)', ex.return_code)
        sys.exit(ex.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    LOGGER = logging.getLogger('post_scale_out')
    main()

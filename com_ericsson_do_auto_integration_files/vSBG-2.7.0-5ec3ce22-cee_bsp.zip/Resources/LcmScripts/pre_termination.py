#!/usr/bin/env python2

"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import logging
import sys
import ast
from sbg_parsers import SBGVCDXmlParser as VCDXmlParser
from sbg_parsers import SBGOpenstackJsonParser as OpenstackJsonParser
from imscommon.consts import ReturnCode
from imscommon.consts import VmAdminState
from imscommon.exceptions import Exit
from sbg_common import CommonLcmTask

DEFAULT_ADMIN = 'vsbg-admin'


class PreTermination(CommonLcmTask):
    class InputData:
        def __init__(self, sc_ip=None,
                     termination_type=None,
                     admin_username=None,
                     key_filename=None,
                     password_file=None):
            self.sc_ip = sc_ip
            self.termination_type = termination_type
            self.admin_username = admin_username
            self.key_filename = key_filename
            self.password_file = password_file

    def __init__(self):
        super(PreTermination, self).__init__(workflow_name=self.__class__.__name__)
        self.input_data = self.argument_parsing()
        self.ssh = None

        if self.input_data.termination_type == 'FORCEFUL':
            logger.info('FORCEFUL TERMINATION')
            # Continue with the deletion of VAPP without the locking procedure
            raise Exit(ReturnCode.SUCCESS)

        self.ssh = self.connect_to_host(
            ip=self.input_data.sc_ip,
            username=self.input_data.admin_username,
            password=self.input_data.password_file,
            key_filename=self.input_data.key_filename,
            port=22)
        logger.info('Checking if SSH is available')
        if not self.check_connection(self.ssh):
            logger.warning('SSH connection is not available yet.')
            print('SSH connection is not available yet.')
            raise Exit(ReturnCode.REPEAT)
        logger.info('Prepare for graceful lock')
        self.graceful_lock_mated_pair(self.input_data.admin_username)
        logger.info('Graceful lock is in progress')
        admin_status = self.read_adm_status(self.input_data.admin_username)
        logger.info('admin_status: %s', admin_status)
        if self.check_matedpair_locked(admin_status):
            logger.info("All mated pairs are locked.")
            raise Exit(ReturnCode.SUCCESS)
        else:
            logger.warning("Mated pairs are not locked yet.")
            print("Mated pairs are not locked yet.")
            raise Exit(ReturnCode.REPEAT)

    def check_matedpair_locked(self, status):
        """
        check admin status returned from function read_adm_status,
        input status format: ("{1: 'LOCKED'}\n", '', 0)
        """
        admin_dict = ast.literal_eval(status[0].strip())
        if len(admin_dict) == 0:
            logger.info("No Mated Pair!")
            return True
        else:
            for mated_pair_id, mated_pair_status in admin_dict.iteritems():
                if mated_pair_status != VmAdminState.LOCKED:
                    logger.error('Mated Pair %s is not LOCKED' % mated_pair_id)
                    return False
            logger.info('All mated pair is LOCKED')
            return True

    def graceful_lock_mated_pair(self, username):
        try:
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--gracefullock",
                    username))
        except:
            logger.error('Graceful lock is unsuccessful')
            print('Graceful lock is unsuccessful')
            raise Exit(ReturnCode.REPEAT)
        return True

    def add_additional_arguments(self):
        self.parser.add_argument('-t', '--termination-type',
                                 metavar='<TERMINATION_TYPE>',
                                 choices=['GRACEFUL', 'FORCEFUL'],
                                 help='Termination type',
                                 type=str, required=True)
        self.parser.add_argument('-s', '--graceful-timeout', metavar='<TIME>',
                                 help='Graceful lock timeout, not supported by vSBG',
                                 type=str, required=False)
        self.parser.add_argument('-i', '--workflow-instance-identifier', metavar='<ID>',
                                 help='Workflow instance identifier.',
                                 required=False)

    def argument_parsing(self):
        # Add the common input arguments
        self.add_common_arguments('pre_termination hook for workflow')
        # Add additional arguments for termination
        self.add_additional_arguments()
        args = self.parser.parse_args()
        self.parsed_args = args
        self.cloud_type = self.get_cloud_type(args.vnf_instance_details_file)
        logger.debug('Loading vnf_instance_details_file: %r',
                     args.vnf_instance_details_file)
        if self.cloud_type == 'OPENSTACK':
            self.vnf_instance_file_parser = OpenstackJsonParser(
                args.vnf_instance_details_file
            )
        elif self.cloud_type == 'VMWARE':
            self.vnf_instance_file_parser = VCDXmlParser(
                args.vnf_instance_details_file
            )
        sc_ip, admin_username, dummy = \
            self.vnf_instance_file_parser.get_all_params()
        data = PreTermination.InputData(sc_ip,
                                        args.termination_type,
                                        admin_username,
                                        args.key_file,
                                        args.password_file)
        logger.info('Input data: %r', data)
        return data


def main():
    try:
        PreTermination()
    except Exit as e:
        logger.error('Exiting (%d)', e.return_code)
        sys.exit(e.return_code)

if __name__ == '__main__':
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    logger = logging.getLogger('pre_termination')
    main()

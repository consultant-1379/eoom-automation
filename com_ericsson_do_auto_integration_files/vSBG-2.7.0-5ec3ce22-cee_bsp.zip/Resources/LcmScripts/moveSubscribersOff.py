#!/usr/bin/env python2

"""
----------------------------------------------------------------------------
(C) Copyright Ericsson AB 2018.  All rights reserved.
No part of this software may be reproduced in any form
without the written permission of the copyright owner.
----------------------------------------------------------------------------
"""

from __future__ import absolute_import, print_function

import os
import datetime
import time
import json
import logging
import sys
import argparse
import re
import paramiko
from imscommon import SSHUtility
from imscommon.consts import ReturnCode
from imscommon.exceptions import Exit

DEFAULT_ADMIN = 'vsbg-admin'


def mkcmd(*parts):
    """ Create an escaped command line from its parts """
    return ' '.join("'{0}'".format(p) for p in parts)


class MoveSubscribers:
    def __init__(self, args):
        self.additional_params = self.argument_parsing(args)
        self.locktype = self.get_additional_param('mos1lockType')
        self.redistributionrate = self.get_additional_param('mos2maxUserRedistributionRate')
        self.timeout = self.get_additional_param('mos3mosTimeout')
        self.action_after_timeout = self.get_additional_param('mos4actionAfterTimeout')
        self.ssh = self.connect_to_host(ip=self.sc_ip,
                                        username=self.admin_username,
                                        port=22)
        logger.info('Checking if SSH is available.')
        if not self.check_connection():
            logger.warning('SSH connection is not available yet.')
            print('SSH connection is not available yet.')
            raise Exit(ReturnCode.REPEAT)
        self.create_vnflcm_dir()

        admin_status = self.read_adm_status(self.admin_username)
        self.check_matedpair_locked(admin_status)

        if (self.cancel == 'cancel'):
            logger.info('Begin to cancel MoS action...')
            self.cancel_mos_action(self.admin_username)
            admin_operation_status = self.read_adm_operation_status(self.admin_username)
            logger.info('After cancel action, admin_operation_status  is: %s', admin_operation_status)
            if self.check_matedpair_unlocked(admin_operation_status):
                logger.info("Cancel action is successful.")
                raise Exit(ReturnCode.SUCCESS)
            else:
                logger.warning('Canceling MoS is in progress, waitting all mated pairs unlocked.')
                print('Canceling MoS is in progress, waitting all mated pairs unlocked.')
                raise Exit(ReturnCode.REPEAT)

        if self.locktype == 'Graceful Lock':
            logger.info('Prepare for mos graceful lock')
            self.mos_graceful_lock_mated_pair(self.admin_username, self.redistributionrate)
            logger.info('MoS graceful lock is in progress')
            self.wait_for_matedpair_status()
        elif self.locktype == 'Forceful Lock':
            logger.info('MoS forceful lock')
            self.mos_forceful_lock_mated_pair(self.admin_username)

    def create_vnflcm_dir(self):
        try:
            self.ssh.run_command(
                str.format(
                    "if [ ! -d '{0}' ]; then "
                    "  mkdir -m 777 '{0}'; "
                    "fi",
                    self.path('VNFLCM_DIR')))
        except:
            logger.exception('Failed to create dir %r', self.path('VNFLCM_DIR'))
            print('Failed to create dir %s' % self.path('VNFLCM_DIR'))
            raise Exit(ReturnCode.REPEAT)

    def check_matedpair_locked(self, status):
        """
        check admin status returned from function read_adm_status,
        input status format: ("{1: 'LOCKED'}\n", '', 0)
        """
        if type(status) is tuple and len(status) is 3 and status[2] is 0:
            regex = re.compile(r'\'[a-zA-Z]+\'', re.I)
            statuslist = regex.findall(status[0])
            if len(statuslist) is 0:
                logger.error("Check mated pairs status: No Mated Pair!")
                raise Exit(ReturnCode.RETURN_ERROR)
                return True
            else:
                for item in statuslist:
                    if item != "'LOCKED'":
                        logger.error('Mated Pair is not LOCKED')
                        return False
                logger.info('All mated pair is LOCKED')
                return True
        else:
            logger.error('Status input error!')
            return False

    def check_matedpair_unlocked(self, status):
        """
        check adm_operation status returned from function read_adm_operation_status,
        input status format: ("{1: ['ENABLED', 'UNLOCKED']}\n", '', 0)
        """
        if type(status) is tuple and len(status) is 3 and status[2] is 0:
            regex = re.compile(r'\'[a-zA-Z]+\'', re.I)
            statuslist = regex.findall(status[0])
            if len(statuslist) is 0:
                logger.debug("No Mated Pair!")
                return True
            else:
                for i in range(0, len(statuslist), 2):
                    if statuslist[i] == "'DISABLED'":
                        logger.debug('No action')
                        continue
                    if statuslist[i + 1] != "'UNLOCKED'":
                        logger.info('Mated Pair is not UNLOCKED')
                        return False
                return True
        else:
            logger.error('Status input error!')
            return False

    def connect_to_host(self, ip, username, port=22):
        return SSHUtility.SSHUtility(
            ip=ip,
            username=username,
            port=port,
            password=self.password,
            key_filename=self.key_filename,
            keep_alive=True)

    def check_connection(self):
        try:
            self.ssh.run_command('w')
        except paramiko.AuthenticationException:
            logger.error('SSH Authentication failed')
            raise Exit(ReturnCode.RETURN_ERROR)
        except:
            logger.exception('Failed to execute remote command')
            return False
        else:
            return True

    def read_adm_status(self, username):
        return self.ssh.run_command(
            str.format(
                "/opt/imex/mated_pair_util.py "
                "--user '{0}' "
                "--getadmstat",
                username))

    def _check_starttimefile(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f', self.path('START_TIME_FILE')),
                                 fail_at_error=False)
        return retcode == 0

    def read_adm_operation_status(self, username):
        return self.ssh.run_command(
            str.format(
                "/opt/imex/mated_pair_util.py "
                "--user '{0}' "
                "--getadmoperationstat ",
                username))

    def _check_configfile(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('test', '-f', self.path('CONFIG_FILE')),
                                 fail_at_error=False)
        return retcode == 0

    def _get_config(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat', self.path('CONFIG_FILE')),
                                 fail_at_error=False)
        ret = int(stdout.strip())
        return ret

    def _get_time(self):
        stdout, stderr, retcode = \
            self.ssh.run_command(mkcmd('cat', self.path('START_TIME_FILE')),
                                 fail_at_error=False)
        ret = stdout.strip()
        return ret

    def mos_graceful_lock_mated_pair(self, username, mosrate):
        if self._check_configfile():
            oldrate = self._get_config()
            if oldrate == mosrate:
                return True
        try:
            self.ssh.run_command(
                str.format(
                    "/opt/imex/configure_mo.py "
                    "--user '{0}' "
                    "--mosrate '{1}'; "
                    "echo '{1}' > '{2}'",
                    username,
                    str(mosrate),
                    self.path('CONFIG_FILE')))
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--unlock all",
                    username))
            time.sleep(5)
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--mosgracefullock all",
                    username))
            if not self._check_starttimefile():
                start, err, ret = self.ssh.run_command('date +%s')
                self.ssh.run_command(
                    str.format(
                        "echo '{0}' > '{1}'",
                        start.strip(),
                        self.path('START_TIME_FILE')))
        except:
            logger.error('Graceful lock is unsuccessful')
            print('Graceful lock is unsuccessful')
            raise Exit(ReturnCode.REPEAT)
        return True

    def wait_for_matedpair_status(self):
        logger.info('Waiting for all mated pairs locked...')
        admin_status = self.read_adm_status(self.admin_username)
        logger.debug('Admin_status: %s', admin_status)
        if self.check_matedpair_locked(admin_status):
            logger.info("MoS action is successful.")
            raise Exit(ReturnCode.SUCCESS)
        else:
            if self.timeout == -1:
                logger.info('MoS is in progress, Waiting for all mated pairs '
                            'locked without time limitation.')
                print('MoS is in progress, Waiting for all mated pairs '
                      'locked without time limitation.')
                raise Exit(ReturnCode.REPEAT)
            start = self._get_time()
            start_time = datetime.datetime.fromtimestamp(float(start))
            current, err, ret = self.ssh.run_command('date +%s')
            current_time = datetime.datetime.fromtimestamp(float(current.strip()))
            duration = (current_time - start_time).seconds
            if duration < self.timeout:
                logger.info(
                    'MoS action is in progress for %s seconds, Waiting for '
                    'all mated pairs locked until %s seconds timeout.',
                    duration, self.timeout)
                print(
                    'MoS action is in progress for %s seconds, Waiting'
                    ' for all mated pairs locked until %s seconds timeout.'
                    % (duration, self.timeout))
                raise Exit(ReturnCode.REPEAT)
            else:
                if self.action_after_timeout == 'Forceful lock':
                    self.ssh.run_command(
                        str.format(
                            "/opt/imex/mated_pair_util.py "
                            "--forcedlock all"))
                    raise Exit(ReturnCode.SUCCESS)
                elif self.action_after_timeout == 'Unlock':
                    self.ssh.run_command(
                        str.format(
                            "/opt/imex/mated_pair_util.py "
                            "--unlock all"))
                    raise Exit(ReturnCode.SUCCESS)
                elif self.action_after_timeout == 'No action':
                    raise Exit(ReturnCode.SUCCESS)

    def mos_forceful_lock_mated_pair(self, username):
        try:
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--unlock all",
                    username))
            time.sleep(5)
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--forcedlock all",
                    username))
        except:
            logger.error('Forceful lock is unsuccessful')
            print('Forceful lock is unsuccessful')
            raise Exit(ReturnCode.REPEAT)
        return True

    def cancel_mos_action(self, username):
        try:
            self.ssh.run_command(
                str.format(
                    "/opt/imex/mated_pair_util.py "
                    "--user '{0}' "
                    "--unlock all",
                    username))
        except:
            logger.error('Cancel mos action is unsuccessful')
            print('Cancel mos action is unsuccessful')
            raise Exit(ReturnCode.REPEAT)

    def path(self, name):
        if self.workflow_instance_identifier is None:
            conf_dir = 'vnflcm_mos'
        else:
            conf_dir = 'vnflcm_mos_' + self.workflow_instance_identifier

        home_dir = os.path.join('/home', self.admin_username)
        vnflcm_dir = os.path.join(home_dir, conf_dir)
        return {
            'VNFLCM_DIR':
                vnflcm_dir,
            'CONFIG_FILE':
                os.path.join(vnflcm_dir, 'mos_config'),
            'START_TIME_FILE':
                os.path.join(vnflcm_dir, 'mos_start_time')}[name]

    def add_common_arguments(self, description):
        self.parser = argparse.ArgumentParser(description=description)
        self.mandatory = self.parser.add_argument_group('mandatory arguments')
        self.mandatory.add_argument(
            '-f', '--vnf-instance-details-file', metavar='<FILE>',
            help=('Path to the file containing the response of '
                  'stack show details (OpenStack) or vAPP details (vCloud Director) '
                  'command in json (OpenStack) or xml (vCloud Director) format.'),
            required=True)

        arg = self.parser.add_argument
        arg('-k', '--key-file', metavar='<KEY_FILE>',
            help='Path to the file containing the private key for login.')
        arg('-p', '--password-file', metavar='<PASSWORD_FILE>',
            help=('Path to the file containing the password '
                  'to login into the VNF instance.'))
        arg('-u', '--user-name', metavar='<USERNAME>',
            help='Username to login into the VNF instance')

    def argument_parsing(self, args):
        self.add_common_arguments('move_subs hook for workflow')
        self.parser.add_argument(
            '-a', '--additional-param-file', metavar='<ADDITIONAL_PARAM_FILE>',
            help='All additional parameters.')
        self.parser.add_argument(
            '-i', '--workflow-instance-identifier', metavar='<ID>',
            help='Workflow instance identifier.',
            required=False)
        self.parser.add_argument(
            '-q', '--quit-operation', metavar='<QUIT_OPERATION>',
            help='Cancel MoS operation.',
            required=False)
        self.parsed_args = self.parser.parse_args(args)
        all_args = self.parsed_args
        with open(all_args.vnf_instance_details_file) as json_file:
            stack_details = json.load(json_file)['stack']
        parameters = dict(
            (k, v.strip())
            for k, v in stack_details['parameters'].iteritems()
        )
        stack_outputs = dict(
            (output['output_key'], output['output_value'])
            for output in stack_details['outputs']
        )

        self.sc_ip = stack_outputs.get('Output-IP')
        self.admin_username = parameters.get('admin_username', DEFAULT_ADMIN)
        self.password = self.parsed_args.password_file,
        self.key_filename = self.parsed_args.key_file
        self.workflow_instance_identifier = all_args.workflow_instance_identifier
        self.cancel = all_args.quit_operation
        return self.parse_additional_params()

    def parse_additional_params(self):
        if not self.parsed_args.additional_param_file:
            return None
        try:
            with open(self.parsed_args.additional_param_file) as json_file:
                return json.load(json_file)
        except ValueError:
            logger.error("Input JSON file is invalid: %s ", self.parsed_args.additional_param_file)
            raise Exit(ReturnCode.INVALID_JSON)

    def get_additional_param(self, param):
        if not self.additional_params:
            return None
        try:
            return self.additional_params[param]
        except KeyError:
            return None


def main():
    try:
        MoveSubscribers(sys.argv[1:])
    except Exit as e:
        logger.error('Exiting (%d)', e.return_code)
        sys.exit(e.return_code)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(name)s] %(levelname)s %(message)s',
        stream=sys.stderr)
    logger = logging.getLogger('move_subscribers')
    main()
